#!/usr/bin/env python3
"""
ign MCP Server
==============
Exposes ign CLI tools over the Model Context Protocol (stdio transport).

Start via:   python mcp_server.py          (or: ign mcp)
Configure in Copilot CLI:  /mcp add ign python /absolute/path/to/mcp_server.py
"""

from __future__ import annotations

import asyncio
import functools
import os
import re
import shutil
import site
import sys
from pathlib import Path
from typing import Callable

import mcp.server.stdio
import mcp.types as types
from mcp.server import Server

# ---------------------------------------------------------------------------
# Async subprocess runner
# ---------------------------------------------------------------------------

_ANSI_RE = re.compile(r"\x1b\[[\d;]*[a-zA-Z]")

# Use the directory where the MCP server process was launched (i.e. the user's
# project root) as cwd for subprocesses, falling back to the repo root that
# contains this file when the two coincide (dev workflow).
_PROJECT_ROOT = os.getcwd()


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


@functools.lru_cache(maxsize=1)
def _ign_cmd() -> tuple[str, ...]:
    """Resolve the ign executable once and cache the result."""
    exe = shutil.which("ign")
    if exe:
        return (exe,)
    return (sys.executable, str(Path(__file__).with_name("ignition.py")))


async def _run_ign(args: list[str], cwd: str | None = None, timeout: int | None = 120) -> str:
    """Run an ign sub-command asynchronously without blocking the event loop.

    ``timeout`` of None disables the time limit — used for commands that run
    ``terraform apply`` against real infrastructure, which must never be killed
    mid-run. On timeout the process is asked to stop gracefully (SIGTERM) so
    terraform can release its state lock, and only hard-killed if it ignores it.
    """
    cmd = [*_ign_cmd(), *args]
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "NO_COLOR": "1"}
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            # DEVNULL prevents the subprocess from reading the MCP stdio pipe
            # (which would corrupt the protocol stream or cause hangs on prompts).
            stdin=asyncio.subprocess.DEVNULL,
            cwd=cwd or _PROJECT_ROOT,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=10)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
            return (
                f"ERROR: command timed out after {timeout} s and was terminated. "
                "If this was a terraform apply, run a plan to check for "
                "partially-applied changes before retrying."
            )
        raw = (stdout or b"").decode("utf-8", errors="replace") + \
              (stderr or b"").decode("utf-8", errors="replace")
        return _strip_ansi(raw).strip()
    except Exception as exc:
        return f"ERROR: {exc}"


# ---------------------------------------------------------------------------
# Native (no-subprocess) fast handlers for read-only discovery commands
# These avoid the ~0.5–1 s Python startup cost on every call.
# ---------------------------------------------------------------------------

def _template_search_dirs() -> list[Path]:
    """Return candidate directories for stack templates (mirrors ignition.py logic)."""
    dirs: list[Path] = [
        Path(__file__).parent / "resources" / "modules" / "stacks",
        Path(_PROJECT_ROOT) / "resources" / "modules" / "stacks",
        Path(_PROJECT_ROOT) / "modules" / "stacks",
        Path(sys.prefix) / "resources" / "modules" / "stacks",
        Path(sys.prefix) / "share" / "modules" / "stacks",
    ]
    try:
        if hasattr(site, "USER_BASE") and site.USER_BASE:
            dirs.append(Path(site.USER_BASE) / "resources" / "modules" / "stacks")
            dirs.append(Path(site.USER_BASE) / "share" / "modules" / "stacks")
    except Exception as exc:
        # Ignore failures when probing optional USER_BASE stack locations, but log for debugging.
        print(f"[ignition] _template_search_dirs: ignoring USER_BASE error: {exc}", file=sys.stderr)
    try:
        for sd in site.getsitepackages():
            dirs.append(Path(sd) / "resources" / "modules" / "stacks")
    except Exception as exc:
        # Ignore failures when probing optional site-packages stack locations, but log for debugging.
        print(f"[ignition] _template_search_dirs: ignoring site-packages error: {exc}", file=sys.stderr)
    return dirs


def _module_search_dirs() -> list[Path]:
    """Return candidate directories for Terraform modules (mirrors ignition.py logic)."""
    dirs: list[Path] = [
        Path(__file__).parent / "resources" / "modules" / "azure",
        Path(_PROJECT_ROOT) / "resources" / "modules" / "azure",
        Path(_PROJECT_ROOT) / "modules" / "azure",
        Path(_PROJECT_ROOT) / "modules",
        Path(sys.prefix) / "resources" / "modules" / "azure",
        Path(sys.prefix) / "share" / "resources" / "modules" / "azure",
    ]
    try:
        if hasattr(site, "USER_BASE") and site.USER_BASE:
            dirs.append(Path(site.USER_BASE) / "resources" / "modules" / "azure")
            dirs.append(Path(site.USER_BASE) / "share" / "resources" / "modules" / "azure")
    except Exception as exc:
        # Ignore failures when probing optional USER_BASE module locations, but log for debugging.
        print(f"[ignition] _module_search_dirs: ignoring USER_BASE error: {exc}", file=sys.stderr)
    try:
        for sd in site.getsitepackages():
            dirs.append(Path(sd) / "resources" / "modules" / "azure")
    except Exception as exc:
        # Ignore failures when probing optional site-packages module locations, but log for debugging.
        print(f"[ignition] _module_search_dirs: ignoring site-packages error: {exc}", file=sys.stderr)
    return dirs


def _native_list_stack_templates() -> str:
    """List available stack templates without spawning a subprocess."""
    stacks: dict[str, Path] = {}
    for d in _template_search_dirs():
        if not d.exists():
            continue
        for p in d.iterdir():
            if p.is_dir() and p.name not in stacks:
                stacks[p.name] = p

    if not stacks:
        return (
            "No stack templates found.\n"
            "Tip: run 'ign list-stack-templates --debug' for search-path details."
        )

    header = f"{'Template':<35} {'Terraform':<12} {'YAML':<8} {'Scripts':<10} {'Pipeline'}"
    sep = "-" * len(header)
    rows = [header, sep]
    for name, path in sorted(stacks.items()):
        tf  = "✓" if (path / "terraform").exists()        else "–"
        yml = "✓" if (path / "yaml").exists()             else "–"
        scr = "✓" if (path / "scripts").exists()          else "–"
        pip = "✓" if (path / "azure-pipelines.yml").exists() else "–"
        rows.append(f"{name:<35} {tf:<12} {yml:<8} {scr:<10} {pip}")

    rows.append("")
    rows.append("To add a template:  ign add-stack-template --stack-name <name>")
    return "\n".join(rows)


def _native_list_modules() -> str:
    """List available Terraform modules without spawning a subprocess."""
    modules: dict[str, Path] = {}

    for d in _module_search_dirs():
        if not d.exists():
            continue
        # For directories that may contain stack sub-trees (e.g. modules/ root),
        # only look at immediate .tf files to avoid crawling stack templates.
        is_root_modules = (d == Path(_PROJECT_ROOT) / "modules")
        pattern = "*.tf" if is_root_modules else "**/*.tf"
        for tf_file in d.glob(pattern):
            name = tf_file.stem
            if name not in modules:
                modules[name] = tf_file

    if not modules:
        return (
            "No Terraform modules found.\n"
            "Tip: run 'ign list-modules --debug' for search-path details."
        )

    header = f"{'Module':<35} Description"
    sep = "-" * 70
    rows = [header, sep]
    for name, path in sorted(modules.items()):
        description = ""
        try:
            for line in path.read_text(encoding="utf-8").splitlines()[:5]:
                if line.strip().startswith("# Description:"):
                    description = line.replace("# Description:", "").strip()
                    break
        except Exception:
            pass
        rows.append(f"{name:<35} {description or '(no description)'}")
    return "\n".join(rows)


def _native_list_stacks() -> str:
    """List project stacks without spawning a subprocess.

    Stacks live under stacks/ (regular) and landing-zones/ (ALZ stacks, whose
    names start with "alz"); both locations are enumerated.
    """
    root = Path(_PROJECT_ROOT)
    stack_parents = ("stacks", "landing-zones")
    if not any((root / parent).exists() for parent in stack_parents):
        return (
            "No 'stacks/' directory found in the project root.\n"
            "Initialise a project first with:  ign init"
        )

    stack_paths = []
    for parent in stack_parents:
        parent_dir = root / parent
        if parent_dir.is_dir():
            stack_paths.extend(p for p in parent_dir.iterdir() if p.is_dir())
    stack_paths.sort(key=lambda p: p.name)

    if not stack_paths:
        return "No stacks found in the project."

    header = f"{'Status':<12} {'Stack Name':<30} {'Location':<16} {'Terraform':<12} {'YAML'}"
    sep = "-" * len(header)
    rows = [header, sep]
    for sp in stack_paths:
        has_tf   = (sp / "terraform").exists()
        has_yaml = (sp / "yaml").exists()
        status   = "Ready  " if has_tf and has_yaml else "Partial"
        rows.append(
            f"{status:<12} {sp.name:<30} {sp.parent.name + '/':<16} {'✓' if has_tf else '✗':<12} {'✓' if has_yaml else '✗'}"
        )
    return "\n".join(rows)


# Map tool names to their native (no-subprocess) handlers.
_NATIVE: dict[str, Callable[[], str]] = {
    "list_stack_templates": _native_list_stack_templates,
    "list_modules":         _native_list_modules,
    "list_stacks":          _native_list_stacks,
}




def _opt(args: list[str], a: dict, key: str, flag: str) -> None:
    """Append ``--flag value`` to *args* if *key* is present and truthy."""
    val = a.get(key)
    if val:
        args.extend([flag, str(val)])


def _bool_flag(args: list[str], a: dict, key: str, flag: str) -> None:
    """Append ``--flag`` to *args* if *key* is truthy."""
    if a.get(key):
        args.append(flag)


def _stack_or_all(cmd: str, a: dict, *, positional: bool = False) -> list[str]:
    """Build ``[cmd, --stack X | --all | X]`` for the common pattern."""
    args = [cmd]
    stack = a.get("stack", "")
    if a.get("all") or not stack:
        args.append("--all")
    elif positional:
        args.append(stack)
    else:
        args.extend(["--stack", stack])
    return args


# ---------------------------------------------------------------------------
# Per-tool arg builders (for tools that need custom logic)
# ---------------------------------------------------------------------------

def _args_init_project(a: dict) -> list[str]:
    # `ign init` prompts for the cloud provider (1 = AWS, 2 = Azure) when --cloud
    # is absent. MCP subprocesses run with stdin=DEVNULL, so that prompt can never
    # be answered — the provider must be decided up front and passed explicitly.
    cloud = str(a.get("cloud", "")).strip().lower()
    cloud = {"1": "aws", "2": "azure"}.get(cloud, cloud)
    if cloud not in ("aws", "azure"):
        raise ValueError(
            "'cloud' is required and must be 'aws' (menu option 1) or "
            "'azure' (menu option 2). Ask the user which cloud provider the "
            "project targets before calling init_project."
        )

    args = ["init", "--cloud", cloud]
    _opt(args, a, "project_name", "--project-name")
    _opt(args, a, "project_code", "--project-code")
    if cloud == "azure":
        # `ign init` also prompts for the CI/CD tool on Azure (1 = ADO, 2 = GitHub).
        cicd = str(a.get("cicd", "")).strip().lower()
        cicd = {"1": "ado", "2": "github", "azure-devops": "ado", "github-actions": "github"}.get(cicd, cicd)
        if cicd not in ("ado", "github"):
            raise ValueError(
                "'cicd' is required for Azure projects and must be 'ado' (Azure DevOps, menu "
                "option 1) or 'github' (GitHub Actions, menu option 2). Ask the user which "
                "CI/CD tool they use before calling init_project."
            )
        args += ["--cicd", cicd]
        _opt(args, a, "location", "--location")
        if cicd == "ado":
            _opt(args, a, "service_connection", "--service-connection")
        else:
            if not a.get("github_org"):
                raise ValueError("'github_org' is required when cicd is 'github'. Ask the user for their GitHub organisation.")
            _opt(args, a, "github_org", "--github-org")
            # Remaining GitHub prompts have defaults, but stdin is closed - pass them explicitly.
            args += ["--github-repo", str(a.get("github_repo") or a.get("project_code") or a.get("project_name") or "infrastructure")]
            args += ["--cicd-repo", str(a.get("cicd_repo") or "terraform-azure-cicd")]
            args += ["--cicd-ref", str(a.get("cicd_ref") or "main")]
    else:
        _opt(args, a, "aws_region", "--aws-region")
    return args


def _args_add_stack(a: dict) -> list[str]:
    args = ["add-stack"]
    _opt(args, a, "stack_name", "--stack-name")
    _opt(args, a, "description", "--description")
    _opt(args, a, "service_connection", "--service-connection")
    _bool_flag(args, a, "include_databricks", "--include-databricks")
    _bool_flag(args, a, "include_storage", "--include-storage")
    _bool_flag(args, a, "include_keyvault", "--include-keyvault")
    return args


def _args_add_stack_template(a: dict) -> list[str]:
    args = ["add-stack-template"]
    _opt(args, a, "stack_name", "--stack-name")
    return args


def _args_add_resource(a: dict) -> list[str]:
    args = ["add-resource"]
    _opt(args, a, "stack_name", "--stack-name")
    _opt(args, a, "resource_type", "--resource-type")
    _opt(args, a, "resource_name", "--resource-name")
    return args


def _args_rename_stack(a: dict) -> list[str]:
    return ["rename-stack", "--yes", a["old_name"], a["new_name"]]


def _args_env_clone(a: dict) -> list[str]:
    return ["env-clone", a["stack"], a["source_env"], a["new_env"]]


def _args_lint_terraform(a: dict) -> list[str]:
    args = _stack_or_all("lint-tf", a)
    _bool_flag(args, a, "fix", "--fix")
    return args


def _args_compare_environments(a: dict) -> list[str]:
    args = ["compare", "--stack", a["stack"]]
    _opt(args, a, "envs", "--envs")
    return args


def _args_tfsec(a: dict) -> list[str]:
    args = _stack_or_all("tfsec", a, positional=True)
    _opt(args, a, "tool", "--tool")
    return args


def _args_cost(a: dict) -> list[str]:
    args = _stack_or_all("cost", a)
    _opt(args, a, "format", "--format")
    return args


def _args_upgrade_providers(a: dict) -> list[str]:
    args = _stack_or_all("upgrade", a)
    _bool_flag(args, a, "apply", "--apply")
    return args


def _args_bootstrap(a: dict) -> list[str]:
    args = ["bootstrap"]
    _bool_flag(args, a, "init_only", "--init-only")
    _bool_flag(args, a, "plan_only", "--plan-only")
    _bool_flag(args, a, "apply", "--apply")
    _bool_flag(args, a, "auto_approve", "--auto-approve")
    _opt(args, a, "ado_pat", "--ado-pat")
    _bool_flag(args, a, "keep_state", "--keep-state")
    _bool_flag(args, a, "cleanup_cache", "--cleanup-cache")
    return args


def _args_changelog(a: dict) -> list[str]:
    args = ["changelog"]
    _opt(args, a, "from_tag", "--from-tag")
    _opt(args, a, "to_tag", "--to-tag")
    _opt(args, a, "out", "--out")
    return args


# ---------------------------------------------------------------------------
# Dispatch table: tool_name → args builder
# ---------------------------------------------------------------------------

_DISPATCH: dict[str, Callable[[dict], list[str]]] = {
    # Discovery / status
    "list_stacks":          lambda _: ["list-stacks"],
    "stack_status":         lambda _: ["status"],
    "list_stack_templates": lambda _: ["list-stack-templates"],
    "list_modules":         lambda _: ["list-modules"],
    "doctor":               lambda _: ["doctor"],
    "update":               lambda _: ["update"],
    # Scaffolding / project management
    "init_project":         _args_init_project,
    "add_stack":            _args_add_stack,
    "add_stack_template":   _args_add_stack_template,
    "add_resource":         _args_add_resource,
    "rename_stack":         _args_rename_stack,
    "env_clone":            _args_env_clone,
    # Quality gates
    "validate_yaml":        lambda a: _stack_or_all("validate", a),
    "scan_secrets":         lambda a: _stack_or_all("secrets", a),
    "pr_check":             lambda a: _stack_or_all("pr-check", a, positional=True),
    "run_checklist":        lambda a: _stack_or_all("checklist", a),
    "lint_terraform":       _args_lint_terraform,
    "check_policy":         lambda a: _stack_or_all("policy", a, positional=True),
    "compare_environments": _args_compare_environments,
    "tfsec":                _args_tfsec,
    # Cost / providers
    "cost":                 _args_cost,
    "upgrade_providers":    _args_upgrade_providers,
    # Bootstrap / changelog
    "bootstrap":            _args_bootstrap,
    "changelog":            _args_changelog,
}


# ---------------------------------------------------------------------------
# Tool schema definitions
# ---------------------------------------------------------------------------

TOOLS: list[types.Tool] = [
    # ------------------------------------------------------------------
    # Discovery / status
    # ------------------------------------------------------------------
    types.Tool(
        name="list_stacks",
        description=(
            "List all infrastructure stacks in the project with their current readiness status. "
            "Use this to get an overview of what stacks exist and whether they are ready to deploy."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="stack_status",
        description=(
            "Show a live dashboard of every stack and its readiness: Terraform files, "
            "pipeline YAML, placeholder values, and environment tfvars."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="list_stack_templates",
        description=(
            "List all available pre-configured stack templates that can be applied to the project. "
            "Templates are starting points for common deployment patterns (e.g. ALZ, Databricks)."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="list_modules",
        description=(
            "List all available Terraform modules that can be added to stacks via add_resource. "
            "Shows module names and descriptions."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="doctor",
        description=(
            "Check the local environment is correctly set up to use ign. "
            "Verifies Python version, Terraform, Azure CLI, git, required Python packages, "
            "tfsec, and project directory structure."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="update",
        description=(
            "Check for a newer release of ign on GitHub and show the download URL. "
            "Does not modify anything; safe to run at any time."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),

    # ------------------------------------------------------------------
    # Scaffolding / project management
    # ------------------------------------------------------------------
    types.Tool(
        name="init_project",
        description=(
            "Initialise a brand-new infrastructure project with the full directory structure, "
            "bootstrap Terraform files, and CI/CD pipeline scaffolding.\n\n"
            "IMPORTANT: a cloud provider MUST be chosen before this runs — the interactive "
            "'Select Cloud Provider' menu ('1' = AWS, '2' = Azure) cannot be answered over MCP. "
            "If the user has not said which cloud they want, ask them first and pass the answer "
            "as 'cloud'. The scaffolding differs per cloud (directory layout, providers.tf, "
            "pipeline templates) and is written on disk, so guessing is not safe.\n\n"
            "For Azure, a CI/CD tool MUST also be chosen and passed as 'cicd' ('ado' = Azure DevOps "
            "Pipelines, 'github' = GitHub Actions). Ask the user if they have not said. GitHub "
            "Actions additionally needs 'github_org'.\n\n"
            "The other options are cloud-specific: 'location' applies to Azure only, "
            "'service_connection' to Azure DevOps only, 'github_*'/'cicd_repo'/'cicd_ref' to GitHub "
            "Actions only, and 'aws_region' to AWS only — the irrelevant ones are ignored."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "cloud": {
                    "type": "string",
                    "enum": ["aws", "azure"],
                    "description": (
                        "REQUIRED. Cloud provider to scaffold for. Corresponds to the 'ign init' "
                        "menu: '1' = aws (Amazon Web Services), '2' = azure (Microsoft Azure). "
                        "'1'/'2' are also accepted. Ask the user if not already known."
                    ),
                },
                "project_name":       {"type": "string", "description": "Name of the infrastructure project"},
                "project_code":       {"type": "string", "description": "Short project code, e.g. edp"},
                "location":           {"type": "string", "description": "Azure only: default Azure region (e.g. uksouth)"},
                "service_connection": {"type": "string", "description": "Azure only: Azure DevOps service connection name"},
                "aws_region":         {"type": "string", "description": "AWS only: AWS region (e.g. eu-west-2)"},
                "cicd": {
                    "type": "string",
                    "enum": ["ado", "github"],
                    "description": (
                        "REQUIRED for Azure. CI/CD tool: 'ado' (Azure DevOps Pipelines) or 'github' "
                        "(GitHub Actions with reusable workflows + OIDC). AWS projects always use ado."
                    ),
                },
                "github_org":  {"type": "string", "description": "GitHub only: organisation owning the repos"},
                "github_repo": {"type": "string", "description": "GitHub only: name of this infrastructure repo (trusted by the OIDC federated credentials)"},
                "cicd_repo":   {"type": "string", "description": "GitHub only: shared CI/CD templates repo name (default terraform-azure-cicd)"},
                "cicd_ref":    {"type": "string", "description": "GitHub only: tag/branch/SHA of the CI/CD repo to pin (default main)"},
            },
            "required": ["cloud"],
        },
    ),
    types.Tool(
        name="add_stack",
        description=(
            "Add a new blank deployment stack to an existing project. "
            "Generates Terraform files, pipeline YAML, and tfvars for each environment."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack_name":          {"type": "string", "description": "Name of the new stack (e.g. dlz, dmz)"},
                "description":         {"type": "string", "description": "Brief description of what the stack does"},
                "service_connection":  {"type": "string", "description": "Azure DevOps service connection name"},
                "include_databricks":  {"type": "boolean", "description": "Include Databricks workspace resources"},
                "include_storage":     {"type": "boolean", "description": "Include storage account resources"},
                "include_keyvault":    {"type": "boolean", "description": "Include Key Vault resources"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="add_stack_template",
        description=(
            "Copy a pre-configured stack template from the templates library into the project's "
            "stacks/ directory. Use list_stack_templates first to see available templates."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack_name": {"type": "string", "description": "Name of the stack template to add"},
            },
            "required": ["stack_name"],
        },
    ),
    types.Tool(
        name="add_resource",
        description=(
            "Add a Terraform module/resource to an existing stack. "
            "Use list_modules to see all available resource types before calling this."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack_name":     {"type": "string", "description": "Name of the stack to add the resource to"},
                "resource_type":  {"type": "string", "description": "Resource type (run list_modules to see options)"},
                "resource_name":  {"type": "string", "description": "Name for the new resource instance"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="rename_stack",
        description=(
            "Rename a stack: moves its folder and updates all internal file references "
            "(pipeline YAML, tfvars, README) to use the new name."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "old_name": {"type": "string", "description": "Current stack name"},
                "new_name": {"type": "string", "description": "Desired new stack name"},
            },
            "required": ["old_name", "new_name"],
        },
    ),
    types.Tool(
        name="env_clone",
        description=(
            "Clone an environment's tfvars file into a new environment for a stack. "
            "Example: clone dev → staging to create a new staging environment."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack":      {"type": "string", "description": "Stack name"},
                "source_env": {"type": "string", "description": "Source environment (e.g. dev)"},
                "new_env":    {"type": "string", "description": "New environment name to create (e.g. staging)"},
            },
            "required": ["stack", "source_env", "new_env"],
        },
    ),

    # ------------------------------------------------------------------
    # Quality gates
    # ------------------------------------------------------------------
    types.Tool(
        name="validate_yaml",
        description=(
            "Lint YAML pipeline files in a stack or across the entire project. "
            "Reports syntax errors, trailing spaces, and formatting issues."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit to scan all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to scan the whole project"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="scan_secrets",
        description=(
            "Scan Terraform and config files for accidentally committed secrets, credentials, "
            "hardcoded passwords, SAS tokens, and real Azure subscription/tenant IDs."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit to scan all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to scan the whole project"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="pr_check",
        description=(
            "Run all quality gates in sequence: YAML validate → Terraform lint → secret scan → "
            "pre-deployment checklist. Returns a pass/fail result per gate. "
            "Use before raising a pull request to catch issues early."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit for all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to check all stacks"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="run_checklist",
        description=(
            "Run the pre-deployment readiness checklist for a stack. "
            "Checks required files exist, placeholder UUIDs are replaced, "
            "YAML is valid, and the service connection has been customised."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit to check all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to check all stacks"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="lint_terraform",
        description=(
            "Run terraform fmt (formatting check) and terraform validate on one or all stacks. "
            "Pass fix=true to automatically reformat files rather than just reporting issues."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit for all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to lint all stacks"},
                "fix":   {"type": "boolean", "description": "Auto-reformat instead of just reporting"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="check_policy",
        description=(
            "Check Terraform files against house policy rules: required tags on all resources, "
            "no unrestricted public IPs, storage account soft-delete configured, "
            "and no hardcoded environment names in resource names."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit for all stacks"},
                "all":   {"type": "boolean", "description": "Set to true to check all stacks"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="compare_environments",
        description=(
            "Diff the tfvars files across environments (dev, tst, uat, prd) for a stack. "
            "Highlights keys that are missing or have different values between environments. "
            "Optionally restrict to a subset of environments with envs."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name"},
                "envs":  {"type": "string", "description": "Comma-separated envs to compare, e.g. dev,prd (default: all)"},
            },
            "required": ["stack"],
        },
    ),
    types.Tool(
        name="tfsec",
        description=(
            "Run tfsec or checkov security scanner on Terraform code and display findings grouped "
            "by severity. Auto-detects the available tool; use tool to force one."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit to scan all stacks"},
                "all":   {"type": "boolean", "description": "Scan all stacks"},
                "tool":  {"type": "string", "enum": ["tfsec", "checkov"], "description": "Force a specific scanner"},
            },
            "required": [],
        },
    ),

    # ------------------------------------------------------------------
    # Cost / providers
    # ------------------------------------------------------------------
    types.Tool(
        name="cost",
        description=(
            "Estimate infrastructure costs for a stack or the whole project using Infracost. "
            "Requires Infracost to be installed (https://www.infracost.io/docs/)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack":  {"type": "string", "description": "Stack name, or omit for all stacks"},
                "all":    {"type": "boolean", "description": "Estimate costs for all stacks"},
                "format": {"type": "string", "enum": ["table", "json", "html"], "description": "Output format (default: table)"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="upgrade_providers",
        description=(
            "Check Terraform provider versions against the registry for one or all stacks. "
            "Pass apply=true to write updated version constraints back to providers.tf."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "stack": {"type": "string", "description": "Stack name, or omit for all stacks"},
                "all":   {"type": "boolean", "description": "Check all stacks"},
                "apply": {"type": "boolean", "description": "Write updated versions to providers.tf"},
            },
            "required": [],
        },
    ),

    # ------------------------------------------------------------------
    # Bootstrap / changelog
    # ------------------------------------------------------------------
    types.Tool(
        name="bootstrap",
        description=(
            "Bootstrap foundational Terraform state infrastructure: resource groups, storage "
            "accounts, managed identities, and Azure DevOps service connections. "
            "Configuration is read from bootstrap/terraform/config.yaml. "
            "Typical flow: init_only=true → plan_only=true → apply=true."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "init_only":     {"type": "boolean", "description": "Only run terraform init"},
                "plan_only":     {"type": "boolean", "description": "Only run terraform plan"},
                "apply":         {"type": "boolean", "description": "Run terraform apply after plan"},
                "auto_approve":  {"type": "boolean", "description": "Skip confirmation prompts for apply"},
                "ado_pat":       {"type": "string",  "description": "Azure DevOps PAT token (never stored)"},
                "keep_state":    {"type": "boolean", "description": "Keep the Terraform state file after apply"},
                "cleanup_cache": {"type": "boolean", "description": "Delete .terraform provider cache after apply"},
            },
            "required": [],
        },
    ),
    types.Tool(
        name="changelog",
        description=(
            "Generate a CHANGELOG from GitHub release notes between two tags. "
            "Omit both tags to get the most recent release notes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "from_tag": {"type": "string", "description": "Start tag (exclusive); defaults to previous release"},
                "to_tag":   {"type": "string", "description": "End tag (inclusive); defaults to latest release"},
                "out":      {"type": "string", "description": "Write output to this file path instead of returning it"},
            },
            "required": [],
        },
    ),
]


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

server = Server("ign")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    # Use native (no-subprocess) handler when available — much faster.
    native = _NATIVE.get(name)
    if native is not None:
        try:
            out = await asyncio.get_event_loop().run_in_executor(None, native)
        except Exception as exc:
            out = f"ERROR: {exc}"
        return [types.TextContent(type="text", text=out)]

    builder = _DISPATCH.get(name)
    if builder is None:
        return [types.TextContent(type="text", text=f"Unknown tool: {name}")]

    # Commands that run `terraform apply` against real infrastructure must never
    # be killed mid-run, so they get no timeout. Other terraform/scanner
    # commands may be slow on a cold cache (provider downloads, init) but are
    # safe to interrupt — give them a generous window. Lightweight CLI wrappers
    # get a short cap so slow starts / hangs surface quickly.
    _apply = {"bootstrap"}
    _heavy = {"tfsec", "cost", "upgrade_providers", "lint_terraform", "pr_check"}
    if name in _apply:
        timeout: int | None = None
    elif name in _heavy:
        timeout = 900
    else:
        timeout = 60

    # The low-level MCP Server doesn't validate arguments against inputSchema,
    # so a missing required field would raise inside the builder. Return a clean
    # message instead of letting the exception escape call_tool.
    try:
        cmd_args = builder(arguments)
    except KeyError as exc:
        return [types.TextContent(type="text", text=f"ERROR: missing required argument {exc}")]
    except Exception as exc:
        return [types.TextContent(type="text", text=f"ERROR: {exc}")]

    out = await _run_ign(cmd_args, timeout=timeout)
    return [types.TextContent(type="text", text=out)]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def _main() -> None:
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
