#!/usr/bin/env python3
"""
Infrastructure CLI Tool
A CLI for DevOps engineers to scaffold infrastructure projects and manage deployment stacks.
"""

import click
import json
import re
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path
from typing import Dict, List, Optional



# Read version from VERSION file
def get_version():
    """Read version from VERSION file."""
    # Try multiple locations for VERSION file
    locations = [
        Path(__file__).parent / 'VERSION',  # When running from source
        Path(__file__).resolve().parent / 'VERSION',  # When running as script
    ]
    
    for version_file in locations:
        if version_file.exists():
            try:
                return version_file.read_text(encoding='utf-8').strip()
            except Exception:
                pass
    
    # If VERSION file not found, try to get from package metadata
    try:
        import importlib.metadata
        return importlib.metadata.version('ign')
    except Exception:
        pass
    
    return '0.0.0'

__version__ = get_version()


class InfrastructureCLI:
    """Main CLI class for infrastructure project management."""
    
    def __init__(self):
        self.project_root = Path.cwd()
    
    def create_directory(self, path: Path) -> None:
        """Create directory if it doesn't exist."""
        path.mkdir(parents=True, exist_ok=True)
        try:
            rel_path = path.resolve().relative_to(self.project_root)
            console.print(f"  [dim]📁 {rel_path}[/dim]")
        except ValueError:
            console.print(f"  [dim]📁 {path}[/dim]")
    
    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        try:
            rel_path = path.resolve().relative_to(self.project_root)
            console.print(f"  [dim]📄 {rel_path}[/dim]")
        except ValueError:
            console.print(f"  [dim]📄 {path}[/dim]")
    
    def load_template(self, template_path: str, **kwargs) -> str:
        """Load a template file and replace placeholders with provided values."""
        import sys
        
        locations = []
        
        # Check local sibling repo tf-iac-modules first if template starts with 'resources/'
        if template_path.startswith('resources/'):
            sub_path = template_path[len('resources/'):]
            for parent_level in [Path(__file__).resolve().parents[3], Path(__file__).resolve().parents[2], Path.cwd().parent, Path.cwd()]:
                locations.append(parent_level / 'tf-iac-modules' / sub_path)

        # Then try standard locations
        locations.extend([
            # 1. Development: next to ignition.py
            Path(__file__).parent / template_path,
            # 2. Current working directory
            Path(template_path),
            # 3. Installed package: sys.prefix (for pip/uv install)
            Path(sys.prefix) / template_path,
            # 4. User install: site.USER_BASE
            Path(sys.prefix).parent / template_path,
        ])

        template_file = None
        for location in locations:
            if location.exists():
                template_file = location
                break
        
        if not template_file:
            # List tried locations for debugging
            tried = '\n  '.join(str(loc) for loc in locations)
            raise FileNotFoundError(
                f"Template not found: {template_path}\n"
                f"Tried locations:\n  {tried}"
            )
        
        template_content = template_file.read_text(encoding='utf-8')
        
        # Replace placeholders if any kwargs provided
        if kwargs:
            for key, value in kwargs.items():
                val_str = str(value)
                template_content = template_content.replace(f"{{{key}}}", val_str)
                template_content = template_content.replace(f"<{key}>", val_str)
                title_key = key.replace('_', ' ').title()
                template_content = template_content.replace(f"{{{title_key}}}", val_str)
                template_content = template_content.replace(f"<{title_key}>", val_str)
        
        return template_content


console = Console(force_terminal=True, legacy_windows=False)

# Initialize CLI
cli_helper = InfrastructureCLI()


# Stacks live in one of two locations: regular stacks under stacks/, and ALZ
# (Azure Landing Zone) stacks — whose names start with "alz" — under
# landing-zones/ (see add_stack_template). These helpers are the single source
# of truth for locating a stack by name and for enumerating every stack,
# regardless of which directory it lives in.
STACK_DIRS = ('stacks', 'landing-zones')


def _resolve_stack_dir(name: str, root: Optional[Path] = None) -> Optional[Path]:
    """Return the directory for a stack by name, searching both stacks/ and
    landing-zones/. Returns None if the stack isn't found in either location."""
    base = root or Path.cwd()
    for parent in STACK_DIRS:
        candidate = base / parent / name
        if candidate.is_dir():
            return candidate
    return None


def _iter_all_stacks(root: Optional[Path] = None) -> List[Path]:
    """Return the directories of every stack across stacks/ and landing-zones/,
    sorted by stack name."""
    base = root or Path.cwd()
    found = []
    for parent in STACK_DIRS:
        parent_dir = base / parent
        if parent_dir.is_dir():
            found.extend(d for d in parent_dir.iterdir() if d.is_dir())
    return sorted(found, key=lambda p: p.name)


# tfvars files are named per "target": either a lifecycle environment
# (dev/tst/uat/prd for regular stacks) or a region (uks/ukw/... for ALZ landing
# zones, which are deployed per-region rather than per-lifecycle-env). We
# auto-discover whatever <target>.tfvars files exist rather than assuming a
# fixed set, so both conventions work.

# Lifecycle names in promotion order — used only to order comparison columns
# nicely. Anything not listed (region codes, etc.) still works; it just sorts
# after these, alphabetically.
_ENV_ORDER = [
    "dev", "tst", "test", "sit", "uat", "stg", "stage", "staging",
    "preprod", "ppd", "ppe", "prd", "prod",
]

# Azure region abbreviations — the full set from the AVM Terraform library
# standard (ref: https://www.jlaundry.nz/2022/azure_region_abbreviations/).
# Used to recognise region-based tfvars values in env-clone. compare does not
# depend on this list — it discovers tfvars files directly — so an unlisted
# code still works there.
_CAF_REGION_ABBRS = {
    # Australia / Austria
    "acl", "acl2", "ae", "ase", "aue",
    # Belgium / Brazil
    "bec", "brs", "bse", "bru",
    # Canada
    "cnc", "cne",
    # India
    "inc", "ins", "inw", "jic", "jiw",
    # United States (incl. EUAP)
    "cus", "ccy", "eus", "eus2", "ecy", "ncus", "scus", "wcus",
    "wus", "wus2", "wus3",
    # Chile / Denmark
    "clc", "dke",
    # Asia
    "ea", "sea",
    # France
    "frc", "frs",
    # Germany (public + legacy sovereign)
    "gn", "gwc", "gec", "gne",
    # Indonesia / Israel / Italy
    "idc", "ilc", "itn",
    # Japan / Korea
    "jpe", "jpw", "krc", "krs",
    # Malaysia / Mexico / New Zealand
    "mys", "myw", "mxc", "nzn",
    # Europe / Norway / Poland / Qatar
    "ne", "we", "nwe", "nww", "plc", "qac",
    # South Africa / Spain / Sweden / Switzerland
    "san", "saw", "spc", "sdc", "sds", "szn", "szw",
    # UAE / UK
    "uac", "uan", "uks", "ukw",
    # China (sovereign)
    "sha", "cne2", "sha3", "bjb", "cnn2", "bjb3",
    # US Government / DoD / Nat / Sec (sovereign)
    "udc", "ude", "uga", "ugi", "ugtx", "ugva", "exe", "exw", "rxe", "rxw",
}


def _is_env_tfvars(name: str) -> bool:
    """True if a filename is an environment/region tfvars file — i.e. a
    ``<target>.tfvars`` that is not one of Terraform's auto-loaded specials
    (``terraform.tfvars`` / ``*.auto.tfvars``)."""
    lower = name.lower()
    if not lower.endswith(".tfvars"):
        return False
    if lower == "terraform.tfvars" or lower.endswith(".auto.tfvars"):
        return False
    return True


def _env_sort_key(target: str):
    """Order lifecycle envs first (by promotion order), then everything else
    (region codes, etc.) alphabetically."""
    low = target.lower()
    return (_ENV_ORDER.index(low) if low in _ENV_ORDER else len(_ENV_ORDER), low)


def _discover_env_tfvars(tfvars_dir: Path) -> List[str]:
    """Return the sorted list of environment/region targets (tfvars stems)
    present in a directory (e.g. ['dev','prd'] or ['uks','ukw'])."""
    stems = {p.stem for p in tfvars_dir.glob("*.tfvars") if _is_env_tfvars(p.name)}
    return sorted(stems, key=_env_sort_key)


@click.group()
@click.version_option(version=__version__)
def cli():
    """
    Infrastructure CLI - Scaffold and manage infrastructure projects.
    
    Use this tool to:
    - Initialize new infrastructure projects
    - Add new deployment stacks to existing projects
    - Manage CI/CD pipeline configurations
    """
    pass


def _prompt_cloud_provider() -> str:
    """Display a styled cloud provider selection menu and return 'aws' or 'azure'."""
    console.print()
    console.print(Panel(
        "  [bold]1.[/bold]  [bold #FF9900]⬡  AWS[/bold #FF9900]          [dim]Amazon Web Services[/dim]\n"
        "  [bold]2.[/bold]  [bold #0078D4]◆  Azure[/bold #0078D4]        [dim]Microsoft Azure[/dim]",
        title="[bold cyan]☁  Select Cloud Provider[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    choice = click.prompt(
        "  Cloud provider",
        type=click.Choice(['1', '2', 'aws', 'azure'], case_sensitive=False),
        show_choices=False,
    )
    return 'aws' if choice in ('1', 'aws') else 'azure'


CICD_LABELS = {
    'ado': "[bold #0078D4]⚙  Azure DevOps Pipelines[/bold #0078D4]",
    'github': "[bold white]⬢  GitHub Actions[/bold white]",
}

# Project-level settings written by `ign init` so later commands (add-stack,
# rename-stack, checklist, ...) know which CI/CD flavour the project uses.
PROJECT_SETTINGS_FILE = '.ignition.json'

DEFAULT_CICD_REPO = 'terraform-azure-cicd'
DEFAULT_CICD_REF = 'main'


def _prompt_cicd_platform() -> str:
    """Display a styled CI/CD tool selection menu and return 'ado' or 'github'."""
    console.print()
    console.print(Panel(
        "  [bold]1.[/bold]  [bold #0078D4]⚙  Azure DevOps[/bold #0078D4]    [dim]Azure Pipelines (ADO)[/dim]\n"
        "  [bold]2.[/bold]  [bold white]⬢  GitHub Actions[/bold white]  [dim]Reusable workflows + OIDC[/dim]",
        title="[bold cyan]🔁  Select CI/CD Tool[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    choice = click.prompt(
        "  CI/CD tool",
        type=click.Choice(['1', '2', 'ado', 'github'], case_sensitive=False),
        show_choices=False,
    )
    return 'ado' if choice in ('1', 'ado') else 'github'


def _load_project_settings(root: Optional[Path] = None) -> Dict[str, str]:
    """Read .ignition.json from the project root (empty dict if absent/invalid)."""
    path = (root or Path.cwd()) / PROJECT_SETTINGS_FILE
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
        except (OSError, ValueError):
            pass
    return {}


def _save_project_settings(settings: Dict[str, str]) -> None:
    cli_helper.write_file(Path(PROJECT_SETTINGS_FILE), json.dumps(settings, indent=2) + '\n')


def _detect_cicd_platform(root: Optional[Path] = None) -> str:
    """Return the project's CI/CD platform ('ado' or 'github').

    Prefers .ignition.json; falls back to the GitHub scaffold written by init,
    and otherwise assumes Azure DevOps (the behaviour before GitHub support)."""
    base = root or Path.cwd()
    cicd = str(_load_project_settings(base).get('cicd', '')).lower()
    if cicd in ('ado', 'github'):
        return cicd
    if (base / 'templates' / 'scaffold' / 'github' / 'stack-workflow.yml').exists():
        return 'github'
    return 'ado'


def _stack_pipeline_file(stack_path: Path, root: Optional[Path] = None) -> Path:
    """Path of the CI/CD definition for a stack, for the project's platform."""
    base = root or Path.cwd()
    if _detect_cicd_platform(base) == 'github':
        return base / '.github' / 'workflows' / f'{stack_path.name}.yml'
    return stack_path / 'azure-pipelines.yml'


@cli.command()
@click.option('--cloud', type=click.Choice(['aws', 'azure'], case_sensitive=False), default=None, help='Cloud provider (aws or azure)')
@click.option('--cicd', type=click.Choice(['ado', 'github'], case_sensitive=False), default=None, help='CI/CD tool: ado (Azure DevOps) or github (GitHub Actions, Azure only)')
@click.option('--project-name', default=None, help='Name of the infrastructure project')
@click.option('--location', default=None, help='Default Azure location (Azure only, default: uksouth)')
@click.option('--aws-region', default=None, help='AWS region (AWS only, default: eu-west-2)')
@click.option('--project-code', default=None, help='Short project code (e.g., edp)')
@click.option('--service-connection', default=None, help='Azure DevOps service connection name (ADO only)')
@click.option('--github-org', default=None, help='GitHub organisation that owns the repos (GitHub only)')
@click.option('--github-repo', default=None, help='Name of this infrastructure repository on GitHub (GitHub only)')
@click.option('--cicd-repo', default=None, help=f'Shared CI/CD templates repository name (GitHub only, default: {DEFAULT_CICD_REPO})')
@click.option('--cicd-ref', default=None, help=f'Tag/branch/SHA of the shared CI/CD repo to pin (GitHub only, default: {DEFAULT_CICD_REF})')
@click.option('--ign-wheel', default=None, envvar='IGN_WHEEL',
              type=click.Path(exists=True, dir_okay=False, resolve_path=True),
              help='Optional: a different ign-<version>-py3-none-any.whl to add to .devcontainer/wheels/ '
                   '(a wheel is bundled by default). Env: IGN_WHEEL')
def init(cloud: str, cicd: str, project_name: str, location: str, aws_region: str, project_code: str,
         service_connection: str, github_org: str, github_repo: str, cicd_repo: str, cicd_ref: str,
         ign_wheel: Optional[str]):
    """Initialize a new infrastructure project with full structure."""

    if not cloud:
        cloud = _prompt_cloud_provider()
    cloud = cloud.lower()

    if cloud == 'aws':
        if cicd and cicd.lower() == 'github':
            console.print("[bold red]❌  GitHub Actions templates are currently Azure-only.[/bold red] "
                          "Use [bold]--cicd ado[/bold] for AWS projects.")
            return
        cicd = 'ado'
    elif not cicd:
        cicd = _prompt_cicd_platform()
    cicd = cicd.lower()

    if not project_name:
        project_name = click.prompt('  Project name')
    if not project_code:
        project_code = click.prompt('  Project code', default='edp')

    if cloud == 'azure':
        if not location:
            location = click.prompt('  Azure location', default='uksouth')
        if cicd == 'ado':
            if not service_connection:
                service_connection = click.prompt('  Service connection', default='DataPlatform - Dev')
        else:
            service_connection = None
            if not github_org:
                github_org = click.prompt('  GitHub organisation')
            if not github_repo:
                default_repo = re.sub(r'[^A-Za-z0-9._-]+', '-', project_name).strip('-').lower() or project_code
                github_repo = click.prompt('  GitHub repository (this infra repo)', default=default_repo)
            if not cicd_repo:
                cicd_repo = click.prompt('  Shared CI/CD templates repo', default=DEFAULT_CICD_REPO)
            if not cicd_ref:
                cicd_ref = click.prompt('  CI/CD repo ref to pin (tag/branch/SHA)', default=DEFAULT_CICD_REF)
        region_display = location
    else:
        if not aws_region:
            aws_region = click.prompt('  AWS region', default='eu-west-2')
        location = None
        service_connection = None
        region_display = aws_region

    cloud_label = (
        "[bold #FF9900]⬡  AWS[/bold #FF9900]"
        if cloud == 'aws'
        else "[bold #0078D4]◆  Azure[/bold #0078D4]"
    )

    console.print()
    console.print(Panel(
        f"[bold white]Cloud:[/bold white]    {cloud_label}\n"
        f"[bold white]CI/CD:[/bold white]    {CICD_LABELS[cicd]}\n"
        f"[bold white]Project:[/bold white]  [cyan]{project_name}[/cyan]\n"
        f"[bold white]Region:[/bold white]   [cyan]{region_display}[/cyan]  "
        f"[bold white]Code:[/bold white] [cyan]{project_code}[/cyan]"
        + (f"\n[bold white]GitHub:[/bold white]   [cyan]{github_org}/{github_repo}[/cyan]  "
           f"[bold white]CI/CD repo:[/bold white] [cyan]{github_org}/{cicd_repo}@{cicd_ref}[/cyan]"
           if cicd == 'github' else ''),
        title="[bold cyan]🚀  Initializing Infrastructure Project[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()

    # Create base directory structure
    if cicd == 'github':
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            '.github/workflows',
            'scripts',
            'templates/scaffold/terraform',
            'templates/scaffold/github',
            'templates/scripts',
            'templates/utils',
            'templates/tests/scripts',
        ]
    elif cloud == 'aws':
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            'templates/scaffold/terraform',
            'templates/scaffold/yaml',
            'templates/scripts',
            'templates/yaml',
            'templates/utils',
            'templates/tests/scripts',
        ]
    else:
        base_dirs = [
            'stacks',
            'bootstrap/terraform',
            'templates/scaffold/terraform',
            'templates/scaffold/yaml',
            'templates/scripts',
            'templates/yaml',
            'templates/yaml/build',
            'templates/yaml/deploy',
            'templates/utils',
            'templates/tests/config/lint',
            'templates/tests/config/leaks',
            'templates/tests/scripts',
        ]
    
    for dir_path in base_dirs:
        cli_helper.create_directory(Path(dir_path))
    
    # Create root Makefile
    makefile_content = """# Infrastructure Makefile

#
# Makefile
#

TEST?=$$(go list ./... |grep -v 'vendor'|grep -v 'utils')

# Azure Pipelines

azp-strategy:
	@echo "==> Running script..."
	./templates/scripts/azp-strategy.ps1

azp-backend:
	@echo "==> Running script..."
	./templates/scripts/azp-backend.sh

azp-spn-generator:
	@echo "==> Running script..."
	./templates/scripts/azp-spn-generator.sh

# Terraform

tf-install:
	@echo "==> Running script..."
	./templates/scripts/tf-install.sh

tf-prepare:
	@echo "==> Running script..."
	./templates/scripts/tf-prepare.sh

tf-fmt:
	@echo "==> Running script..."
	./templates/scripts/tf-fmt.sh

tf-validate:
	@echo "==> Running script..."
	./templates/scripts/tf-validate.sh

tf-init:
	@echo "==> Running script..."
	./templates/scripts/tf-init.sh

tf-plan:
	@echo "==> Running script..."
	./templates/scripts/tf-plan.sh

tf-apply:
	@echo "==> Running script..."
	./templates/scripts/tf-apply.sh

tf-destroy:
	@echo "==> Running script..."
	./templates/scripts/tf-destroy.sh

# Terratest

terratest:
	@echo "==> Running Go test..."
	cd tests/terratest && go test $(TEST) $(TESTARGS) -run ^$(TESTPREFIX)

# OPA Conftest

opa-install:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-install-linux.sh

opa-run-tests:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-run-tests.sh

opa-update-values:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-update-values.ps1 -GENERATE_AUTO_TFVARS

opa-update-git:
	@echo "==> Running script..."
	./templates/tests/scripts/opa-update-git.sh

docs:
	terraform-docs .

.PHONY: azp-strategy azp-backend azp-spn-generator docs tf-install tf-prepare tf-fmt tf-validate tf-init tf-plan tf-apply tf-destroy terratest opa-install opa-run-tests opa-update-values opa-update-git
"""
    cli_helper.write_file(Path('Makefile'), makefile_content)
    
    # Create root README
    if cloud == 'aws':
        cloud_prereqs = "- AWS CLI\n- Terraform >= 1.5.0\n- AWS IAM access with appropriate permissions"
        cloud_cicd = (
            "Each stack includes CI/CD configuration for automated deployments:\n\n"
            "- **Build**: Validates and plans Terraform changes\n"
            "- **Deploy**: Applies Terraform configurations to target environments\n"
            "- **State**: Manages Terraform state in S3"
        )
        cloud_config_section = f"### Region\n\nDefault region: `{aws_region}`"
    elif cicd == 'github':
        cloud_prereqs = (
            "- Azure CLI\n"
            "- Terraform >= 1.5.0\n"
            "- GitHub CLI (`gh`) and access to the GitHub organisation"
        )
        cloud_cicd = (
            "Each stack has a caller workflow in `.github/workflows/<stack>.yml` that uses the shared "
            f"reusable pipeline in [`{github_org}/{cicd_repo}`](https://github.com/{github_org}/{cicd_repo}) "
            f"(pinned to `{cicd_ref}`):\n\n"
            "- **CI**: `terraform init`, `fmt`, `validate` and a Checkov scan\n"
            "- **Plan**: plan uploaded as an artifact and posted to the pull request\n"
            "- **Apply**: applies the reviewed plan on `develop` (dev) / `main` (prd), gated by the "
            "`<env>/apply` GitHub environment\n"
            "- **Auth**: OIDC federated credentials to Azure - no stored secrets\n"
            "- **State**: Terraform state in Azure Storage (azurerm backend)\n\n"
            "| Branch / event | Environment | Apply |\n"
            "|---|---|---|\n"
            "| `feature/**` push, PR into `develop` | `dev` | no |\n"
            "| `develop` push | `dev` | yes |\n"
            "| PR into `main` | `prd` | no |\n"
            "| `main` push | `prd` | yes |"
        )
        cloud_config_section = (
            "### GitHub Environments\n\n"
            "Create the `dev`, `dev/apply`, `prd` and `prd/apply` environments and set the "
            "`AZURE_*` / `TF_STATE_*` variables on each. `ign bootstrap` prints the exact "
            "`gh variable set` commands; `scripts/setup-github-oidc.ps1` is an alternative "
            "if you are not using bootstrap. Add required reviewers to the `*/apply` environments."
        )
    else:
        cloud_prereqs = (
            "- Azure CLI\n"
            "- Terraform >= 1.5.0\n"
            "- Azure DevOps access with appropriate permissions"
        )
        cloud_cicd = (
            "Each stack includes Azure Pipelines configuration for automated deployments:\n\n"
            "- **Build**: Validates and plans Terraform changes\n"
            "- **Deploy**: Applies Terraform configurations to target environments\n"
            "- **State**: Manages Terraform state in Azure Storage"
        )
        cloud_config_section = (
            f"### Service Connections\n\n"
            f"Configure service connections in Azure DevOps:\n"
            f"- Service Connection: `{service_connection}`"
        )

    if cicd == 'github':
        structure_extra = "├── .github/workflows/   # One caller workflow per stack\n├── scripts/             # setup-github-oidc.ps1 (manual OIDC setup)\n"
        structure_yaml = ""
    else:
        structure_extra = ""
        structure_yaml = "│   ├── yaml/            # CI/CD pipeline templates\n"

    readme_content = f"""# {project_name} Infrastructure

This repository contains Infrastructure as Code (IaC) for the {project_name} project.

## Project Structure

```
.
├── stacks/              # Deployment stacks (dlz, dmz, unity-catalog, etc.)
{structure_extra}├── templates/           # Reusable templates and utilities
│   ├── scaffold/        # Stack scaffolding templates
│   ├── scripts/         # Terraform scripts called by the Makefile / pipelines
│   ├── utils/           # Terraform utility modules
{structure_yaml}│   └── tests/           # Testing configurations
└── Makefile            # Common operations
```

## Getting Started

### Prerequisites

{cloud_prereqs}

### Adding a New Stack

Use the CLI to add a new deployment stack:

```bash
ign add-stack --stack-name <name>
```

### Manual Deployment

1. Navigate to the stack directory:
   ```bash
   cd stacks/<stack-name>/terraform
   ```

2. Initialize Terraform:
   ```bash
   terraform init
   ```

3. Plan the deployment:
   ```bash
   terraform plan -var-file="tfvars/dev.tfvars"
   ```

4. Apply the changes:
   ```bash
   terraform apply -var-file="tfvars/dev.tfvars"
   ```

## CI/CD Pipelines

{cloud_cicd}

## Configuration

### Environment Variables

Each stack supports multiple environments:
- `dev` - Development
- `tst` - Test
- `uat` - User Acceptance Testing
- `prd` - Production

{cloud_config_section}

## Contributing

1. Create a feature branch
2. Make your changes
3. Test locally
4. Submit a pull request

## Support

For questions or issues, contact the DevOps team.
"""
    cli_helper.write_file(Path('README.md'), readme_content)

    if cloud == 'aws':
        create_aws_utils_module()
        create_aws_pipeline_templates(aws_region)
        create_aws_scaffold_templates()
    elif cicd == 'github':
        create_utils_module(project_code)
        create_scaffold_templates(include_yaml=False)
        create_github_pipeline_templates(github_org, cicd_repo, cicd_ref, github_repo)
    else:
        create_utils_module(project_code)
        create_pipeline_templates()
        create_scaffold_templates()

    # Copy script templates (same for both clouds / CI/CD tools)
    copy_script_templates()

    # Standard dev container so the cloned repo opens with ign and the tooling installed
    create_devcontainer(ign_wheel)

    # Create bootstrap configuration (Azure-specific; AWS generates a minimal placeholder)
    if cloud == 'azure':
        create_bootstrap_config(project_code, location, project_name, cicd=cicd,
                                github_org=github_org, github_repo=github_repo,
                                cicd_repo=cicd_repo)
    else:
        _create_aws_bootstrap_config(project_code, aws_region, project_name)

    settings = {'cloud': cloud, 'cicd': cicd}
    if cicd == 'github':
        settings.update({
            'github_org': github_org,
            'github_repo': github_repo,
            'cicd_repo': cicd_repo,
            'cicd_ref': cicd_ref,
        })
    _save_project_settings(settings)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", "Review the generated structure")
    if cicd == 'github':
        grid.add_row("2.", f"Create the shared CI/CD repo if it doesn't exist: [bold]ign init-cicd-repo --github-org {github_org} --cicd-repo {cicd_repo}[/bold]")
        grid.add_row("3.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your subscription IDs")
        grid.add_row("4.", "Run bootstrap: [bold]ign bootstrap --apply[/bold]  then run the printed [bold]gh variable set[/bold] commands")
        grid.add_row("5.", "Add your first stack: [bold]ign add-stack[/bold]  (creates [bold].github/workflows/<stack>.yml[/bold])")
        console.print()
        console.print(Panel(grid, title="[bold green]✅  Project Initialized Successfully![/bold green]", title_align="left", style="green", expand=False))
        console.print()
        return
    if cloud == 'azure':
        grid.add_row("2.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your subscription IDs")
        grid.add_row("3.", "Run bootstrap: [bold]ign bootstrap --plan-only[/bold]  (or [bold]--apply[/bold])")
    else:
        grid.add_row("2.", "Configure bootstrap: Edit [bold]bootstrap/terraform/config.yaml[/bold] with your AWS account details")
        grid.add_row("3.", "Run bootstrap: [bold]ign bootstrap --plan-only[/bold]  (or [bold]--apply[/bold])")
    grid.add_row("4.", "Add your first stack: [bold]ign add-stack[/bold]")
    grid.add_row("5.", "Customize templates in the [bold]templates/[/bold] directory")
    console.print(Panel(grid, title="[bold green]✅  Project Initialized Successfully![/bold green]", title_align="left", style="green", expand=False))
    console.print()


DEVCONTAINER_DIR = Path('.devcontainer')


_BINARY_SUFFIXES = {'.whl'}


def _render_devcontainer(target: Path, include_binary: bool = True) -> int:
    """Copy the bundled dev container (resources/templates/devcontainer) to target/.devcontainer.

    This includes the Ignition CLI wheel in wheels/, so the container installs ign offline
    (client environments cannot reach the Telefónica Tech GitHub releases).
    include_binary=False skips binary files such as the wheel.

    Returns the file count (0 if the templates are not in the installed package).
    Files are copied verbatim - devcontainer.json uses ${...} variables that must not be substituted."""
    import shutil

    source = _find_resource_dir('resources/templates/devcontainer')
    if source is None:
        return 0
    count = 0
    for src in sorted(source.rglob('*')):
        if not src.is_file() or '__pycache__' in src.parts:
            continue
        binary = src.suffix.lower() in _BINARY_SUFFIXES
        if binary and not include_binary:
            continue
        out = target / DEVCONTAINER_DIR / src.relative_to(source)
        out.parent.mkdir(parents=True, exist_ok=True)
        if binary:
            shutil.copyfile(src, out)
        else:
            # LF endings: post-create.sh runs inside a Linux container.
            with open(out, 'w', encoding='utf-8', newline='\n') as fh:
                fh.write(src.read_text(encoding='utf-8'))
        count += 1
    return count


DEVCONTAINER_WHEELS_DIR = DEVCONTAINER_DIR / 'wheels'


def _copy_ign_wheel(wheel: Optional[str]) -> None:
    """Optional override: copy a different Ignition CLI wheel into .devcontainer/wheels/
    (the bundled one from templates/devcontainer/wheels is already there for new dev containers).
    post-create.sh installs the newest version it finds.

    The wheel comes from --ign-wheel, else the IGN_WHEEL environment variable."""
    import os
    import shutil
    import zipfile

    wheel = wheel or os.environ.get('IGN_WHEEL')
    if not wheel:
        return
    src = Path(wheel).expanduser()
    if not src.is_file():
        raise click.ClickException(f"Ignition wheel not found: {src}")
    if not re.fullmatch(r'ign-[0-9][^-]*-py3-none-any\.whl', src.name) or not zipfile.is_zipfile(src):
        raise click.ClickException(f"Not an Ignition CLI wheel (expected ign-<version>-py3-none-any.whl): {src.name}")
    DEVCONTAINER_WHEELS_DIR.mkdir(parents=True, exist_ok=True)
    target = DEVCONTAINER_WHEELS_DIR / src.name
    shutil.copy2(src, target)
    console.print(f"  [dim]📄 {target.as_posix()} (installed by the dev container - commit it)[/dim]")


def create_devcontainer(ign_wheel: Optional[str] = None) -> None:
    """Add the standard dev container (Ignition CLI, Terraform, Azure CLI, ...) to the project.

    Never overwrites a .devcontainer/ the team already has, but still adds the ign wheel to it."""
    if DEVCONTAINER_DIR.exists():
        console.print(f"  [dim]↷ {DEVCONTAINER_DIR}/ exists - left unchanged[/dim]")
    elif _render_devcontainer(Path('.')) == 0:
        console.print("  [yellow]⚠️  Dev container templates not found in the installed package - skipped[/yellow]")
        return
    else:
        console.print(f"  [dim]📁 {DEVCONTAINER_DIR}/ (dev container)[/dim]")
    _copy_ign_wheel(ign_wheel)


def _render_cicd_repo(source: Path, target: Path, github_org: str, cicd_repo: str, cicd_ref: str) -> int:
    """Render the shared CI/CD repo templates for an organisation into target. Returns the file count."""
    count = 0
    for src in sorted(source.rglob('*')):
        if not src.is_file() or '__pycache__' in src.parts:
            continue
        content = src.read_text(encoding='utf-8')
        for key, value in (('github_org', github_org), ('cicd_repo', cicd_repo), ('cicd_ref', cicd_ref)):
            content = content.replace('{' + key + '}', value)
        out = target / src.relative_to(source)
        out.parent.mkdir(parents=True, exist_ok=True)
        # LF endings: these files run on Linux runners and are committed as-is by bootstrap.
        with open(out, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(content)
        count += 1
    return count


def _github_repo_exists(org: str, repo: str, token: str) -> Optional[bool]:
    """True/False if the repository exists, None if GitHub could not be asked."""
    import os
    import urllib.request
    import urllib.error
    api = os.environ.get('GITHUB_API_URL', 'https://api.github.com').rstrip('/')
    req = urllib.request.Request(f"{api}/repos/{org}/{repo}", headers={
        'Authorization': f'Bearer {token}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'ignition-cli',
    })
    try:
        with urllib.request.urlopen(req, timeout=20):
            return True
    except urllib.error.HTTPError as err:
        return False if err.code == 404 else None
    except (urllib.error.URLError, TimeoutError, OSError):
        return None


@cli.command('init-cicd-repo')
@click.option('--github-org', default=None, help='GitHub organisation that will own the shared CI/CD repo')
@click.option('--cicd-repo', default=None, help=f'Repository name (default: {DEFAULT_CICD_REPO})')
@click.option('--cicd-ref', default=None, help=f'Ref the reusable workflow uses for its own composite actions (default: {DEFAULT_CICD_REF})')
@click.option('--output-dir', default=None, help='Directory to write into (default: ./<cicd-repo>)')
@click.option('--force', is_flag=True, default=False, help='Overwrite files in a non-empty output directory')
def init_cicd_repo(github_org: str, cicd_repo: str, cicd_ref: str, output_dir: str, force: bool):
    """Scaffold the shared GitHub Actions CI/CD repo for Azure Terraform.

    Creates the reusable workflow (_terraform-pipeline.yml), the tf-ci / tf-plan /
    tf-apply composite actions and a release workflow. Push the result to
    GitHub as <github-org>/<cicd-repo>; projects created with
    `ign init --cicd github` call it from .github/workflows/<stack>.yml.
    """
    if not github_org:
        github_org = click.prompt('  GitHub organisation')
    if not cicd_repo:
        cicd_repo = click.prompt('  CI/CD repo name', default=DEFAULT_CICD_REPO)
    if not cicd_ref:
        cicd_ref = click.prompt('  Ref for internal action references (tag/branch/SHA)', default=DEFAULT_CICD_REF)

    source = _find_resource_dir('resources/templates/pipelines/github/cicd-repo')
    if source is None:
        console.print("[bold red]❌  CI/CD repo templates not found in the installed package.[/bold red]")
        return

    target = Path(output_dir) if output_dir else Path(cicd_repo)
    if target.exists() and any(target.iterdir()) and not force:
        console.print(f"[bold red]❌  {target} is not empty.[/bold red] Use [bold]--force[/bold] to overwrite.")
        return

    console.print(Panel(
        f"[bold white]Repo:[/bold white] [cyan]{github_org}/{cicd_repo}[/cyan]\n"
        f"[bold white]Into:[/bold white] [cyan]{target}[/cyan]",
        title="[bold cyan]🔁  Scaffolding Shared GitHub Actions CI/CD Repo (Azure)[/bold cyan]",
        title_align="left", style="cyan", expand=False,
    ))
    console.print()

    count = _render_cicd_repo(source, target, github_org, cicd_repo, cicd_ref)
    console.print(f"[green]✓[/green] Rendered {count} files into [cyan]{target}[/cyan]")

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Push to GitHub: [bold]cd {target} && git init -b main && git add . && git commit -m 'Initial CI/CD templates'[/bold]")
    grid.add_row("2.", f"Create the repo: [bold]gh repo create {github_org}/{cicd_repo} --private --source . --push[/bold]")
    grid.add_row("3.", "Settings → Actions → General → Access: allow repositories in the organisation")
    grid.add_row("4.", f"Create the [bold]{cicd_repo}-maintainers[/bold] team (CODEOWNERS) - or let [bold]ign bootstrap[/bold] create the whole repo")
    grid.add_row("5.", "After the first release, pin consumers (and the internal action refs) to the tag")
    console.print(Panel(grid, title="[bold green]✅  CI/CD Repo Scaffolded[/bold green]", title_align="left", style="green", expand=False))
    console.print()


def _detect_cloud_provider() -> str:
    """Infer cloud provider from the scaffold providers.tf written by init."""
    providers_tf = Path('templates/scaffold/terraform/providers.tf')
    if providers_tf.exists():
        content = providers_tf.read_text(encoding='utf-8')
        if 'hashicorp/aws' in content or 'backend "s3"' in content:
            return 'aws'
    return 'azure'


@cli.command()
@click.option('--stack-name', prompt='Stack name', help='Name of the stack (e.g., dlz, dmz)')
@click.option('--description', prompt='Stack description', help='Brief description of the stack')
@click.option('--service-connection', default=None, help='DevOps service connection name (Azure DevOps projects only; prompted if omitted)')
@click.option('--include-databricks', is_flag=True, default=False, help='Include Databricks workspace resources (Azure only)')
@click.option('--include-storage', is_flag=True, default=False, help='Include storage account resources (Azure only)')
@click.option('--include-keyvault', is_flag=True, default=False, help='Include Key Vault resources (Azure only)')
def add_stack(stack_name: str, description: str, service_connection: str,
              include_databricks: bool, include_storage: bool, include_keyvault: bool):
    """Add a new deployment stack to the project."""

    cloud = _detect_cloud_provider()
    cicd = _detect_cicd_platform()
    if cicd == 'ado' and not service_connection:
        service_connection = click.prompt('Service connection', default='DataPlatform - Dev')

    cloud_label = (
        "[bold #FF9900]⬡  AWS[/bold #FF9900]"
        if cloud == 'aws'
        else "[bold #0078D4]◆  Azure[/bold #0078D4]"
    )
    console.print(Panel(
        f"[bold white]Cloud:[/bold white] {cloud_label}\n"
        f"[bold white]CI/CD:[/bold white] {CICD_LABELS[cicd]}\n"
        f"[bold white]Stack:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]📦  Creating New Stack[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()

    # Validate stacks directory exists
    stacks_dir = Path('stacks')
    if not stacks_dir.exists():
        console.print("[bold red]❌  Error:[/bold red] [red]'stacks' directory not found. Did you run 'init' first?[/red]")
        return

    stack_dir = stacks_dir / stack_name
    if stack_dir.exists():
        if not click.confirm(f"Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return

    # Create stack structure
    terraform_dir = stack_dir / 'terraform'
    yaml_dir = stack_dir / 'yaml'

    cli_helper.create_directory(terraform_dir)

    if cloud == 'aws':
        generate_aws_terraform_files(terraform_dir, stack_name, description)
    else:
        generate_terraform_files(terraform_dir, stack_name, description,
                                 include_databricks, include_storage, include_keyvault)

    if cicd == 'github':
        # One caller workflow per stack, calling the shared reusable pipeline
        generate_github_workflow(stack_name)
    else:
        cli_helper.create_directory(yaml_dir)
        generate_yaml_files(yaml_dir, stack_dir, stack_name, service_connection, cloud=cloud)
        # Generate Azure Pipelines file (same structure for both clouds)
        generate_azure_pipelines(stack_dir, stack_name, service_connection)

    # Generate configuration guide
    generate_configuration_guide(stack_dir, terraform_dir, yaml_dir)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Customize Terraform configuration in [bold]stacks/{stack_name}/terraform/[/bold]")
    grid.add_row("2.", "Update variable values in [bold]terraform/tfvars/*.tfvars[/bold] files")
    if cicd == 'github':
        grid.add_row("3.", f"Review the workflow in [bold].github/workflows/{stack_name}.yml[/bold] and [bold]stacks/{stack_name}/CONFIGURATION.md[/bold]")
    else:
        grid.add_row("3.", "Review pipeline configuration in [bold]azure-pipelines.yml[/bold]")
    grid.add_row("4.", "Commit changes and push to trigger CI/CD")
    console.print(Panel(grid, title=f"[bold green]✅  Stack '{stack_name}' Created Successfully![/bold green]", title_align="left", style="green", expand=False))
    console.print()


@cli.command()
def list_stacks():
    """List all stacks in the project."""
    
    stack_paths = _iter_all_stacks()
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No 'stacks' directory found.[/bold red] Initialize a project first with [bold]ign init[/bold].")
        return

    if not stack_paths:
        console.print("[yellow]No stacks found in the project.[/yellow]")
        return

    table = Table(
        title="[bold cyan]📋  Project Stacks[/bold cyan]",
        box=box.ROUNDED,
        header_style="bold cyan",
        border_style="cyan",
        show_lines=False,
    )
    table.add_column("Status", style="bold", no_wrap=True, width=8)
    table.add_column("Stack Name", style="bold white")
    table.add_column("Location", style="dim", no_wrap=True)
    table.add_column("Terraform", justify="center", width=12)
    table.add_column("YAML", justify="center", width=8)

    for stack_path in stack_paths:
        terraform_exists = (stack_path / 'terraform').exists()
        yaml_exists = (stack_path / 'yaml').exists()
        is_complete = terraform_exists and yaml_exists
        status = "[green]●  Ready[/green]" if is_complete else "[yellow]●  Partial[/yellow]"
        tf_icon = "[green]✓[/green]" if terraform_exists else "[red]✗[/red]"
        yaml_icon = "[green]✓[/green]" if yaml_exists else "[red]✗[/red]"
        table.add_row(status, stack_path.name, f"{stack_path.parent.name}/", tf_icon, yaml_icon)

    console.print()
    console.print(table)
    console.print()


@cli.command()
@click.option('--debug', is_flag=True, help='Show debug information about module search paths')
def list_modules(debug: bool):
    """List all available Terraform modules that can be added to stacks.
    
    This includes both .tf modules (in modules/ directory) and template-based modules.
    Contributors can add new modules by creating .tf files in the modules/ directory.
    """
    
    cloud = _detect_cloud_provider()
    cloud_label = "AWS" if cloud == 'aws' else "Azure"

    console.print()
    console.print(Rule(f"[bold cyan]📦  Available Terraform Modules ({cloud_label})[/bold cyan]", style="cyan"))
    console.print()

    # Show debug info if requested
    if debug:
        import sys
        import site
        console.print(f"[bold]🔍  Debug: Cloud platform detected as [cyan]{cloud_label}[/cyan]. Searching:[/bold]")
        search_paths = [
            Path(__file__).parent / 'resources' / 'modules' / cloud,
            Path.cwd() / 'resources' / 'modules' / cloud,
            Path(sys.prefix) / 'resources' / 'modules' / cloud,
            Path(sys.prefix) / 'share' / 'resources' / 'modules' / cloud,
        ]
        try:
            if hasattr(site, 'USER_BASE') and site.USER_BASE:
                search_paths.append(Path(site.USER_BASE) / 'resources' / 'modules' / cloud)
        except:
            pass
        try:
            for site_dir in site.getsitepackages():
                search_paths.append(Path(site_dir) / 'resources' / 'modules' / cloud)
        except:
            pass

        for path in search_paths:
            if path.exists():
                console.print(f"  [green]✅[/green]  {path}")
            else:
                console.print(f"  [red]❌[/red]  [dim]{path}[/dim]")
        console.print()

    # Discover Terraform modules for the detected cloud
    tf_modules = discover_available_modules(cloud)
    
    if tf_modules:
        table = Table(
            box=box.SIMPLE,
            header_style="bold cyan",
            border_style="dim",
            show_header=True,
            pad_edge=False,
        )
        table.add_column("Module", style="bold white", no_wrap=True)
        table.add_column("Description", style="white")
        if debug:
            table.add_column("Path", style="dim", no_wrap=True)
        
        for module_name, module_path in sorted(tf_modules.items()):
            try:
                first_lines = module_path.read_text(encoding='utf-8').split('\n')[:3]
                description = ""
                for line in first_lines:
                    if line.strip().startswith('# Description:'):
                        description = line.replace('# Description:', '').strip()
                        break
            except Exception:
                description = ""
            
            if debug:
                try:
                    relative_path = module_path.relative_to(Path(__file__).parent) if module_path.is_relative_to(Path(__file__).parent) else module_path
                except Exception:
                    relative_path = module_path
                table.add_row(module_name, description or "[dim italic]No description[/dim italic]", str(relative_path))
            else:
                table.add_row(module_name, description or "[dim italic]No description[/dim italic]")
        
        console.print(table)
    else:
        console.print("[yellow]⚠️   No Terraform modules found[/yellow]")
        console.print("\n[dim]💡 Tip: Run with --debug flag to see search paths:[/dim]")
        console.print("   [bold]ign list-modules --debug[/bold]")
    
    console.print()
    console.print(Rule("[dim]Need a module or found a bug?[/dim]", style="dim"))
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", "Raise an issue: [link]https://github.com/telefonicatechuki/devops-cli/issues[/link]")
    grid.add_row("2.", "It will be reviewed and added to the library if new")
    grid.add_row("3.", "If this is a bug it will be triaged")
    grid.add_row("4.", "Raise a PR if you know the fix and get it merged!")
    console.print()
    console.print(grid)
    console.print()
    console.print("[dim]📖 See modules/README.md for contributor guide[/dim]")
    console.print()


@cli.command()
@click.option('--init-only', is_flag=True, default=False, help='Only run terraform init')
@click.option('--plan-only', is_flag=True, default=False, help='Only run terraform plan')
@click.option('--apply', is_flag=True, default=False, help='Run terraform apply after plan')
@click.option('--auto-approve', is_flag=True, default=False, help='Skip confirmation prompts for terraform apply')
@click.option('--ado-pat', envvar='AZDO_PERSONAL_ACCESS_TOKEN', help='Azure DevOps PAT token (prompted if not provided, not stored)')
@click.option('--gh-token', envvar='GITHUB_TOKEN', help='GitHub token for cicdPlatform: github (falls back to `gh auth token`, then a prompt; not stored)')
@click.option('--keep-state', is_flag=True, default=False, help='Keep the Terraform state file after apply (default: state file is deleted since bootstrap resources are one-time setup)')
@click.option('--cleanup-cache', is_flag=True, default=False, help='Clean up .terraform directory (provider cache) after successful apply. Safe to delete.')
def bootstrap(init_only: bool, plan_only: bool, apply: bool, auto_approve: bool, ado_pat: str, gh_token: str, keep_state: bool, cleanup_cache: bool):
    """Bootstrap infrastructure by running Terraform in the bootstrap directory.
    
    This command sets up the foundational infrastructure including:
    - Resource groups for Terraform state storage
    - Storage accounts for Terraform state
    - User Managed Identities for build and deploy operations
    - Azure DevOps service connections (requires ADO PAT token), or
    - GitHub repository guardrails, role teams, environments, environment
      variables and OIDC federated credentials (requires a GitHub token)
    
    Configuration is managed via config.yaml in the bootstrap/terraform directory.
    Tokens are prompted securely and never stored.
    """
    import subprocess
    import sys
    import os
    
    # Try to import yaml, provide helpful error if missing
    try:
        import yaml
    except ImportError:
        console.print("[bold red]❌  Error:[/bold red] [red]PyYAML is required but not installed.[/red]")
        console.print("   Please reinstall the package:")
        console.print("     [bold]uv pip install --force-reinstall .[/bold]")
        console.print("   Or install PyYAML directly:")
        console.print("     [bold]pip install PyYAML[/bold]")
        return
    
    console.print(Panel(
        "[white]Sets up foundational infrastructure: resource groups, storage accounts,\nmanaged identities, and CI/CD access (Azure DevOps service connections\nor GitHub Actions OIDC federated credentials).[/white]",
        title="[bold cyan]🚀  Bootstrapping Infrastructure[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Find CLI's bootstrap terraform directory (where terraform files are)
    # When installed via pip/uv, data_files go to sys.prefix or site-packages
    cli_bootstrap_dirs = [
        # 1. Development: next to ignition.py (source directory)
        Path(__file__).parent / 'resources' / 'bootstrap' / 'terraform',
        # 2. Installed package location (data_files go here)
        Path(sys.prefix) / 'resources' / 'bootstrap' / 'terraform',
    ]
    
    # Try to get from site-packages (where data_files are installed)
    try:
        import site
        # Check site-packages directories
        for site_dir in site.getsitepackages():
            cli_bootstrap_dirs.append(Path(site_dir) / 'bootstrap' / 'terraform')
        
        # Check user site-packages
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            user_site = site.getusersitepackages() if hasattr(site, 'getusersitepackages') else None
            if user_site:
                cli_bootstrap_dirs.append(Path(user_site) / 'bootstrap' / 'terraform')
            else:
                cli_bootstrap_dirs.append(Path(site.USER_BASE) / 'bootstrap' / 'terraform')
    except Exception:
        pass
    
    # Find CLI bootstrap directory (where terraform files are)
    cli_bootstrap_dir = None
    for dir_path in cli_bootstrap_dirs:
        if dir_path.exists() and (dir_path / 'main.tf').exists():
            cli_bootstrap_dir = dir_path
            break
    
    if not cli_bootstrap_dir:
        console.print("[bold red]❌  Error:[/bold red] [red]CLI bootstrap terraform directory not found.[/red]")
        console.print("   The bootstrap terraform files are not installed with the package.")
        console.print("   Please reinstall the package:")
        console.print("     [bold]pip install --force-reinstall .[/bold]")
        console.print("   Or if using uv:")
        console.print("     [bold]uv pip install --force-reinstall .[/bold]")
        console.print("\n   [dim]Searched in:[/dim]")
        for dir_path in cli_bootstrap_dirs:
            exists_icon = "[green]✓[/green]" if dir_path.exists() else "[red]✗[/red]"
            console.print(f"     {exists_icon}  [dim]{dir_path}[/dim]")
        return
    
    # Check for config.yaml in current project directory
    project_config_file = Path.cwd() / 'bootstrap' / 'terraform' / 'config.yaml'
    cli_config_file = cli_bootstrap_dir / 'config.yaml'
    
    # Use project config.yaml if it exists, otherwise check CLI directory
    config_source = None
    if project_config_file.exists():
        config_source = project_config_file
        console.print(f"[green]📁[/green]  Found project config: [bold]{project_config_file}[/bold]")
        console.print(f"[green]📁[/green]  Using CLI terraform files: [dim]{cli_bootstrap_dir}[/dim]")
    elif cli_config_file.exists():
        config_source = cli_config_file
        console.print(f"[green]📁[/green]  Using CLI config: [bold]{cli_config_file}[/bold]")
    else:
        console.print("[bold red]❌  Error:[/bold red] [red]config.yaml not found.[/red]")
        console.print(f"   Please create config.yaml at:")
        console.print(f"     [bold]{project_config_file}[/bold] [dim](project directory)[/dim]")
        console.print(f"   Or run [bold]ign init[/bold] to generate it.")
        return
    
    # Read config.yaml to check if ADO is configured
    with open(config_source, 'r', encoding='utf-8') as f:
        config_data = yaml.safe_load(f)
    
    ado_org_url = config_data.get('adoOrgUrl')
    ado_project_id = config_data.get('adoProjectId')
    cicd_platform = str(config_data.get('cicdPlatform') or 'ado').strip().lower()
    first_time_gh = False
    gh_org = config_data.get('orgName_gh')
    github_configured = (
        cicd_platform == 'github'
        and gh_org is not None
        and str(gh_org).strip() not in ('', 'null', '<Fill Me In>')
    )
    if cicd_platform == 'github':
        # Azure DevOps resources are never created for GitHub projects
        ado_org_url = None
        if not github_configured:
            console.print("[bold red]❌  cicdPlatform is github but orgName_gh is not set in config.yaml.[/bold red]")
            return
        first_time_gh = config_data.get('isFirstTimeDeployToGH')
        if not isinstance(first_time_gh, bool):
            console.print("[bold red]❌  Set isFirstTimeDeployToGH to true or false in config.yaml.[/bold red]")
            console.print("   [dim]true  = first environment for this repository: creates the role teams and repository guardrails[/dim]")
            console.print("   [dim]false = later environments: only the GitHub environments and OIDC trust are created[/dim]")
            return
    
    # Check if ADO is configured (adoOrgUrl is set and not null/empty)
    # Service connections will be created if adoOrgUrl is set, so PAT is needed
    ado_configured = (
        ado_org_url is not None 
        and str(ado_org_url).strip() != '' 
        and str(ado_org_url).lower() != 'null'
    )
    
    # Warn if adoProjectId is missing but adoOrgUrl is set
    if ado_configured:
        if not ado_project_id or str(ado_project_id).lower() == 'null' or str(ado_project_id).strip() == '':
            console.print("[yellow]⚠️   Warning:[/yellow] [yellow]adoOrgUrl is configured but adoProjectId is not set.[/yellow]")
            console.print("   Service connections require adoProjectId. Update config.yaml with your project ID.")
            console.print("   Service connection creation will fail if adoProjectId is missing.\n")
    
    # Prompt for ADO PAT token if ADO is configured and not provided
    if ado_configured and not ado_pat:
        console.print("[bold cyan]🔐  Azure DevOps configuration detected in config.yaml[/bold cyan]")
        console.print("   ADO PAT token is required for creating service connections.")
        console.print("   [dim]The token will be used securely and never stored.[/dim]\n")
        ado_pat = click.prompt("Enter Azure DevOps PAT token", hide_input=True)
        if not ado_pat or not ado_pat.strip():
            console.print("[bold red]❌  ADO PAT token is required when adoOrgUrl is configured.[/bold red]")
            return
    
    # Resolve a GitHub token if GitHub is configured: --gh-token / GITHUB_TOKEN,
    # then the GitHub CLI's token, then a hidden prompt.
    if github_configured and not gh_token:
        try:
            gh_res = subprocess.run(['gh', 'auth', 'token'], capture_output=True, text=True, timeout=20)
            if gh_res.returncode == 0 and gh_res.stdout.strip():
                if click.confirm("Use the GitHub CLI's current token (gh auth token)?", default=True):
                    gh_token = gh_res.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    if github_configured and not gh_token:
        console.print("[bold cyan]🔐  GitHub configuration detected in config.yaml[/bold cyan]")
        console.print(f"   A token with admin rights on [bold]{gh_org}/{config_data.get('repositoryName_gh')}[/bold] is required")
        console.print("   (classic PAT scopes: repo, admin:org, workflow - or a fine-grained token with")
        console.print("   Administration, Environments, Variables and Members write access).")
        console.print("   [dim]The token will be used securely and never stored.[/dim]\n")
        gh_token = click.prompt("Enter GitHub token", hide_input=True)
        if not gh_token or not gh_token.strip():
            console.print("[bold red]❌  A GitHub token is required when cicdPlatform is github.[/bold red]")
            return

    # The infrastructure repository must already exist (and be visible to the token) unless this
    # first run creates it. GitHub answers 404 for repos the token cannot see, and the Terraform
    # provider turns that into an empty result rather than an error, so check up front.
    if github_configured and not (first_time_gh and config_data.get('ghCreateRepository') is True):
        infra_repo = str(config_data.get('repositoryName_gh') or '').strip()
        for _ in range(5):  # resolve ${key} placeholders, e.g. "${app_short}"
            infra_repo = re.sub(r'\$\{(\w+)\}', lambda m: str(config_data.get(m.group(1), m.group(0))), infra_repo)
        exists = _github_repo_exists(str(gh_org).strip(), infra_repo, gh_token.strip())
        if exists is None:
            console.print(f"[bold red]❌  Could not check whether {gh_org}/{infra_repo} exists (GitHub API unreachable or token rejected).[/bold red]")
            return
        if not exists:
            console.print(f"[bold red]❌  GitHub repository {gh_org}/{infra_repo} was not found, or the token cannot see it.[/bold red]")
            console.print("   - Check repositoryName_gh / orgName_gh in config.yaml")
            console.print("   - Fine-grained PAT: give it access to this repository (and the organisation)")
            console.print("   - Classic PAT: needs the repo scope and SSO authorisation for the organisation")
            if first_time_gh:
                console.print("   - Or set [bold]ghCreateRepository: true[/bold] to have bootstrap create it")
            return

    # Shared CI/CD repo: on a repository's first run, create it if the organisation does not have it yet.
    cicd_repo_tf_env: Dict[str, str] = {}
    cicd_render_dir = None
    if github_configured and first_time_gh and config_data.get('createCicdRepo_gh', True) is not False:
        project_settings = _load_project_settings()
        cicd_repo_name = str(config_data.get('cicdRepoName_gh') or project_settings.get('cicd_repo') or DEFAULT_CICD_REPO).strip()
        cicd_ref = str(project_settings.get('cicd_ref') or DEFAULT_CICD_REF).strip()
        exists = _github_repo_exists(str(gh_org).strip(), cicd_repo_name, gh_token.strip())
        if exists is None:
            console.print(f"[bold red]❌  Could not check whether {gh_org}/{cicd_repo_name} exists (GitHub API unreachable or token rejected).[/bold red]")
            console.print("   Fix the token / network, or set [bold]createCicdRepo_gh: false[/bold] in config.yaml.")
            return
        if exists:
            console.print(f"[green]📦[/green]  Shared CI/CD repo [bold]{gh_org}/{cicd_repo_name}[/bold] already exists [dim](left unchanged)[/dim]\n")
            cicd_repo_tf_env['TF_VAR_cicd_repo_exists'] = 'true'
        else:
            source = _find_resource_dir('resources/templates/pipelines/github/cicd-repo')
            if source is None:
                console.print("[bold red]❌  CI/CD repo templates not found in the installed package.[/bold red]")
                return
            import tempfile
            cicd_render_dir = Path(tempfile.mkdtemp(prefix='ign-cicd-repo-'))
            count = _render_cicd_repo(source, cicd_render_dir, str(gh_org).strip(), cicd_repo_name, cicd_ref)
            console.print(f"[green]📦[/green]  Shared CI/CD repo [bold]{gh_org}/{cicd_repo_name}[/bold] will be created "
                          f"with {count} files [dim](internal refs @{cicd_ref})[/dim]\n")
            cicd_repo_tf_env['TF_VAR_cicd_repo_exists'] = 'false'
            cicd_repo_tf_env['TF_VAR_cicd_repo_files_dir'] = cicd_render_dir.as_posix()

    # New infrastructure repository: commit the dev container so it is there on first clone.
    app_render_dir = None
    if github_configured and first_time_gh and config_data.get('ghCreateRepository') is True:
        import tempfile
        app_render_dir = Path(tempfile.mkdtemp(prefix='ign-app-repo-'))
        if _render_devcontainer(app_render_dir):
            import sys
            cicd_repo_tf_env['TF_VAR_app_repo_files_dir'] = app_render_dir.as_posix()
            # The ign wheel is binary: Terraform uploads it via the Contents API using this interpreter.
            cicd_repo_tf_env['TF_VAR_python_executable'] = Path(sys.executable).as_posix()
            console.print("[green]📦[/green]  Dev container (including the ign wheel) will be committed to the new repository\n")
        else:
            console.print("[yellow]⚠️  Dev container templates not found in the installed package - repository will be created without one[/yellow]\n")

    # Copy project config.yaml to CLI bootstrap directory temporarily
    config_backup = None
    if config_source == project_config_file:
        # Backup existing CLI config if it exists
        if cli_config_file.exists():
            config_backup = cli_bootstrap_dir / 'config.yaml.backup'
            if config_backup.exists():
                config_backup.unlink()
            cli_config_file.rename(config_backup)
        
        # Copy project config to CLI directory
        import shutil
        shutil.copy2(project_config_file, cli_config_file)
        console.print(f"[green]📋[/green]  Copied project config to CLI bootstrap directory\n")
    
    # Set up environment variables for terraform
    terraform_env = os.environ.copy()
    # Set AZDO_ORG_SERVICE_URL if adoOrgUrl is configured (needed for provider initialization)
    # This is independent of whether PAT is provided or adoProjectId is set
    if ado_configured or (ado_org_url and str(ado_org_url).strip() and str(ado_org_url).lower() != 'null'):
        terraform_env['AZDO_ORG_SERVICE_URL'] = str(ado_org_url).strip()
        if ado_pat:
            terraform_env['AZDO_PERSONAL_ACCESS_TOKEN'] = ado_pat
            console.print("[green]🔐[/green]  ADO PAT token set in environment [dim](will not be stored)[/dim]\n")
        else:
            console.print("[yellow]⚠️   ADO org URL set, but PAT token not provided.[/yellow]\n")
    
    if github_configured:
        terraform_env['GITHUB_TOKEN'] = gh_token.strip()
        terraform_env['GITHUB_OWNER'] = str(gh_org).strip()
        terraform_env.update(cicd_repo_tf_env)
        console.print("[green]🔐[/green]  GitHub token set in environment [dim](will not be stored)[/dim]\n")

    # Azure DevOps resources live in ado.tf. The azuredevops provider contacts the ADO
    # organisation as soon as it is configured (even when every ADO resource has count = 0),
    # so GitHub runs set the file aside and restore it afterwards.
    ado_tf = cli_bootstrap_dir / 'ado.tf'
    ado_tf_disabled = cli_bootstrap_dir / 'ado.tf.disabled'
    if ado_tf_disabled.exists():
        # Left over from an interrupted GitHub run - put it back first.
        if ado_tf.exists():
            ado_tf_disabled.unlink()
        else:
            ado_tf_disabled.rename(ado_tf)
    ado_tf_set_aside = False

    # Change to CLI bootstrap directory to run terraform
    original_dir = Path.cwd()
    try:
        if cicd_platform == 'github' and ado_tf.exists():
            ado_tf.rename(ado_tf_disabled)
            ado_tf_set_aside = True
            console.print("[dim]⏭️   Azure DevOps resources (ado.tf) excluded: cicdPlatform is github[/dim]")
        os.chdir(cli_bootstrap_dir)
        console.print(f"[dim]📂  Running terraform from: {cli_bootstrap_dir}[/dim]\n")
        
        # Run terraform init (always needed before plan/apply, unless init-only)
        if not init_only:
            console.print(Rule("[bold]🔧  Running terraform init...[/bold]", style="blue"))
            result = subprocess.run(['terraform', 'init'], capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform init failed[/bold red]")
                return
        
        if init_only:
            console.print(Panel("[bold green]✅  Bootstrap initialization complete![/bold green]", style="green", expand=False))
            return
        
        # Run terraform plan
        if not apply:
            console.print(Rule("[bold]📋  Running terraform plan...[/bold]", style="blue"))
            result = subprocess.run(['terraform', 'plan'], capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform plan failed[/bold red]")
                return
            
            if plan_only:
                console.print(Panel("[bold green]✅  Terraform plan complete![/bold green]", style="green", expand=False))
                return
        
        # Run terraform apply
        if apply:
            if not auto_approve:
                if not click.confirm("\n⚠️  Do you want to apply these changes?"):
                    console.print("[yellow]Aborted.[/yellow]")
                    return
            
            console.print(Rule("[bold]🚀  Running terraform apply...[/bold]", style="blue"))
            apply_args = ['terraform', 'apply']
            if auto_approve:
                apply_args.append('-auto-approve')
            if cicd_render_dir is not None or 'TF_VAR_app_repo_files_dir' in cicd_repo_tf_env:
                # Files are committed to one branch one at a time - parallel commits conflict.
                apply_args.append('-parallelism=1')
            
            result = subprocess.run(apply_args, capture_output=False, env=terraform_env)
            if result.returncode != 0:
                console.print("[bold red]❌  Terraform apply failed[/bold red]")
                return
            
            console.print(Panel("[bold green]✅  Bootstrap deployment complete![/bold green]", style="green", expand=False))
            
            # Generate environment-specific output documentation before local state cleanup
            try:
                output_res = subprocess.run(
                    ['terraform', 'output', '-json'],
                    capture_output=True,
                    text=True,
                    env=terraform_env,
                    cwd=cli_bootstrap_dir
                )
                if output_res.returncode == 0 and output_res.stdout.strip():
                    raw_outputs = json.loads(output_res.stdout)
                    
                    from datetime import datetime
                    output_params = {
                        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }

                    # Dynamically map all terraform outputs into output_params dictionary
                    for key, output_obj in raw_outputs.items():
                        val = output_obj.get("value") if isinstance(output_obj, dict) else output_obj
                        if isinstance(val, dict):
                            # Handle nested dictionary outputs
                            for sub_k, sub_v in val.items():
                                output_params[f"{key}_{sub_k}"] = str(sub_v) if sub_v is not None else ""
                        elif isinstance(val, list):
                            output_params[key] = ", ".join(f"`{item}`" for item in val)
                        else:
                            output_params[key] = str(val) if val is not None else ""

                    env_name = output_params.get("environment", "unknown")
                    outputs_template = (
                        'resources/bootstrap/BOOTSTRAP-OUTPUTS-github.md.template'
                        if output_params.get("cicd_platform") == "github"
                        else 'resources/bootstrap/BOOTSTRAP-OUTPUTS.md.template'
                    )

                    try:
                        template_content = cli_helper.load_template(outputs_template, **output_params)
                        
                        output_dir = original_dir / 'bootstrap'
                        output_dir.mkdir(parents=True, exist_ok=True)
                        output_file = output_dir / f'BOOTSTRAP-OUTPUTS-{env_name}.md'
                        
                        cli_helper.write_file(output_file, template_content)
                        console.print(f"[bold green]📝  Generated environment summary: [cyan]{output_file}[/cyan][/bold green]")
                    except Exception as te:
                        console.print(f"[yellow]⚠️  Could not generate BOOTSTRAP-OUTPUTS markdown summary: {te}[/yellow]")
            except Exception as oe:
                console.print(f"[yellow]⚠️  Could not capture terraform outputs: {oe}[/yellow]")

            # Cleanup after successful apply
            import shutil
            terraform_dir = Path(cli_bootstrap_dir) / '.terraform'
            state_file = Path(cli_bootstrap_dir) / 'terraform.tfstate'
            state_backup = Path(cli_bootstrap_dir) / 'terraform.tfstate.backup'
            
            # Clean up state file by default (bootstrap resources are one-time setup and don't need tracking)
            if not keep_state:
                if state_file.exists():
                    state_file.unlink()
                    console.print("[cyan]🧹  Removed local state file (terraform.tfstate)[/cyan]")
                if state_backup.exists():
                    state_backup.unlink()
                    console.print("[cyan]🧹  Removed state backup file (terraform.tfstate.backup)[/cyan]")
            
            # Clean up provider cache if requested
            if cleanup_cache and terraform_dir.exists():
                shutil.rmtree(terraform_dir)
                console.print("[cyan]🧹  Cleaned up .terraform directory (provider cache)[/cyan]")
        else:
            console.print("\n[dim]💡  Tip: Use [bold]--apply[/bold] flag to apply the changes[/dim]")
            console.print("   [dim]Example: [bold]ign bootstrap --apply[/bold][/dim]")
    
    finally:
        # Clear PAT token from environment
        if 'AZDO_PERSONAL_ACCESS_TOKEN' in terraform_env:
            terraform_env.pop('AZDO_PERSONAL_ACCESS_TOKEN', None)
            console.print("\n[dim]🔒  ADO PAT token cleared from environment[/dim]")
        if cicd_render_dir is not None:
            import shutil
            shutil.rmtree(cicd_render_dir, ignore_errors=True)
        if app_render_dir is not None:
            import shutil
            shutil.rmtree(app_render_dir, ignore_errors=True)
        if 'GITHUB_TOKEN' in terraform_env:
            terraform_env.pop('GITHUB_TOKEN', None)
            console.print("[dim]🔒  GitHub token cleared from environment[/dim]")
        
        # Restore CLI config.yaml backup if we copied project config
        if config_source == project_config_file and config_backup:
            if cli_config_file.exists():
                cli_config_file.unlink()
            if config_backup.exists():
                config_backup.rename(cli_config_file)

        # Put the Azure DevOps resources back for the next (possibly ADO) run
        if ado_tf_set_aside and ado_tf_disabled.exists() and not ado_tf.exists():
            ado_tf_disabled.rename(ado_tf)

        # Always return to original directory
        os.chdir(original_dir)


@cli.command()
@click.option('--stack-name', prompt='Stack name', help='Name of the stack to add resource to')
@click.option('--resource-type', prompt='Resource type', help='Type of resource to add (run list-modules to see available)')
@click.option('--resource-name', prompt='Resource name', help='Name for the resource')
def add_resource(stack_name: str, resource_type: str, resource_name: str):
    """Add a resource to an existing stack.
    
    Run 'ign list-modules' to see all available resource types.
    """
    
    console.print(Panel(
        f"[bold white]Resource:[/bold white] [cyan]{resource_type}[/cyan]  →  [bold white]Stack:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]📦  Adding Resource[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Validate stack exists
    stack_dir = _resolve_stack_dir(stack_name)
    if stack_dir is None:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack_name}' not found.[/red]")
        console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
        return

    terraform_dir = stack_dir / 'terraform'
    main_tf = terraform_dir / 'main.tf'
    
    if not main_tf.exists():
        console.print(f"[bold red]❌  Error:[/bold red] [red]{main_tf} not found.[/red]")
        return
    
    # Generate resource code
    resource_code = generate_resource_code(resource_type, resource_name)
    
    if not resource_code:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Could not generate code for {resource_type}[/red]")
        console.print(f"\n[dim]💡 Run [bold]ign list-modules[/bold] to see available resource types[/dim]")
        return
    
    # Read existing main.tf
    existing_content = main_tf.read_text(encoding='utf-8')
    
    # Check if resource already exists
    if f'module "{resource_name}"' in existing_content:
        console.print(f"[yellow]⚠️   Warning:[/yellow] [yellow]Resource '{resource_name}' already exists in {stack_name}[/yellow]")
        if not click.confirm("Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return
    
    # Append resource to main.tf
    updated_content = existing_content.rstrip() + "\n\n" + resource_code
    main_tf.write_text(updated_content, encoding='utf-8')
    
    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Review the generated code in [bold]main.tf[/bold]")
    grid.add_row("2.", "Update variable values as needed")
    grid.add_row("3.", f"Run: [bold]cd stacks/{stack_name}/terraform && terraform plan[/bold]")
    console.print(Panel(
        grid,
        title=f"[bold green]✅  Added {resource_type} '{resource_name}' to {stack_name}[/bold green]",
        title_align="left",
        style="green",
        expand=False
    ))
    console.print()


def _detect_stack_platform(stack_path: Path) -> str:
    """Detect whether a stack template targets AWS or Azure by inspecting its providers.tf."""
    for candidate in [
        stack_path / 'terraform' / 'providers.tf',
        stack_path / 'terraform' / 'main.tf',
    ]:
        if candidate.exists():
            content = candidate.read_text(encoding='utf-8')
            if 'hashicorp/aws' in content or 'backend "s3"' in content:
                return 'aws'
            if 'hashicorp/azurerm' in content or 'backend "azurerm"' in content:
                return 'azure'
    return 'azure'


def discover_available_modules(cloud: str = 'azure') -> Dict[str, Path]:
    """
    Discover available Terraform modules from the modules directory for the given cloud.
    Returns a dict mapping module names to their file paths.
    """
    import sys
    import site

    modules = {}
    module_dirs = [
        # 1. Development: next to ignition.py
        Path(__file__).parent / 'resources' / 'modules' / cloud,
        # 2. Current working directory
        Path.cwd() / 'resources' / 'modules' / cloud,
        # 3. Installed package: sys.prefix (for pip/uv install)
        Path(sys.prefix) / 'resources' / 'modules' / cloud,
        # 4. Installed package: site-packages data directory
        Path(sys.prefix) / 'share' / 'resources' / 'modules' / cloud,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            module_dirs.append(Path(site.USER_BASE) / 'resources' / 'modules' / cloud)
            module_dirs.append(Path(site.USER_BASE) / 'share' / 'resources' / 'modules' / cloud)
    except Exception:
        pass

    try:
        for site_dir in site.getsitepackages():
            module_dirs.append(Path(site_dir) / 'resources' / 'modules' / cloud)
    except Exception:
        pass

    for module_dir in module_dirs:
        if not module_dir.exists():
            continue

        for tf_file in module_dir.glob('**/*.tf'):
            module_name = tf_file.stem
            if module_name not in modules:
                modules[module_name] = tf_file

    return modules


def load_terraform_module(module_path: Path, resource_name: str) -> str:
    """
    Load a Terraform module and replace placeholders.
    
    Placeholders supported:
    - {{resource_name}}: The name of the resource
    """
    if not module_path.exists():
        return ""
    
    content = module_path.read_text(encoding='utf-8')
    
    # Replace placeholders
    content = content.replace('{{resource_name}}', resource_name)
    
    return content


def generate_resource_code(resource_type: str, resource_name: str) -> str:
    """
    Generate Terraform code for a specific resource type.
    
    Loads from Terraform (.tf) modules library.
    """
    
    # Try to find .tf module first
    available_modules = discover_available_modules(_detect_cloud_provider())

    if resource_type.lower() in available_modules:
        module_path = available_modules[resource_type.lower()]
        tf_code = load_terraform_module(module_path, resource_name)
        if tf_code:
            click.echo(f"   Using Terraform module: {module_path.name}")
            return tf_code
    
    # Module not found
    click.echo(f"⚠️  Module not found: {resource_type}")
    click.echo(f"\nAvailable modules:")
    for module_name in sorted(available_modules.keys()):
        click.echo(f"  • {module_name}")
    return ""


def create_aws_utils_module() -> None:
    """Create the templates/utils naming module for AWS."""
    utils_dir = Path('templates/utils')

    cli_helper.write_file(utils_dir / 'variables.tf',
        cli_helper.load_template('resources/templates/utils/aws/variables.tf'))
    cli_helper.write_file(utils_dir / 'main.tf',
        cli_helper.load_template('resources/templates/utils/aws/main.tf'))
    cli_helper.write_file(utils_dir / 'outputs.tf',
        cli_helper.load_template('resources/templates/utils/aws/outputs.tf'))


def create_aws_pipeline_templates(aws_region: str) -> None:
    """Create AWS-specific CI/CD pipeline templates using AWSShellScript@1 tasks."""
    yaml_dir = Path('templates/yaml')

    cli_helper.write_file(yaml_dir / 'build-terraform.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/build-terraform.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'deploy-terraform.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/deploy-terraform.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'environments.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/environments.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'alz-environments.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/alz-environments.yml.template', aws_region=aws_region))

    cli_helper.write_file(yaml_dir / 'run-terraform-checks.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/run-terraform-checks.yml.template'))

    cli_helper.write_file(yaml_dir / 'create-s3-backend.yml',
        cli_helper.load_template('resources/templates/pipelines/aws/create-s3-backend.yml.template'))


def create_aws_scaffold_templates() -> None:
    """Create scaffold templates for new stacks (AWS)."""
    scaffold_tf = Path('templates/scaffold/terraform')
    scaffold_yaml = Path('templates/scaffold/yaml')

    for fname in ['providers.tf', 'variables.tf', 'data.tf', 'locals.tf', 'outputs.tf']:
        cli_helper.write_file(scaffold_tf / fname,
            cli_helper.load_template(f'resources/templates/terraform/aws/{fname}.template'))

    cli_helper.write_file(scaffold_tf / 'main_intro.tf',
        cli_helper.load_template('resources/templates/terraform/aws/main.tf.template'))

    cli_helper.write_file(scaffold_tf / 'README.md', """\
# Stack Scaffold Template

This directory contains template files for creating new infrastructure stacks.

## Files

- `terraform/` - Terraform configuration templates
- `yaml/` - Azure Pipeline YAML templates (using AWS tasks)
- `azure-pipelines.yml` - Main pipeline configuration

## Usage

Use the CLI tool to generate new stacks based on these templates:

```bash
ign add-stack --stack-name <name>
```
""")

    for fname in ['build.yml', 'deploy.yml', 'state.yml']:
        cli_helper.write_file(scaffold_yaml / fname,
            cli_helper.load_template(f'resources/templates/yaml/aws/{fname}.template'))


def create_utils_module(project_code: str):
    """Create the templates/utils naming module."""
    
    utils_dir = Path('templates/utils')
    
    # variables.tf
    variables_content = """variable "location" {
  description = "Azure region for naming"
  type        = string
}

variable "project" {
  description = "Project name"
  type        = string
}

variable "lz" {
  description = "Landing zone code"
  type        = string
}

variable "suffix" {
  description = "Suffix for naming"
  type        = string
}

variable "lz_short" {
  description = "Short landing zone code"
  type        = string
  default     = ""
}
"""
    cli_helper.write_file(utils_dir / 'variables.tf', variables_content)
    
    # main.tf
    main_content = """locals {
  location_short_map = {
    "uksouth" = "uks"
    "ukwest"  = "ukw"
    "eastus"  = "eus"
    "westus"  = "wus"
  }

  location_short = lookup(local.location_short_map, var.location, "uks")
}
"""
    cli_helper.write_file(utils_dir / 'main.tf', main_content)
    
    # outputs.tf
    outputs_content = """output "name" {
  description = "Standardized names for Azure resources"
  value = {
    resource_group       = "rg-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    storage_account      = "st${local.location_short}${var.project}${var.lz}${var.suffix}"
    key_vault            = "kv-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    databricks_workspace = "dbw-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    data_factory         = "adf-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    virtual_network      = "vnet-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    sql_server           = "sql-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
    app_service          = "app-${local.location_short}-${var.project}-${var.lz}-${var.suffix}"
  }
}

output "lz" {
  description = "Landing zone code"
  value       = var.lz
}

output "location_short" {
  description = "Short location code"
  value       = local.location_short
}
"""
    cli_helper.write_file(utils_dir / 'outputs.tf', outputs_content)


def create_pipeline_templates():
    """Create CI/CD pipeline templates."""
    
    yaml_dir = Path('templates/yaml')
    
    # Load ADO pipeline templates from files
    environments_content = cli_helper.load_template('resources/templates/pipelines/ado/environments.yml.template')
    cli_helper.write_file(yaml_dir / 'environments.yml', environments_content)
    
    build_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/build-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'build-terraform.yml', build_terraform_content)
    
    deploy_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/deploy-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'deploy-terraform.yml', deploy_terraform_content)
    
    checks_content = cli_helper.load_template('resources/templates/pipelines/ado/run-terraform-checks.yml.template')
    cli_helper.write_file(yaml_dir / 'run-terraform-checks.yml', checks_content)
    
    alz_environments_content = cli_helper.load_template('resources/templates/pipelines/ado/alz-environments.yml.template')
    cli_helper.write_file(yaml_dir / 'alz-environments.yml', alz_environments_content)

    copy_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/copy-terraform-code.yml.template')
    cli_helper.write_file(yaml_dir / 'copy-terraform-code.yml', copy_terraform_content)

    environment_sign_off_content = cli_helper.load_template('resources/templates/pipelines/ado/environments-sign-off.yml.template')
    cli_helper.write_file(yaml_dir / 'environments-sign-off.yml', environment_sign_off_content)

    pr_sign_off_content = cli_helper.load_template('resources/templates/pipelines/ado/pr-validation.yml.template')
    cli_helper.write_file(yaml_dir / 'pr-validation.yml', pr_sign_off_content)

    summary_terraform_content = cli_helper.load_template('resources/templates/pipelines/ado/summary-terraform.yml.template')
    cli_helper.write_file(yaml_dir / 'summary-terraform.yml', summary_terraform_content)


def create_scaffold_templates(include_yaml: bool = True):
    """Create scaffold templates for new stacks.

    include_yaml=False skips the Azure DevOps YAML scaffold (GitHub Actions
    projects use templates/scaffold/github instead)."""
    
    scaffold_dir = Path('templates/scaffold/terraform')
    
    # Load scaffold terraform templates from files
    data_content = cli_helper.load_template('resources/templates/terraform/base/data.tf.template')
    cli_helper.write_file(scaffold_dir / 'data.tf', data_content)
    
    locals_content = cli_helper.load_template('resources/templates/terraform/base/locals.tf.template')
    cli_helper.write_file(scaffold_dir / 'locals.tf', locals_content)
    
    main_content = cli_helper.load_template('resources/templates/terraform/base/main_intro.tf.template')
    cli_helper.write_file(scaffold_dir / 'main_intro.tf', main_content)
    
    outputs_content = cli_helper.load_template('resources/templates/terraform/base/outputs.tf.template')
    cli_helper.write_file(scaffold_dir / 'outputs.tf', outputs_content)

    providers_content = cli_helper.load_template('resources/templates/terraform/base/providers.tf.template')
    cli_helper.write_file(scaffold_dir / 'providers.tf', providers_content)

    variables_content = cli_helper.load_template('resources/templates/terraform/base/variables.tf.template')
    cli_helper.write_file(scaffold_dir / 'variables.tf', variables_content)


    if include_yaml:
        scaffoldyaml_dir = Path('templates/scaffold/yaml')

        # Load scaffold yaml templates from files
        build_content = cli_helper.load_template('resources/templates/yaml/build.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'build.yml', build_content)

        deploy_content = cli_helper.load_template('resources/templates/yaml/deploy.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'deploy.yml', deploy_content)

        state_content = cli_helper.load_template('resources/templates/yaml/state.yml.template')
        cli_helper.write_file(scaffoldyaml_dir / 'state.yml', state_content)

    pipeline_line = (
        "- `yaml/` - Azure Pipeline YAML templates\n- `azure-pipelines.yml` - Main pipeline configuration"
        if include_yaml else
        "- `../github/stack-workflow.yml` - GitHub Actions caller workflow written to `.github/workflows/<stack>.yml`"
    )

    # Scaffold README
    readme = f"""# Stack Scaffold Template

This directory contains template files for creating new infrastructure stacks.

## Files

- `terraform/` - Terraform configuration templates
{pipeline_line}

## Usage

Use the CLI tool to generate new stacks based on these templates:

```bash
ign add-stack --stack-name <name>
```
"""
    cli_helper.write_file(scaffold_dir / 'README.md', readme)


# =============================================================================
# GitHub Actions (Azure) support
# =============================================================================

def _find_resource_dir(rel_path: str) -> Optional[Path]:
    """Locate a directory bundled under resources/ (source checkout or installed package)."""
    import sys
    import site

    rel = Path(rel_path)
    candidates = [
        Path(__file__).parent / rel,
        Path(__file__).resolve().parent / rel,
        Path.cwd() / rel,
        Path(sys.prefix) / rel,
        Path(sys.prefix) / 'share' / rel,
    ]
    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            candidates.append(Path(site.USER_BASE) / rel)
        for site_dir in site.getsitepackages():
            candidates.append(Path(site_dir) / rel)
    except (AttributeError, OSError):
        pass
    for c in candidates:
        if c.is_dir():
            return c
    return None


def _github_settings() -> Dict[str, str]:
    """GitHub settings for the current project with sensible fallbacks."""
    settings = _load_project_settings()
    return {
        'github_org': settings.get('github_org') or '<GITHUB_ORG>',
        'cicd_repo': settings.get('cicd_repo') or DEFAULT_CICD_REPO,
        'cicd_ref': settings.get('cicd_ref') or DEFAULT_CICD_REF,
    }


def create_github_pipeline_templates(github_org: str, cicd_repo: str, cicd_ref: str,
                                     github_repo: Optional[str] = None) -> None:
    """Write the GitHub Actions scaffold used by add-stack, plus the manual OIDC setup script."""
    workflow = cli_helper.load_template(
        'resources/templates/pipelines/github/stack-workflow.yml.template',
        github_org=github_org, cicd_repo=cicd_repo, cicd_ref=cicd_ref,
    )
    # {stack_name} is intentionally left in place - it is filled in by add-stack.
    cli_helper.write_file(Path('templates/scaffold/github/stack-workflow.yml'), workflow)

    cli_helper.write_file(
        Path('scripts/setup-github-oidc.ps1'),
        cli_helper.load_template('resources/templates/pipelines/github/scripts/setup-github-oidc.ps1'),
    )

    # Repo hygiene files - never overwrite ones the team already has.
    # .gitattributes matters: the tf-*.sh scripts run on Linux runners and
    # must be committed with LF line endings.
    for name in ('.gitattributes', '.gitignore', 'CODEOWNERS'):
        target = Path(name)
        if target.exists():
            console.print(f"  [dim]↷ {name} exists - left unchanged[/dim]")
            continue
        cli_helper.write_file(target, cli_helper.load_template(
            f'resources/templates/pipelines/github/consumer/{name}', github_org=github_org,
            github_repo=github_repo or Path.cwd().name))


def generate_github_workflow(stack_name: str) -> Path:
    """Create .github/workflows/<stack>.yml for a stack.

    Uses the project's scaffold (templates/scaffold/github/stack-workflow.yml)
    when present so teams can customise it, else the bundled template."""
    gh = _github_settings()
    scaffold = Path('templates/scaffold/github/stack-workflow.yml')
    if scaffold.exists():
        content = scaffold.read_text(encoding='utf-8')
    else:
        content = cli_helper.load_template('resources/templates/pipelines/github/stack-workflow.yml.template', **gh)
    content = content.replace('{stack_name}', stack_name)
    workflow_path = Path('.github/workflows') / f'{stack_name}.yml'
    cli_helper.write_file(workflow_path, content)
    return workflow_path


def discover_script_templates() -> List[str]:
    """Discover available script template files dynamically from resources/templates/scripts."""
    import sys
    import site

    template_rel_path = Path('resources') / 'templates' / 'scripts'
    tf_iac_rel_path = Path('templates') / 'scripts'
    search_dirs = [
        # 1. Development: next to ignition.py
        Path(__file__).parent / template_rel_path,
        # 2. Current working directory
        Path.cwd() / template_rel_path,
        # 3. Sibling repository tf-iac-modules
        Path(__file__).resolve().parents[3] / 'tf-iac-modules' / tf_iac_rel_path,
        Path.cwd().parent / 'tf-iac-modules' / tf_iac_rel_path,
        # 4. Installed package: sys.prefix
        Path(sys.prefix) / template_rel_path,
        Path(sys.prefix) / 'share' / template_rel_path,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            search_dirs.append(Path(site.USER_BASE) / template_rel_path)
            search_dirs.append(Path(site.USER_BASE) / 'share' / template_rel_path)
    except (AttributeError, OSError, RuntimeError):
        # USER_BASE lookup is optional; ignore failures and continue best-effort discovery.
        pass

    try:
        for site_dir in site.getsitepackages():
            search_dirs.append(Path(site_dir) / template_rel_path)
    except (AttributeError, OSError):
        # Best-effort discovery: some Python environments do not expose
        # getsitepackages() or may deny access to site-package locations.
        # Continue with other search directories.
        pass

    found_files = set()
    for sdir in search_dirs:
        if sdir.is_dir():
            for item in sdir.iterdir():
                if item.is_file() and item.name != 'README.md' and not item.name.startswith('.'):
                    found_files.add(item.name)

    return sorted(found_files)


def discover_test_script_templates() -> List[str]:
    """Discover available test script template files dynamically from resources/templates/tests/scripts."""
    import sys
    import site

    template_rel_path = Path('resources') / 'templates' / 'tests' / 'scripts'
    tf_iac_rel_path = Path('templates') / 'tests' / 'scripts'
    search_dirs = [
        # 1. Development: next to ignition.py
        Path(__file__).parent / template_rel_path,
        # 2. Current working directory
        Path.cwd() / template_rel_path,
        # 3. Sibling repository tf-iac-modules
        Path(__file__).resolve().parents[3] / 'tf-iac-modules' / tf_iac_rel_path,
        Path.cwd().parent / 'tf-iac-modules' / tf_iac_rel_path,
        # 4. Installed package: sys.prefix
        Path(sys.prefix) / template_rel_path,
        Path(sys.prefix) / 'share' / template_rel_path,
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            search_dirs.append(Path(site.USER_BASE) / template_rel_path)
            search_dirs.append(Path(site.USER_BASE) / 'share' / template_rel_path)
    except Exception:
        # USER_BASE may be unavailable or inaccessible in some environments; ignore and continue discovery.
        pass

    try:
        for site_dir in site.getsitepackages():
            search_dirs.append(Path(site_dir) / template_rel_path)
    except Exception as e:
        # Best-effort discovery: some environments may not expose site-packages paths.
        console.print(f"[dim]Skipping site.getsitepackages() during template discovery: {e}[/dim]")

    found_files = set()
    for sdir in search_dirs:
        if sdir.is_dir():
            for item in sdir.iterdir():
                if item.is_file() and item.name != 'README.md' and not item.name.startswith('.'):
                    found_files.add(item.name)

    return sorted(found_files)


def copy_script_templates():
    """Copy script templates to the project."""
    
    scripts_dir = Path('templates/scripts')
    
    # Discover available script template files dynamically
    script_files = discover_script_templates()
    
    for script_file in script_files:
        try:
            script_content = cli_helper.load_template(f'resources/templates/scripts/{script_file}')
            cli_helper.write_file(scripts_dir / script_file, script_content)
        except FileNotFoundError:
            click.echo(f"⚠️  Warning: Script template not found: {script_file}")
    
    # Create README for scripts directory
    readme_content = """# Script Templates

This directory contains shell script templates for various Azure DevOps and Terraform operations.

## Azure Pipeline Scripts

### `azp-backend.sh`
Creates or updates Azure backend storage for Terraform state management. Sets up:
- Resource Group
- Storage Account with blob retention policies
- Storage Container for Terraform state files

### `azp-spn-generator.sh`
Creates or updates Service Principal Names (SPNs) with certificate-based authentication:
- Creates Key Vault for certificate storage
- Generates 10 SPNs with Owner role assignments
- Stores certificates securely in Key Vault

## Terraform Operation Scripts

### `tf-apply.sh`
Applies Terraform infrastructure changes with retry logic:
- Supports multiple var-file configurations
- Automatic retry on failure (up to 5 attempts)
- Special handling for firewall rules workspace

### `tf-destroy.sh`
Destroys Terraform infrastructure:
- Handles management group hierarchy cleanup
- Recursive deletion up to 6 levels deep
- Fallback manual cleanup on failure

### `tf-fmt.sh`
Formats Terraform files:
- Checks formatting across all files
- Shows differences
- Recursive formatting

### `tf-init.sh`
Initializes Terraform workspace:
- Configures Azure backend storage
- Sets up remote state management
- Handles subscription and storage account configuration

### `tf-install.sh`
Installs Terraform binary:
- Downloads Terraform 1.12.2 for Linux AMD64
- Extracts and installs to `/usr/local/bin`
- Sets up executable in system PATH

### `tf-plan.sh`
Generates Terraform execution plan:
- Supports environment-specific var files
- Special handling for firewall rules configurations
- Outputs plan file for apply stage

## Usage

These templates can be copied and customized for your specific Azure DevOps pipelines and Terraform workflows.
"""
    cli_helper.write_file(scripts_dir / 'README.md', readme_content)

    # Copy test script templates to templates/tests/scripts
    test_scripts_dir = Path('templates/tests/scripts')
    test_script_files = discover_test_script_templates()
    for test_script_file in test_script_files:
        try:
            test_script_content = cli_helper.load_template(f'resources/templates/tests/scripts/{test_script_file}')
            cli_helper.write_file(test_scripts_dir / test_script_file, test_script_content)
        except FileNotFoundError:
            click.echo(f"⚠️  Warning: Test script template not found: {test_script_file}")


def get_location_short(location: str) -> str:
    """Convert Azure location to short code."""
    location_map = {
        "uksouth": "uks",
        "ukwest": "ukw",
        "eastus": "eus",
        "westus": "wus",
        "swedencentral": "sdc",
    }
    return location_map.get(location.lower(), "uks")


def _create_aws_bootstrap_config(project_code: str, aws_region: str, project_name: str) -> None:
    """Create a minimal AWS bootstrap configuration file."""
    bootstrap_dir = Path('bootstrap/terraform')
    config_yaml = f"""# Global Variables
environment: "dev"
region: "{aws_region}"  # AWS region, e.g. eu-west-2, us-east-1
app_short: "{project_code}"
tags:
  environment: "dev"
  Creator: "{project_code}"
  ReviewDate: "YY/MM"

# State Variables (S3 backend)
accountId_state: "000000000000"  # AWS account ID for Terraform state bucket
stateBucketName: "tf-state-{project_code}"
stateBucketRegion: "{aws_region}"

# IAM Variables
accountId_application: "000000000000"  # AWS account ID for application deployment
accountName_application: "{project_name}"

# OIDC / IAM role Variables
iamRoleName_build: "iam-role-tf-build"
iamRoleName_deploy: "iam-role-tf-deploy"

# Optional CI variables
preventSelfReviewDeploy: false
deployApprovalRequired: false
"""
    cli_helper.write_file(bootstrap_dir / 'config.yaml', config_yaml)

    # Copy BOOTSTRAP-DOCUMENTATION.md template as README.md in project bootstrap directory
    try:
        doc_content = cli_helper.load_template('resources/bootstrap/BOOTSTRAP-DOCUMENTATION.md')
        cli_helper.write_file(bootstrap_dir / 'README.md', doc_content)
    except FileNotFoundError:
        pass


def _apply_cicd_to_bootstrap_config(config_yaml: str, cicd: str,
                                    github_org: Optional[str], github_repo: Optional[str],
                                    cicd_repo: Optional[str] = None) -> str:
    """Set the CI/CD platform keys in the bootstrap config.yaml text.

    Line-based so the comments in the template are preserved."""
    def set_key(text: str, key: str, value: str) -> str:
        pattern = re.compile(rf'^({re.escape(key)}:\s*)([^#\n]*?)(\s*(#.*)?)$', re.MULTILINE)
        if pattern.search(text):
            return pattern.sub(lambda m: f"{m.group(1)}{value}{m.group(3)}", text, count=1)
        return text

    config_yaml = set_key(config_yaml, 'cicdPlatform', f'"{cicd}"')
    if cicd == 'github':
        config_yaml = set_key(config_yaml, 'orgName_gh', f'"{github_org}"' if github_org else 'null')
        if github_repo:
            config_yaml = set_key(config_yaml, 'repositoryName_gh', f'"{github_repo}"')
        if cicd_repo:
            config_yaml = set_key(config_yaml, 'cicdRepoName_gh', f'"{cicd_repo}"')
        # No Azure DevOps resources for GitHub projects
        config_yaml = set_key(config_yaml, 'isFirstTimeDeployToADO', 'false')
        config_yaml = set_key(config_yaml, 'adoOrgUrl', 'null')
        config_yaml = set_key(config_yaml, 'adoProjectName', 'null')
        config_yaml = set_key(config_yaml, 'adoProjectDescription', 'null')
    else:
        # No GitHub resources for Azure DevOps projects
        config_yaml = set_key(config_yaml, 'isFirstTimeDeployToGH', 'false')
    return config_yaml


def create_bootstrap_config(project_code: str, location: str, project_name: str, cicd: str = 'ado',
                            github_org: Optional[str] = None, github_repo: Optional[str] = None,
                            cicd_repo: Optional[str] = None):
    """Create bootstrap configuration file in the project."""
    bootstrap_dir = Path('bootstrap/terraform')
    
    # Get location short code
    location_short = get_location_short(location)
    
    # Load config.yaml template and populate project-specific values
    config_yaml = cli_helper.load_template(
        'resources/bootstrap/terraform/config.yaml',
        location=location,
        location_short=location_short,
        project_code=project_code,
        project_name=project_name,
    )
    config_yaml = _apply_cicd_to_bootstrap_config(config_yaml, cicd, github_org, github_repo, cicd_repo)
    cli_helper.write_file(bootstrap_dir / 'config.yaml', config_yaml)
    
    # Create README.md for bootstrap directory using BOOTSTRAP-DOCUMENTATION.md template
    try:
        doc_content = cli_helper.load_template('resources/bootstrap/BOOTSTRAP-DOCUMENTATION.md')
        cli_helper.write_file(bootstrap_dir / 'README.md', doc_content)
    except FileNotFoundError:
        # README template is optional; continue bootstrap generation when it is not packaged.
        pass


def generate_aws_terraform_files(terraform_dir: Path, stack_name: str, description: str) -> None:
    """Generate Terraform files for a stack (AWS provider)."""

    for fname in ['providers.tf', 'variables.tf', 'data.tf', 'locals.tf', 'outputs.tf']:
        cli_helper.write_file(terraform_dir / fname,
            cli_helper.load_template(f'resources/templates/terraform/aws/{fname}.template'))

    cli_helper.write_file(terraform_dir / 'main.tf',
        cli_helper.load_template(
            'resources/templates/terraform/aws/main.tf.template',
            stack_name_upper=stack_name.upper().replace('-', '_'),
            description=description,
            stack_name=stack_name,
        ))

    tfvars_dir = terraform_dir / 'tfvars'
    cli_helper.create_directory(tfvars_dir)

    cli_helper.write_file(tfvars_dir / 'terraform.tfvars',
        cli_helper.load_template('resources/templates/terraform/aws/tfvars/terraform.tfvars.template'))

    for env in ['dev', 'tst', 'uat', 'prod']:
        cli_helper.write_file(tfvars_dir / f'{env}.tfvars',
            cli_helper.load_template(
                'resources/templates/terraform/aws/tfvars/env.tfvars.template',
                env=env,
                env_upper=env.upper(),
            ))


def generate_terraform_files(terraform_dir: Path, stack_name: str, description: str,
                            include_databricks: bool, include_storage: bool, include_keyvault: bool):
    """Generate Terraform files for a stack."""
    
    # Load and write base terraform files from templates
    providers_content = cli_helper.load_template('resources/templates/terraform/base/providers.tf.template')
    cli_helper.write_file(terraform_dir / 'providers.tf', providers_content)
    
    variables_content = cli_helper.load_template('resources/templates/terraform/base/variables.tf.template')
    cli_helper.write_file(terraform_dir / 'variables.tf', variables_content)
    
    # main.tf
    main_resources = []
    
    # Load main intro template
    main_intro = cli_helper.load_template(
        'resources/templates/terraform/base/main_intro.tf.template',
        stack_name_upper=stack_name.upper(),
        description=description,
        stack_name=stack_name
    )
    
    main_resources.append(main_intro)
    
    if include_storage:
        storage_module = cli_helper.load_template('resources/modules/azure/storage.tf')
        storage_module = storage_module.replace('{{resource_name}}', f'{stack_name}_storage')
        main_resources.append(storage_module)
    
    if include_keyvault:
        keyvault_module = cli_helper.load_template('resources/modules/azure/keyvault.tf')
        keyvault_module = keyvault_module.replace('{{resource_name}}', f'{stack_name}_keyvault')
        main_resources.append(keyvault_module)
    
    if include_databricks:
        databricks_module = cli_helper.load_template('resources/modules/azure/databricks.tf')
        databricks_module = databricks_module.replace('{{resource_name}}', f'{stack_name}_databricks')
        main_resources.append(databricks_module)
    
    cli_helper.write_file(terraform_dir / 'main.tf', '\n'.join(main_resources))
    
    # Load and write remaining terraform files from templates
    data_content = cli_helper.load_template('resources/templates/terraform/base/data.tf.template')
    cli_helper.write_file(terraform_dir / 'data.tf', data_content)
    
    outputs_content = cli_helper.load_template('resources/templates/terraform/base/outputs.tf.template')
    cli_helper.write_file(terraform_dir / 'outputs.tf', outputs_content)
    
    locals_content = cli_helper.load_template('resources/templates/terraform/base/locals.tf.template')
    cli_helper.write_file(terraform_dir / 'locals.tf', locals_content)
    
    # Create tfvars subdirectory
    tfvars_dir = terraform_dir / 'tfvars'
    cli_helper.create_directory(tfvars_dir)

    # terraform.tfvars
    terraform_tfvars_content = """# Common Terraform variables
# These values are shared across all environments
"""
    cli_helper.write_file(tfvars_dir / 'terraform.tfvars', terraform_tfvars_content)
    
    # Environment-specific tfvars
    environments = {
        'dev': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'dev',
        },
        'tst': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'tst',
        },
        'uat': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'uat',
        },
        'prd': {
            'subscription_id': '00000000-0000-0000-0000-000000000000',
            'management_subscription_id': '00000000-0000-0000-0000-000000000000',
            'environment': 'prd',
        },
    }
    
    for env, values in environments.items():
        env_content = f"""# {env.upper()} Environment Configuration

subscription_id            = "{values['subscription_id']}"
management_subscription_id = "{values['management_subscription_id']}"
location                   = "uksouth"
location_short             = "uks"
environment                = "{values['environment']}"
project                    = "edp"
enable_telemetry           = true
"""
        cli_helper.write_file(tfvars_dir / f'{env}.tfvars', env_content)
    
    # Location-specific tfvars
    locations = ['uks', 'ukw']
    for loc in locations:
        loc_name = 'uksouth' if loc == 'uks' else 'ukwest'
        loc_content = f"""# UK South Configuration
location       = "{loc_name}"
location_short = "{loc}"
"""
        cli_helper.write_file(tfvars_dir / f'{loc}.tfvars', loc_content)


def generate_yaml_files(yaml_dir: Path, stack_dir: Path, stack_name: str, service_connection: str, cloud: str = 'azure'):
    """Generate YAML pipeline files for a stack."""

    # build.yml
    build_content = cli_helper.load_template('resources/templates/yaml/build.yml.template')
    cli_helper.write_file(yaml_dir / 'build.yml', build_content)
    
    # deploy.yml
    deploy_content = cli_helper.load_template('resources/templates/yaml/deploy.yml.template')
    cli_helper.write_file(yaml_dir / 'deploy.yml', deploy_content)
    
    # state.yml — backend vars differ between Azure (Storage Account) and AWS (S3)
    if cloud == 'aws':
        state_content = cli_helper.load_template('resources/templates/yaml/aws/state.yml.template', stack_name=stack_name)
    else:
        state_content = cli_helper.load_template('resources/templates/yaml/state.yml.template', stack_name=stack_name)
    cli_helper.write_file(yaml_dir / 'state.yml', state_content)


def generate_azure_pipelines(stack_dir: Path, stack_name: str, service_connection: str):
    """Generate Azure Pipelines YAML for a stack."""
    
    pipeline_content = cli_helper.load_template(
        'resources/templates/yaml/azure-pipelines.yml.template',
        stack_name=stack_name,
        service_connection=service_connection
    )
    cli_helper.write_file(stack_dir / 'azure-pipelines.yml', pipeline_content)


@cli.command()
@click.option('--debug', is_flag=True, help='Show debug information about stack template search paths')
def list_stack_templates(debug: bool):
    """List all available stack templates.
    
    Stack templates are pre-configured infrastructure stacks that can be
    applied to your project. These provide starting points for common
    deployment patterns.
    """
    
    cloud = _detect_cloud_provider()
    cloud_label = "AWS" if cloud == 'aws' else "Azure"

    console.print()
    console.print(Rule(f"[bold cyan]🗂   Available Stack Templates ({cloud_label})[/bold cyan]", style="cyan"))
    console.print()

    # Show debug info if requested
    if debug:
        import sys
        import site
        console.print(f"[bold]🔍  Debug: Cloud platform detected as [cyan]{cloud_label}[/cyan]. Searching:[/bold]")
        search_paths = [
            Path(__file__).parent / 'resources' / 'modules' / 'stacks',
            Path.cwd() / 'resources' / 'modules' / 'stacks',
            Path(sys.prefix) / 'resources' / 'modules' / 'stacks',
            Path(sys.prefix) / 'share' / 'modules' / 'stacks',
        ]
        try:
            if hasattr(site, 'USER_BASE') and site.USER_BASE:
                search_paths.append(Path(site.USER_BASE) / 'resources' / 'modules' / 'stacks')
        except:
            pass
        try:
            for site_dir in site.getsitepackages():
                search_paths.append(Path(site_dir) / 'resources' / 'modules' / 'stacks')
        except:
            pass

        for path in search_paths:
            if path.exists():
                console.print(f"  [green]✅[/green]  {path}")
            else:
                console.print(f"  [red]❌[/red]  [dim]{path}[/dim]")
        console.print()

    # Discover stack templates for the detected cloud
    stack_templates = discover_stack_templates(cloud)
    
    if stack_templates:
        table = Table(
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="cyan",
            show_lines=False,
        )
        table.add_column("Template", style="bold green", no_wrap=True)
        table.add_column("Terraform", justify="center", width=12)
        table.add_column("YAML", justify="center", width=8)
        table.add_column("Scripts", justify="center", width=10)
        table.add_column("Pipeline", justify="center", width=10)
        
        for template_name, stack_path in sorted(stack_templates.items()):
            has_terraform = (stack_path / 'terraform').exists()
            has_yaml = (stack_path / 'yaml').exists()
            has_scripts = (stack_path / 'scripts').exists()
            has_pipeline = (stack_path / 'azure-pipelines.yml').exists()
            
            tf_icon = "[green]✓[/green]" if has_terraform else "[dim]–[/dim]"
            yaml_icon = "[green]✓[/green]" if has_yaml else "[dim]–[/dim]"
            scripts_icon = "[green]✓[/green]" if has_scripts else "[dim]–[/dim]"
            pipeline_icon = "[green]✓[/green]" if has_pipeline else "[dim]–[/dim]"
            table.add_row(template_name, tf_icon, yaml_icon, scripts_icon, pipeline_icon)
        
        console.print(table)
    else:
        console.print("[yellow]⚠️   No stack templates found[/yellow]")
        console.print("\n[dim]💡 Tip: Run with --debug flag to see search paths:[/dim]")
        console.print("   [bold]ign list-stack-templates --debug[/bold]")
    
    console.print(f"\n[dim]To add a stack template:[/dim] [bold]ign add-stack-template --stack-name <name>[/bold]")
    console.print()


@cli.command()
@click.option('--stack-name', prompt='Stack template name', help='Name of the stack template to add')
def add_stack_template(stack_name: str):
    """Add a stack template to the current project.
    
    This command copies a pre-configured stack template from the templates library
    into your project's stacks/ directory (or landing-zones/ for ALZ stacks). 
    Useful for quickly scaffolding common deployment patterns.
    """
    
    console.print(Panel(
        f"[bold white]Template:[/bold white] [cyan]{stack_name}[/cyan]",
        title="[bold cyan]🗂   Adding Stack Template[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False
    ))
    console.print()
    
    # Check if we're in a project directory
    stacks_dir = Path('stacks')
    if not stacks_dir.exists():
        console.print("[bold red]❌  Error:[/bold red] [red]Not in a project directory. Run [bold]ign init[/bold] first.[/red]")
        console.print("[dim]Or navigate to a directory with a 'stacks/' folder.[/dim]")
        return
    
    # Determine target directory based on stack name
    # If stack name starts with "alz", use landing-zones directory
    is_alz_stack = stack_name.lower().startswith('alz')
    if is_alz_stack:
        target_dir = Path('landing-zones')
        # Create landing-zones directory if it doesn't exist
        if not target_dir.exists():
            cli_helper.create_directory(target_dir)
    else:
        target_dir = stacks_dir
    
    # Check if stack already exists
    dest_path = target_dir / stack_name
    if dest_path.exists():
        if not click.confirm(f"Warning: Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Aborted.[/yellow]")
            return
    
    # Discover available stacks for the current cloud platform
    available_stacks = discover_stack_templates(_detect_cloud_provider())

    if not available_stacks:
        console.print("[bold red]❌  Error:[/bold red] [red]No stack templates found[/red]")
        console.print("\n[dim]Run [bold]ign list-stack-templates[/bold] to see available templates[/dim]")
        return
    
    if stack_name not in available_stacks:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack template '{stack_name}' not found[/red]")
        console.print(f"\n[bold]Available stack templates:[/bold]")
        for name in sorted(available_stacks.keys()):
            console.print(f"  [green]•[/green]  {name}")
        console.print(f"\n[dim]Run [bold]ign list-stack-templates[/bold] for more details[/dim]")
        return
    
    # Copy the stack
    if copy_stack_template(stack_name, dest_path):
        # If this is an ALZ stack, ensure environments.yml exists in landing-zones root
        if is_alz_stack:
            create_landing_zones_environments_file(target_dir)
        
        # Generate configuration guide for the copied stack
        terraform_dir = dest_path / 'terraform'
        yaml_dir = dest_path / 'yaml'
        # Only generate if at least one of the directories exists
        if terraform_dir.exists() or yaml_dir.exists():
            generate_configuration_guide(dest_path, terraform_dir, yaml_dir)
        
        location_path = f"{target_dir.name}/{stack_name}/"
        console.print()
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="bold cyan", no_wrap=True)
        grid.add_column()
        grid.add_row("1.", "Review and customize the stack configuration")
        grid.add_row("2.", "Update variable values in [bold]terraform/tfvars/*.tfvars[/bold] files")
        grid.add_row("3.", "Review Azure Pipeline configuration")
        console.print(Panel(
            grid,
            title=f"[bold green]✅  Stack Template '{stack_name}' Added Successfully![/bold green]",
            title_align="left",
            style="green",
            expand=False
        ))
        console.print(f"[dim]Stack location:[/dim] [bold]{location_path}[/bold]")
        console.print()
    else:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Failed to add stack template '{stack_name}'[/red]")


def discover_stack_templates(cloud: str = 'azure') -> Dict[str, Path]:
    """
    Discover available stack templates from the modules/stacks directory for the given cloud.
    Returns a dict mapping stack names to their directory paths.
    """
    import sys
    import site

    stacks = {}
    stack_dirs = [
        # 1. Development: next to ignition.py
        Path(__file__).parent / 'resources' / 'modules' / 'stacks',
        # 2. Current working directory
        Path.cwd() / 'resources' / 'modules' / 'stacks',
        # 3. Installed package: sys.prefix
        Path(sys.prefix) / 'resources' / 'modules' / 'stacks',
        Path(sys.prefix) / 'share' / 'modules' / 'stacks',
    ]

    try:
        if hasattr(site, 'USER_BASE') and site.USER_BASE:
            stack_dirs.append(Path(site.USER_BASE) / 'resources' / 'modules' / 'stacks')
            stack_dirs.append(Path(site.USER_BASE) / 'share' / 'modules' / 'stacks')
    except Exception:
        pass

    try:
        for site_dir in site.getsitepackages():
            stack_dirs.append(Path(site_dir) / 'resources' / 'modules' / 'stacks')
    except Exception:
        pass

    for stack_dir in stack_dirs:
        if not stack_dir.exists():
            continue

        for stack_path in stack_dir.iterdir():
            if stack_path.is_dir():
                stack_name = stack_path.name
                if stack_name not in stacks and _detect_stack_platform(stack_path) == cloud:
                    stacks[stack_name] = stack_path

    return stacks


def copy_stack_template(stack_name: str, destination: Path) -> bool:
    """
    Copy a stack template from modules/stacks to the destination directory.
    Handles symlinks, special files, and missing files gracefully.
    Returns True if successful, False otherwise.
    """
    available_stacks = discover_stack_templates(_detect_cloud_provider())
    
    if stack_name not in available_stacks:
        console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack_name}' not found in available templates[/red]")
        return False
    
    source_dir = available_stacks[stack_name]
    
    try:
        import shutil
        
        def copy_with_handling(src: Path, dst: Path):
            """Recursively copy directory tree, handling symlinks and special files."""
            # Skip if source doesn't exist
            if not src.exists():
                console.print(f"  [yellow]⚠️   Warning: Source does not exist: {src}[/yellow]")
                return
            
            # Handle symlinks
            if src.is_symlink():
                try:
                    target = src.readlink()
                    # Resolve absolute path if relative
                    if not target.is_absolute():
                        target = src.parent / target
                    
                    if target.exists():
                        if target.is_dir():
                            # Copy the directory that symlink points to
                            copy_with_handling(target, dst)
                        else:
                            # Copy the file that symlink points to
                            shutil.copy2(target, dst, follow_symlinks=False)
                    else:
                        console.print(f"  [yellow]⚠️   Skipping broken symlink:[/yellow] [dim]{src} → {target}[/dim]")
                except Exception as e:
                    console.print(f"  [yellow]⚠️   Skipping symlink {src}:[/yellow] [dim]{e}[/dim]")
            elif src.is_dir():
                # Create directory and copy contents
                dst.mkdir(parents=True, exist_ok=True)
                for item in src.iterdir():
                    # Skip special files and directories
                    if item.name in ['.git', '__pycache__', '.DS_Store']:
                        continue
                    try:
                        copy_with_handling(item, dst / item.name)
                    except Exception as e:
                        console.print(f"  [yellow]⚠️   Skipping {item}:[/yellow] [dim]{e}[/dim]")
            elif src.is_file():
                # Copy regular file
                try:
                    shutil.copy2(src, dst, follow_symlinks=False)
                except (OSError, shutil.Error, FileNotFoundError) as e:
                    console.print(f"  [yellow]⚠️   Could not copy {src}:[/yellow] [dim]{e}[/dim]")
            else:
                # Skip special files (sockets, pipes, etc.)
                console.print(f"  [yellow]⚠️   Skipping special file:[/yellow] [dim]{src}[/dim]")
        
        # Ensure destination parent exists
        destination.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy the directory tree
        copy_with_handling(source_dir, destination)
        return True
    except Exception as e:
        console.print(f"[bold red]❌  Error copying stack template:[/bold red] [red]{e}[/red]")
        import traceback
        traceback.print_exc()
        return False


def create_landing_zones_environments_file(landing_zones_dir: Path):
    """
    Create environments.yml file in the landing-zones directory root if it doesn't exist.
    """
    environments_file = landing_zones_dir / 'environments.yml'
    
    # Only create if it doesn't exist
    if environments_file.exists():
        return
    
    environments_content = """parameters:
  - name: buildTemplatePath
    default: ""
  - name: deployTemplatePath
    default: ""
  - name: landingZone
    default: ""
  - name: serviceConnection
    default: ""
  - name: UkSouth
  - name: UkWest

  
stages:
- ${{ if eq(parameters.UkSouth, 'Yes') }}:
  - stage: BuildUKSouth
    displayName: BUILD UK South - Terraform Plan
    jobs:
      - template: ${{ parameters.buildTemplatePath }}
        parameters:
          serviceConnection:  ${{ parameters.serviceConnection }}
          stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
          landingZone: ${{ parameters.landingZone }}
          environment: "uks"
          agentPool: ""
          location: "UkSouth"

- ${{ if eq(parameters.UkWest, 'Yes') }}:
  - stage: BuildUKWest
    displayName: BUILD UK West - Terraform Plan
    condition: ${{ eq(parameters.UkWest, 'Yes') }}  
    jobs:
      - template: ${{ parameters.buildTemplatePath }}
        parameters:
          serviceConnection:  ${{ parameters.serviceConnection }}
          stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
          landingZone: ${{ parameters.landingZone }}
          environment: "ukw"
          agentPool: ""
          location: "UKWest"
          

- ${{ if eq(parameters.UkSouth, 'Yes') }}:
  - stage: DeployUKSouth
    displayName: DEPLOY UK South - Terraform Apply
    dependsOn: [BuildUKSouth]
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')
    jobs:
    - template: '${{ parameters.deployTemplatePath }}'
      parameters:
        serviceConnection:  ${{ parameters.serviceConnection }}
        stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
        landingZone: ${{ parameters.landingZone }}
        environment: "uks"
        agentPool: ""
        location: "UkSouth"



- ${{ if eq(parameters.UkWest, 'Yes') }}:
  - stage: DeployUKWest
    displayName: DEPLOY UK West - Terraform Apply
    condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')
    dependsOn: [BuildUKWest]
    jobs:
    - template: '${{ parameters.deployTemplatePath }}'
      parameters:
        serviceConnection:  ${{ parameters.serviceConnection }}
        stateServiceConnection: "SUB-GROUP-MANAGEMENT-PR-SC"
        landingZone: ${{ parameters.landingZone }}
        environment: "ukw"
        agentPool: ""
        location: "UKWest"
  
"""
    cli_helper.write_file(environments_file, environments_content)


def generate_configuration_guide(stack_dir: Path, terraform_dir: Path, yaml_dir: Path):
    """
    Generate a CONFIGURATION.md file in the stack directory that lists
    all files that need to be updated with subscription IDs and other configuration.
    """
    stack_name = stack_dir.name
    cicd = _detect_cicd_platform()
    
    config_guide_lines = [
        f"# Configuration Guide - {stack_name}",
        "",
        "This document lists all files that need to be updated with your specific configuration values before deploying this stack.",
        "",
        "## ⚠️ Required Updates",
        "",
        "Before deploying this stack, you must update the following files with your Azure subscription IDs and other configuration values:",
        "",
    ]
    
    if cicd == 'github':
        gh = _github_settings()
        config_guide_lines.extend([
            "### 1. GitHub Actions (`.github/workflows/" + stack_name + ".yml`)",
            "",
            f"The workflow calls the shared reusable pipeline `{gh['github_org']}/{gh['cicd_repo']}` "
            f"pinned to `{gh['cicd_ref']}`. Pin it to a release tag (or full commit SHA) before going live.",
            "",
            "Identity and Terraform state settings are read from **GitHub environment variables**. "
            "Create these environments in the repository (Settings → Environments) and set the variables on each:",
            "",
            "| Environment | Used by | `AZURE_CLIENT_ID` |",
            "|---|---|---|",
            "| `dev`, `prd` | CI + plan jobs | build identity client ID |",
            "| `dev/apply`, `prd/apply` | apply job (add required reviewers) | deploy identity client ID |",
            "",
            "Variables required on every environment:",
            "",
            "- **`AZURE_CLIENT_ID`**: client ID of the managed identity (see table above)",
            "- **`AZURE_TENANT_ID`**: Microsoft Entra tenant ID",
            "- **`AZURE_SUBSCRIPTION_ID`**: subscription this stack deploys into",
            "- **`TF_STATE_SUBSCRIPTION_ID`**: subscription holding the Terraform state storage account",
            "- **`TF_STATE_RESOURCE_GROUP`**: resource group of the state storage account",
            "- **`TF_STATE_STORAGE_ACCOUNT`**: state storage account name",
            "- **`TF_STATE_CONTAINER`**: state blob container",
            "",
            f"The state blob key defaults to `stacks/{stack_name}/terraform/<environment>.tfstate`.",
            "",
            "`ign bootstrap --apply` writes `bootstrap/BOOTSTRAP-OUTPUTS-<env>.md` containing the exact "
            "`gh variable set` commands. Without bootstrap, use `scripts/setup-github-oidc.ps1`.",
            "",
            "Optional repository secret **`MODULE_REPO_PAT`**: read token for private Terraform module repositories.",
            "",
        ])

    # Check for state.yml file
    if cicd != 'github' and yaml_dir.exists():
        state_file = yaml_dir / 'state.yml'
        if state_file.exists():
            config_guide_lines.extend([
                "### 1. State Configuration (`yaml/state.yml`)",
                "",
                "Update the Terraform state backend configuration:",
                "",
                "- **`stateSubscriptionId`**: Your Azure subscription ID for Terraform state storage",
                "- **`stateResourceGroupName`**: Resource group name where Terraform state is stored",
                "- **`stateStorageAccountName`**: Storage account name for Terraform state",
                "- **`stateStorageAccountContainerName`**: Container name for Terraform state files",
                "",
                "Example:",
                "```yaml",
                "variables:",
                "  - name: stateSubscriptionId",
                "    value: 'your-subscription-id-here'",
                "  - name: stateResourceGroupName",
                "    value: 'rg-terraform-state'",
                "  - name: stateStorageAccountName",
                "    value: 'stterraformstate'",
                "  - name: stateStorageAccountContainerName",
                "    value: 'tfstate'",
                "```",
                "",
            ])
    
    # Find all .tfvars files
    tfvars_files = []
    tfvars_subdir = terraform_dir / 'tfvars'
    if tfvars_subdir.exists():
        tfvars_files = sorted(tfvars_subdir.glob('*.tfvars'))
    elif terraform_dir.exists():
        tfvars_files = sorted(terraform_dir.glob('*.tfvars'))
    
    if tfvars_files:
        config_guide_lines.extend([
            "### 2. Terraform Variable Files (`terraform/tfvars/*.tfvars`)",
            "",
            "Update the following `.tfvars` files with your subscription IDs:",
            "",
        ])
        
        for tfvars_file in tfvars_files:
            file_name = tfvars_file.name
            config_guide_lines.append(f"- **`terraform/tfvars/{file_name}`**")
            
            # Provide specific guidance based on file name
            if file_name in ['dev.tfvars', 'tst.tfvars', 'uat.tfvars', 'prd.tfvars']:
                env_name = file_name.replace('.tfvars', '').upper()
                config_guide_lines.extend([
                    f"  - Update `subscription_id` with your {env_name} environment subscription ID",
                    f"  - Update `management_subscription_id` if applicable",
                ])
            elif file_name in ['uks.tfvars', 'ukw.tfvars']:
                loc_name = "UK South" if 'uks' in file_name else "UK West"
                config_guide_lines.append(f"  - Location-specific variables for {loc_name}")
            elif file_name == 'terraform.tfvars':
                config_guide_lines.append("  - Common variables shared across all environments")
            else:
                config_guide_lines.append("  - Update subscription IDs and other configuration values as needed")
            
            config_guide_lines.append("")
        
        config_guide_lines.extend([
            "Example for environment-specific files (e.g., `dev.tfvars`):",
            "```hcl",
            "subscription_id            = \"your-subscription-id-here\"",
            "management_subscription_id = \"your-management-subscription-id-here\"",
            "location                   = \"uksouth\"",
            "environment                = \"dev\"",
            "```",
            "",
        ])
    
    if cicd == 'github':
        pipeline_note = (f"- **Workflow**: Review `.github/workflows/{stack_name}.yml` - branch triggers, "
                         "environments (add `tst`/`uat` jobs if needed) and the pinned CI/CD ref")
    else:
        pipeline_note = ("- **Service Connection**: Check `azure-pipelines.yml` and ensure the service connection "
                         "name matches your Azure DevOps configuration")

    # Additional configuration notes
    config_guide_lines.extend([
        "## 📝 Additional Configuration",
        "",
        "You may also need to update:",
        "",
        pipeline_note,
        "- **Resource Names**: Review and customize resource names in `terraform/main.tf` if needed",
        "- **Variables**: Review `terraform/variables.tf` for any additional variables that need values",
        "",
        "## ✅ Verification",
        "",
        "After updating the configuration files:",
        "",
        "1. Verify all subscription IDs are correct",
        "2. Ensure state backend configuration points to the correct storage account",
        "3. Review environment-specific values in `.tfvars` files",
        "4. Test with `terraform plan` before applying changes",
        "",
        "## 📚 Resources",
        "",
        "- [Azure Subscription IDs](https://docs.microsoft.com/en-us/azure/azure-portal/get-subscription-tenant-id)",
        "- [Terraform State Backend](https://www.terraform.io/docs/language/settings/backends/azurerm.html)",
        "",
    ])
    
    config_guide_content = '\n'.join(config_guide_lines)
    config_guide_path = stack_dir / 'CONFIGURATION.md'
    cli_helper.write_file(config_guide_path, config_guide_content)


@cli.command()
@click.option('--stack', default=None, help='Name of the stack to validate (e.g. dlz, dmz)')
@click.option('--all', 'validate_all', is_flag=True, default=False, help='Validate all stacks and templates in the project')
@click.option('--config', 'yamllint_config', default=None, help='Path to a custom yamllint config file')
def validate(stack: str, validate_all: bool, yamllint_config: str):
    """Validate YAML files in a stack or across the whole project.

    Checks every .yml / .yaml file for syntax errors and linting issues.
    Use --stack to target one stack, or --all to scan everything.
    """
    try:
        from yamllint import linter as yamllinter
        from yamllint.config import YamlLintConfig
    except ImportError:
        console.print("[bold red]❌  Error:[/bold red] [red]yamllint is required but not installed.[/red]")
        console.print("   Install it with: [bold]pip install yamllint[/bold]")
        return

    # ------------------------------------------------------------------
    # Resolve scope
    # ------------------------------------------------------------------
    if not stack and not validate_all:
        console.print()
        choice = click.prompt(
            "Validate a single stack or the whole project?",
            type=click.Choice(['stack', 'project'], case_sensitive=False),
            default='stack',
        )
        if choice == 'stack':
            stack = click.prompt('Stack name')
        else:
            validate_all = True

    # Collect target directories
    scan_dirs: list[Path] = []
    project_root = Path.cwd()

    if validate_all:
        scan_dirs.append(project_root)
        scope_label = "Whole Project"
    else:
        stack_dir = _resolve_stack_dir(stack, project_root)
        if stack_dir is None:
            console.print(f"[bold red]❌  Error:[/bold red] [red]Stack '{stack}' not found.[/red]")
            console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
            return
        scan_dirs.append(stack_dir)
        scope_label = f"Stack: {stack}"

    # ------------------------------------------------------------------
    # Build yamllint config
    # ------------------------------------------------------------------
    if yamllint_config:
        cfg_path = Path(yamllint_config)
        if not cfg_path.exists():
            console.print(f"[bold red]❌  Error:[/bold red] [red]Config file not found: {yamllint_config}[/red]")
            return
        lint_cfg = YamlLintConfig(file=str(cfg_path))
    else:
        # Sensible defaults for Azure Pipelines / Terraform YAML
        lint_cfg = YamlLintConfig("""\
extends: default
rules:
  line-length:
    max: 250
    level: warning
  truthy:
    allowed-values: ['true', 'false', 'yes', 'no', 'on', 'off']
    level: warning
  comments:
    min-spaces-from-content: 1
    level: warning
  indentation:
    spaces: 2
    indent-sequences: whatever
    check-multi-line-strings: false
  document-start: disable
""")

    # ------------------------------------------------------------------
    # Discover YAML files
    # ------------------------------------------------------------------
    yaml_files: list[Path] = []
    skip_dirs = {'.git', '__pycache__', '.terraform', 'node_modules'}
    for scan_dir in scan_dirs:
        for pattern in ('**/*.yml', '**/*.yaml'):
            for f in scan_dir.glob(pattern):
                if not any(part in skip_dirs for part in f.parts):
                    yaml_files.append(f)

    yaml_files = sorted(set(yaml_files))

    if not yaml_files:
        console.print(Panel(
            f"[yellow]No YAML files found in scope:[/yellow] [bold]{scope_label}[/bold]",
            style="yellow", expand=False
        ))
        return

    # ------------------------------------------------------------------
    # Header
    # ------------------------------------------------------------------
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Files found:[/bold white] [cyan]{len(yaml_files)}[/cyan]",
        title="[bold cyan]🔍  Validating YAML[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    # ------------------------------------------------------------------
    # Lint each file
    # ------------------------------------------------------------------
    results_table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        border_style="cyan",
        show_lines=False,
        expand=True,
    )
    results_table.add_column("File", style="white", no_wrap=False, ratio=5)
    results_table.add_column("Status", justify="center", width=12)
    results_table.add_column("Errors", justify="right", width=8)
    results_table.add_column("Warnings", justify="right", width=10)

    total_errors = 0
    total_warnings = 0
    files_ok = 0
    files_with_issues: list[tuple[Path, list]] = []

    for yaml_file in yaml_files:
        try:
            content = yaml_file.read_text(encoding='utf-8')
        except Exception as e:
            results_table.add_row(
                str(yaml_file.relative_to(project_root)),
                "[red]READ ERROR[/red]",
                "[red]–[/red]", "[red]–[/red]",
            )
            total_errors += 1
            continue

        problems = list(yamllinter.run(content, lint_cfg))
        errors = [p for p in problems if p.level == 'error']
        warnings = [p for p in problems if p.level == 'warning']

        total_errors += len(errors)
        total_warnings += len(warnings)

        try:
            rel = yaml_file.relative_to(project_root)
        except ValueError:
            rel = yaml_file

        if errors:
            status = "[bold red]✗  ERROR[/bold red]"
            files_with_issues.append((yaml_file, problems))
        elif warnings:
            status = "[yellow]⚠  WARN[/yellow]"
            files_with_issues.append((yaml_file, problems))
            files_ok += 1
        else:
            status = "[green]✓  OK[/green]"
            files_ok += 1

        err_cell = f"[red]{len(errors)}[/red]" if errors else "[dim]0[/dim]"
        warn_cell = f"[yellow]{len(warnings)}[/yellow]" if warnings else "[dim]0[/dim]"
        results_table.add_row(str(rel), status, err_cell, warn_cell)

    console.print(results_table)

    # ------------------------------------------------------------------
    # Detail panel for files with issues
    # ------------------------------------------------------------------
    if files_with_issues:
        console.print()
        console.print(Rule("[bold]Issue Details[/bold]", style="dim"))
        for yaml_file, problems in files_with_issues:
            try:
                rel = yaml_file.relative_to(project_root)
            except ValueError:
                rel = yaml_file

            issue_table = Table(
                box=box.SIMPLE,
                show_header=True,
                header_style="bold",
                pad_edge=False,
            )
            issue_table.add_column("Line", style="dim", width=6, justify="right")
            issue_table.add_column("Col", style="dim", width=5, justify="right")
            issue_table.add_column("Level", width=10)
            issue_table.add_column("Message")

            for p in problems:
                level_str = "[red]error[/red]" if p.level == 'error' else "[yellow]warning[/yellow]"
                issue_table.add_row(str(p.line), str(p.column), level_str, p.message)

            console.print(f"\n  [bold white]{rel}[/bold white]")
            console.print(issue_table)

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    console.print()
    files_errored = sum(1 for _, problems in files_with_issues if any(p.level == 'error' for p in problems))
    files_warned = sum(1 for _, problems in files_with_issues if not any(p.level == 'error' for p in problems))

    summary_grid = Table.grid(padding=(0, 3))
    summary_grid.add_column(style="bold", no_wrap=True)
    summary_grid.add_column()
    summary_grid.add_row("[cyan]Files checked[/cyan]", str(len(yaml_files)))
    summary_grid.add_row("[green]✓  Valid[/green]", str(len(yaml_files) - files_errored))
    summary_grid.add_row("[yellow]⚠  Warnings[/yellow]", str(files_warned))
    summary_grid.add_row("[red]✗  Errors[/red]", str(files_errored))

    if files_errored:
        summary_style = "red"
        summary_title = "[bold red]✗  Validation Failed[/bold red]"
    elif files_warned:
        summary_style = "yellow"
        summary_title = "[bold yellow]⚠  Validation Passed with Warnings[/bold yellow]"
    else:
        summary_style = "green"
        summary_title = "[bold green]✅  All YAML Files Valid[/bold green]"

    console.print(Panel(
        summary_grid,
        title=summary_title,
        title_align="left",
        style=summary_style,
        expand=False,
    ))
    console.print()

    if files_errored:
        raise click.exceptions.Exit(code=1)



# =============================================================================
# Secret scanning patterns (module-level, used by `secrets` command)
# =============================================================================

_SECRET_PATTERNS = [
    (re.compile(r"DefaultEndpointsProtocol=https?;AccountName=", re.I),
     "Azure Storage connection string", "critical"),
    (re.compile(r"[?&]sig=[A-Za-z0-9+/%]{20,}"),
     "SAS token", "critical"),
    (re.compile(r"-----BEGIN\s+(?:RSA\s+|EC\s+)?PRIVATE KEY-----"),
     "Private key", "critical"),
    (re.compile(
        r'(?i)(?:password|secret|client_secret|access_key|account_key|api_key|pat|token)'
        r'\s*[=:]\s*["\x27](?!\$\{|var\.|local\.|module\.)[^"\x27]{8,}["\x27]'
    ), "Potential hardcoded credential", "high"),
    (re.compile(
        r'(?i)(?:subscription_id|tenant_id|client_id)\s*=\s*"'
        r'(?!00000000-0000-0000-0000-000000000000)'
        r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"'
    ), "Real subscription/tenant/client ID", "medium"),
]

_SEVERITY_COLOUR = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "dim yellow",
}
_SCAN_EXTENSIONS = {".tf", ".tfvars", ".yml", ".yaml", ".json", ".env", ".sh", ".ps1"}
_SKIP_DIRS = {".git", "__pycache__", ".terraform", "node_modules", ".tfsec"}
_PLACEHOLDER_UUID = "00000000-0000-0000-0000-000000000000"


# =============================================================================
# ign doctor
# =============================================================================

@cli.command()
def doctor():
    """Check your environment is correctly set up to use ign."""
    import subprocess
    import sys
    import importlib.metadata

    console.print(Panel(
        "[white]Checks tools, authentication, Python packages and project structure.[/white]",
        title="[bold cyan]🩺  Environment Health Check[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    checks = []  # (name, status, detail, action)

    pv = sys.version_info
    ver_str = f"{pv.major}.{pv.minor}.{pv.micro}"
    checks.append(("Python", "ok" if pv >= (3, 7) else "error", ver_str,
                   "" if pv >= (3, 7) else "Upgrade to >= 3.7"))

    try:
        r = subprocess.run(["terraform", "--version"], capture_output=True, text=True, timeout=10)
        checks.append(("Terraform", "ok", r.stdout.strip().split("\n")[0], ""))
    except FileNotFoundError:
        checks.append(("Terraform", "error", "Not installed",
                       "https://developer.hashicorp.com/terraform/install"))
    except Exception as e:
        checks.append(("Terraform", "warning", str(e), ""))

    az_ok = False
    try:
        r = subprocess.run(["az", "--version"], capture_output=True, text=True, timeout=10)
        az_ok = r.returncode == 0
        checks.append(("Azure CLI", "ok", r.stdout.strip().split("\n")[0], ""))
    except FileNotFoundError:
        checks.append(("Azure CLI", "warning", "Not installed", "https://aka.ms/installazurecli"))
    except Exception as e:
        checks.append(("Azure CLI", "warning", str(e), ""))

    if az_ok:
        try:
            r = subprocess.run(
                ["az", "account", "show", "--query", "name", "-o", "tsv"],
                capture_output=True, text=True, timeout=15,
            )
            if r.returncode == 0 and r.stdout.strip():
                checks.append(("Azure Auth", "ok", r.stdout.strip(), ""))
            else:
                checks.append(("Azure Auth", "warning", "Not authenticated", "Run: az login"))
        except Exception as e:
            checks.append(("Azure Auth", "warning", str(e), ""))

    try:
        r = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=10)
        checks.append(("git", "ok", r.stdout.strip(), ""))
    except FileNotFoundError:
        checks.append(("git", "warning", "Not found", "https://git-scm.com"))

    for dist, imp in [
        ("click", "click"), ("PyYAML", "yaml"), ("rich", "rich"),
        ("yamllint", "yamllint"), ("checkov", "checkov"),
    ]:
        try:
            __import__(imp)
            try:
                ver = importlib.metadata.version(dist)
            except Exception:
                ver = "installed"
            checks.append((f"pkg: {dist}", "ok", ver, ""))
        except ImportError:
            checks.append((f"pkg: {dist}", "error", "Not installed", f"pip install {dist}"))

    import shutil as _shutil
    import platform as _platform
    if _shutil.which("tfsec"):
        try:
            r = subprocess.run(["tfsec", "--version"], capture_output=True, text=True, timeout=10)
            checks.append(("tfsec", "ok", r.stdout.strip() or "installed", ""))
        except Exception:
            checks.append(("tfsec", "ok", "installed", ""))
    else:
        _os = _platform.system()
        if _os == "Windows":
            hint = "choco install tfsec  OR  winget install tfsec"
        elif _os == "Darwin":
            hint = "brew install tfsec"
        else:
            hint = "https://aquasecurity.github.io/tfsec/latest/getting-started/installation/"
        checks.append(("tfsec", "warning", "Not installed", hint))

    for label, p, hint in [
        ("stacks/",    Path("stacks"),    "Run: ign init"),
        ("bootstrap/", Path("bootstrap"), "Run: ign init"),
        ("templates/", Path("templates"), "Run: ign init"),
    ]:
        if p.exists():
            items = list(p.iterdir())
            checks.append((label, "ok", f"{len(items)} item(s)", ""))
        else:
            checks.append((label, "warning", "Not found", hint))

    table = Table(box=box.ROUNDED, header_style="bold cyan", border_style="cyan", show_lines=False)
    table.add_column("Check", style="bold white", no_wrap=True, min_width=22)
    table.add_column("Status", justify="center", width=10)
    table.add_column("Detail")
    table.add_column("Action", style="dim cyan")

    ok_n = warn_n = err_n = 0
    for name, status, detail, action in checks:
        if status == "ok":
            cell = "[green]✓  OK[/green]"; ok_n += 1
        elif status == "warning":
            cell = "[yellow]⚠  WARN[/yellow]"; warn_n += 1
        else:
            cell = "[red]✗  FAIL[/red]"; err_n += 1
        table.add_row(name, cell, detail, action)

    console.print(table)
    console.print()

    if err_n:
        style, title = "red", "[bold red]✗  Issues Found — Fix Errors Before Proceeding[/bold red]"
    elif warn_n:
        style, title = "yellow", "[bold yellow]⚠  Environment Ready with Warnings[/bold yellow]"
    else:
        style, title = "green", "[bold green]✅  All Checks Passed — Good to Go![/bold green]"

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[green]✓  Passed[/green]", str(ok_n))
    g.add_row("[yellow]⚠  Warnings[/yellow]", str(warn_n))
    g.add_row("[red]✗  Errors[/red]", str(err_n))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


# =============================================================================
# ign secrets
# =============================================================================

@cli.command()
@click.option("--stack", default=None, help="Scan a specific stack")
@click.option("--all", "scan_all", is_flag=True, help="Scan the whole project")
def secrets(stack, scan_all):
    """Scan for accidentally committed secrets and credentials."""
    project_root = Path.cwd()

    if not stack and not scan_all:
        choice = click.prompt(
            "Scan a stack or whole project?",
            type=click.Choice(["stack", "project"], case_sensitive=False),
            default="project",
        )
        scan_all = choice == "project"
        if not scan_all:
            stack = click.prompt("Stack name")

    if scan_all:
        scan_root = project_root
        scope_label = "Whole Project"
    else:
        scan_root = _resolve_stack_dir(stack, project_root)
        if scan_root is None:
            console.print(f"[bold red]❌  Stack '{stack}' not found.[/bold red]")
            return
        scope_label = f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]",
        title="[bold cyan]🔐  Secret Scanner[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    files = [
        f for f in scan_root.rglob("*")
        if f.is_file()
        and f.suffix in _SCAN_EXTENSIONS
        and not any(part in _SKIP_DIRS for part in f.parts)
    ]

    findings = []
    for fpath in sorted(files):
        try:
            lines = fpath.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue
        for lineno, line in enumerate(lines, 1):
            for pattern, label, severity in _SECRET_PATTERNS:
                if pattern.search(line):
                    snippet = line.strip()[:80]
                    try:
                        rel = str(fpath.relative_to(project_root))
                    except ValueError:
                        rel = str(fpath)
                    findings.append((rel, lineno, label, snippet, severity))

    if not findings:
        console.print(Panel(
            "[bold green]No secrets or credentials detected.[/bold green]\n"
            "[dim]This does not guarantee absence of secrets — always review before pushing.[/dim]",
            title="[bold green]✅  Scan Clean[/bold green]",
            title_align="left",
            style="green",
            expand=False,
        ))
        console.print()
        return

    crit = high = med = low = 0
    console.print()
    for rel, lineno, label, snippet, severity in findings:
        colour = _SEVERITY_COLOUR.get(severity, "white")
        badge  = f"[{colour}] {severity.upper():<8} [/{colour}]"
        console.print(f"  {badge}  [bold white]{label}[/bold white]")
        console.print(f"            [cyan]{rel}[/cyan][dim]:{lineno}[/dim]")
        console.print(f"            [dim italic]{snippet}[/dim italic]")
        console.print()
        if severity == "critical":   crit += 1
        elif severity == "high":     high += 1
        elif severity == "medium":   med  += 1
        else:                        low  += 1
    console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[bold red]Critical[/bold red]",    str(crit))
    g.add_row("[red]High[/red]",                  str(high))
    g.add_row("[yellow]Medium[/yellow]",          str(med))
    g.add_row("[dim yellow]Low[/dim yellow]",     str(low))
    g.add_row("[white]Total findings[/white]",    str(len(findings)))

    sev_style = "red" if (crit or high) else "yellow"
    console.print(Panel(
        g,
        title=f"[bold {sev_style}]⚠  {len(findings)} Potential Secret(s) Found — Review Before Pushing![/bold {sev_style}]",
        title_align="left",
        style=sev_style,
        expand=False,
    ))
    console.print()

    # Exit non-zero so CI gates (e.g. ign pr-check) actually fail when secrets
    # are detected, rather than silently passing.
    raise click.exceptions.Exit(code=1)


# =============================================================================
# ign compare  (helper + command)
# =============================================================================

def _strip_inline_comment(val: str) -> str:
    """Strip a trailing ``#`` or ``//`` inline comment that is outside quotes."""
    in_quote = None
    for i, ch in enumerate(val):
        if in_quote:
            if ch == in_quote:
                in_quote = None
        elif ch in ('"', "'"):
            in_quote = ch
        elif ch == "#":
            return val[:i]
        elif ch == "/" and i + 1 < len(val) and val[i + 1] == "/":
            return val[:i]
    return val


def _parse_tfvars(path):
    """Parse a .tfvars file into a dict of key/value strings."""
    result = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("//"):
                continue
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = _strip_inline_comment(val.strip()).strip()
            if len(val) >= 2 and val[0] in ('"', "'") and val[-1] == val[0]:
                val = val[1:-1]
            result[key] = val
    except Exception:
        pass
    return result


@cli.command()
@click.option("--stack", default=None, help="Stack name")
@click.option("--envs",  default=None, help="Comma-separated envs to compare (e.g. dev,prd)")
def compare(stack, envs):
    """Compare .tfvars files across environments for a stack.

    Highlights every variable that differs between dev / tst / uat / prd.
    """
    if not stack:
        stack = click.prompt("Stack name")

    resolved = _resolve_stack_dir(stack)
    if resolved is None or not (resolved / "terraform").exists():
        console.print(f"[bold red]❌  Stack '{stack}' not found.[/bold red]")
        console.print("[dim]Run [bold]ign list-stacks[/bold] to see available stacks.[/dim]")
        return
    stack_dir = resolved / "terraform"

    # Support both terraform/tfvars/ subdirectory and terraform/ root
    tfvars_dir = stack_dir / "tfvars" if (stack_dir / "tfvars").exists() else stack_dir

    # When --envs isn't given, auto-discover whatever <target>.tfvars files
    # exist so this works for both lifecycle envs (dev/tst/uat/prd) and
    # region-based landing zones (uks/ukw/...).
    env_list = (
        [e.strip() for e in envs.split(",") if e.strip()]
        if envs
        else _discover_env_tfvars(tfvars_dir)
    )

    if not env_list:
        console.print(f"[yellow]⚠  No .tfvars files found in [bold]{tfvars_dir}[/bold][/yellow]")
        console.print("[dim]Expected one or more <target>.tfvars files — lifecycle envs "
                      "(dev.tfvars, prd.tfvars) or regions (uks.tfvars, ukw.tfvars).[/dim]")
        return

    env_data = {}
    missing  = []
    for env in env_list:
        fpath = tfvars_dir / f"{env}.tfvars"
        if fpath.exists():
            env_data[env] = _parse_tfvars(fpath)
        else:
            missing.append(env)
            env_data[env] = {}

    if missing:
        console.print(f"[yellow]⚠  Missing tfvars for: {', '.join(missing)}[/yellow]")

    all_keys = sorted({k for d in env_data.values() for k in d})
    if not all_keys:
        console.print("[yellow]⚠  No variables found in tfvars files.[/yellow]")
        return

    console.print(Panel(
        f"[bold white]Stack:[/bold white] [cyan]{stack}[/cyan]   "
        f"[bold white]Environments:[/bold white] [cyan]{' | '.join(e.upper() for e in env_list)}[/cyan]",
        title="[bold cyan]📊  Environment Comparison[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Variable", style="bold white", no_wrap=True, ratio=3)
    for env in env_list:
        table.add_column(env.upper(), ratio=3)

    diffs = 0
    for key in all_keys:
        vals    = [env_data[env].get(key) for env in env_list]
        present = [v for v in vals if v is not None]
        is_diff = len(set(present)) > 1 or len(present) < len(env_list)
        if is_diff:
            diffs += 1
        cells = []
        for v in vals:
            if v is None:
                cells.append("[dim]— missing —[/dim]")
            elif is_diff:
                cells.append(f"[yellow]{v}[/yellow]")
            else:
                cells.append(f"[dim]{v}[/dim]")
        table.add_row(key, *cells)

    console.print(table)
    console.print()

    style = "yellow" if diffs else "green"
    title = (
        f"[bold yellow]⚠  {diffs} variable(s) differ across environments[/bold yellow]"
        if diffs else
        "[bold green]✅  All variables are consistent across environments[/bold green]"
    )
    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("Variables checked",       str(len(all_keys)))
    g.add_row("[yellow]Differ[/yellow]",  str(diffs))
    g.add_row("[green]Consistent[/green]", str(len(all_keys) - diffs))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


# =============================================================================
# ign status
# =============================================================================

@cli.command()
def status():
    """Show a live dashboard of every stack and its readiness."""
    import subprocess

    stack_paths = _iter_all_stacks()
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory.[/bold red] Run [bold]ign init[/bold] first.")
        return

    if not stack_paths:
        console.print("[yellow]No stacks found.[/yellow]")
        return

    project_root = Path.cwd()
    git_ok = False
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, cwd=str(project_root),
        )
        git_ok = r.returncode == 0
    except FileNotFoundError:
        pass

    console.print(Panel(
        f"[bold white]Project:[/bold white] [cyan]{project_root.name}[/cyan]   "
        f"[bold white]Stacks:[/bold white] [cyan]{len(stack_paths)}[/cyan]",
        title="[bold cyan]📊  Project Status Dashboard[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",        style="bold white", no_wrap=True)
    table.add_column("Terraform",    justify="center", width=11)
    table.add_column("YAML",         justify="center", width=8)
    table.add_column("Pipeline",     justify="center", width=10)
    table.add_column("Resources",    justify="right",  width=11)
    table.add_column("Last Changed", width=18, style="dim")

    total_res  = 0
    yaml_errors = 0
    try:
        from yamllint import linter as _yl2
        from yamllint.config import YamlLintConfig as _YLC2
        _yl2_cfg = _YLC2(
            "extends: default\nrules:\n  line-length: disable\n  document-start: disable\n"
        )
        yl2_ok = True
    except ImportError:
        yl2_ok = False

    for spath in stack_paths:
        sname     = spath.name
        tf_dir    = spath / "terraform"
        yaml_dir  = spath / "yaml"
        pipe_file = _stack_pipeline_file(spath, project_root)

        tf_cell   = "[green]✓[/green]" if tf_dir.exists()    else "[red]✗[/red]"
        if _detect_cicd_platform(project_root) == 'github':
            yaml_cell = "[dim]n/a[/dim]"  # GitHub stacks have no per-stack yaml/ dir
        else:
            yaml_cell = "[green]✓[/green]" if yaml_dir.exists()  else "[red]✗[/red]"
        pipe_cell = "[green]✓[/green]" if pipe_file.exists() else "[dim]—[/dim]"

        res_count = 0
        main_tf = tf_dir / "main.tf"
        if main_tf.exists():
            try:
                content   = main_tf.read_text(encoding="utf-8")
                res_count = len(re.findall(r'^(?:resource|module)\s+"', content, re.MULTILINE))
                total_res += res_count
            except Exception:
                pass
        res_cell = str(res_count) if res_count else "[dim]—[/dim]"

        last_changed = "[dim]—[/dim]"
        if git_ok:
            try:
                r = subprocess.run(
                    ["git", "log", "-1", "--format=%cr", "--", str(spath)],
                    capture_output=True, text=True, cwd=str(project_root),
                )
                if r.returncode == 0 and r.stdout.strip():
                    last_changed = r.stdout.strip()
            except Exception:
                pass

        if yl2_ok and yaml_dir.exists():
            for f in list(yaml_dir.glob("*.yml")) + list(yaml_dir.glob("*.yaml")):
                try:
                    probs = [p for p in _yl2.run(f.read_text(encoding="utf-8"), _yl2_cfg)
                             if p.level == "error"]
                    yaml_errors += len(probs)
                except Exception:
                    pass

        table.add_row(sname, tf_cell, yaml_cell, pipe_cell, res_cell, last_changed)

    console.print(table)
    console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("Stacks",                    str(len(stack_paths)))
    g.add_row("Total resources / modules", str(total_res))
    g.add_row(
        "YAML errors",
        f"[red]{yaml_errors}[/red]" if yaml_errors else "[green]0[/green]",
    )
    style = "yellow" if yaml_errors else "green"
    title = (
        "[bold yellow]⚠  YAML Issues — run ign validate for details[/bold yellow]"
        if yaml_errors else
        "[bold green]✅  Project Looks Healthy[/bold green]"
    )
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()


# =============================================================================
# ign lint-tf
# =============================================================================

@cli.command("lint-tf")
@click.option("--stack", default=None, help="Stack to lint")
@click.option("--all",   "lint_all", is_flag=True, help="Lint all stacks")
@click.option("--fix",   is_flag=True, help="Auto-format with terraform fmt (modifies files)")
def lint_tf(stack, lint_all, fix):
    """Run terraform fmt and validate across one or all stacks.

    Use --fix to automatically reformat rather than just report.
    validate is skipped for stacks not yet initialised (no .terraform/).
    """
    import subprocess
    import os
    import json as _json

    if not stack and not lint_all:
        choice = click.prompt(
            "Lint a stack or all stacks?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        if choice == "stack":
            stack = click.prompt("Stack name")
        else:
            lint_all = True

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target = (
        [p.name for p in _iter_all_stacks()]
        if lint_all else [stack]
    )
    scope_label = "All Stacks" if lint_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Mode:[/bold white] [cyan]{'fix (auto-format)' if fix else 'check only'}[/cyan]",
        title="[bold cyan]🔧  Terraform Linter[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",    style="bold white", no_wrap=True)
    table.add_column("fmt",      justify="center", width=14)
    table.add_column("validate", justify="center", width=22)
    table.add_column("Notes",    style="dim")

    original_dir = Path.cwd()
    ok_n = warn_n = err_n = 0

    for sname in target:
        tf_dir = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        if not tf_dir.exists():
            table.add_row(sname, "[dim]—[/dim]", "[dim]—[/dim]", "No terraform/ directory")
            warn_n += 1
            continue

        fmt_args = ["terraform", "fmt"]
        if not fix:
            fmt_args.append("-check")
        fmt_args.append(str(tf_dir))

        fmt_cell      = "[dim]—[/dim]"
        validate_cell = "[dim]—[/dim]"
        notes         = ""

        try:
            r = subprocess.run(fmt_args, capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                fmt_cell = "[cyan]✓  Fixed[/cyan]" if fix else "[green]✓  OK[/green]"
            else:
                fmt_cell = "[red]✗  fmt failed[/red]" if fix else "[yellow]⚠  Needs fmt[/yellow]"
                notes = (r.stderr or r.stdout).strip()[:60]
        except FileNotFoundError:
            fmt_cell = "[red]✗  not found[/red]"
            notes    = "Terraform not installed"
            table.add_row(sname, fmt_cell, "[dim]—[/dim]", notes)
            err_n += 1
            continue
        except Exception as e:
            fmt_cell = "[red]✗  error[/red]"
            notes    = str(e)[:60]

        if (tf_dir / ".terraform").exists():
            try:
                os.chdir(tf_dir)
                r = subprocess.run(
                    ["terraform", "validate", "-json"],
                    capture_output=True, text=True, timeout=30,
                )
                os.chdir(original_dir)
                if r.returncode == 0:
                    validate_cell = "[green]✓  Valid[/green]"
                else:
                    try:
                        vdata = _json.loads(r.stdout)
                        errs  = [d for d in vdata.get("diagnostics", [])
                                 if d.get("severity") == "error"]
                        validate_cell = f"[red]✗  {len(errs)} error(s)[/red]"
                        if errs:
                            notes = errs[0].get("summary", "")[:60]
                    except Exception:
                        validate_cell = "[red]✗  failed[/red]"
            except Exception as e:
                os.chdir(original_dir)
                validate_cell = "[red]✗  error[/red]"
                notes         = str(e)[:60]
        else:
            validate_cell = "[dim]skipped (run terraform init)[/dim]"

        has_err  = "✗" in (fmt_cell + validate_cell)
        has_warn = "⚠" in fmt_cell or "skipped" in validate_cell
        if has_err:    err_n  += 1
        elif has_warn: warn_n += 1
        else:          ok_n   += 1

        table.add_row(sname, fmt_cell, validate_cell, notes)

    console.print(table)
    console.print()

    if err_n:
        style = "red"
        title = f"[bold red]✗  {err_n} stack(s) with errors[/bold red]"
        console.print(Panel(title, title_align="left", style=style, expand=False))
        raise click.exceptions.Exit(code=1)
    elif warn_n and not fix:
        hint = Table.grid(padding=(0, 2))
        hint.add_column()
        hint.add_row("[dim]Run [bold]ign lint-tf --fix[/bold] (or [bold]--all --fix[/bold]) to auto-format.[/dim]")
        console.print(Panel(
            hint,
            title=f"[bold yellow]⚠  {warn_n} stack(s) need formatting[/bold yellow]",
            title_align="left", style="yellow", expand=False,
        ))
    else:
        console.print(Panel(
            "[bold green]✅  All Terraform Files Pass[/bold green]",
            title_align="left", style="green", expand=False,
        ))
    console.print()


# =============================================================================
# ign upgrade  (helpers + command)
# =============================================================================

def _fetch_latest_tf_provider_version(source):
    """Query the Terraform Registry for the latest version of a provider."""
    import urllib.request
    import json as _json

    parts = source.strip().split("/")
    if len(parts) != 2:
        return None
    namespace, ptype = parts
    url = f"https://registry.terraform.io/v1/providers/{namespace}/{ptype}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ign-cli/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
            return data.get("version")
    except Exception:
        return None


def _parse_providers_tf(path):
    """Extract provider entries from a providers.tf file."""
    providers = []
    try:
        content = path.read_text(encoding="utf-8")
        rp = re.search(r"required_providers\s*\{((?:[^{}]|\{[^{}]*\})*)\}", content, re.DOTALL)
        if not rp:
            return providers
        block = rp.group(1)
        for m in re.finditer(r'(\w+)\s*=\s*\{([^}]+)\}', block, re.DOTALL):
            name  = m.group(1)
            body  = m.group(2)
            src_m = re.search(r'source\s*=\s*"([^"]+)"', body)
            ver_m = re.search(r'version\s*=\s*"([^"]+)"', body)
            if src_m:
                providers.append({
                    "name":    name,
                    "source":  src_m.group(1),
                    "version": ver_m.group(1) if ver_m else "unset",
                })
    except Exception:
        pass
    return providers


@cli.command()
@click.option("--stack",  default=None, help="Check a specific stack")
@click.option("--all",    "upgrade_all", is_flag=True, help="Check all stacks")
@click.option("--apply",  "do_apply",   is_flag=True, help="Write updated versions to providers.tf")
def upgrade(stack, upgrade_all, do_apply):
    """Check Terraform provider versions against the registry and optionally update them."""
    if not stack and not upgrade_all:
        choice = click.prompt(
            "Check a stack or all stacks?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="all",
        )
        upgrade_all = choice == "all"
        if not upgrade_all:
            stack = click.prompt("Stack name")

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target      = (
        [p.name for p in _iter_all_stacks()]
        if upgrade_all else [stack]
    )
    scope_label = "All Stacks" if upgrade_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]   "
        f"[bold white]Mode:[/bold white] [cyan]{'apply updates' if do_apply else 'check only'}[/cyan]",
        title="[bold cyan]⬆   Provider Version Checker[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    console.print("[dim]Querying Terraform Registry...[/dim]\n")

    table = Table(
        box=box.ROUNDED, header_style="bold cyan", border_style="cyan",
        show_lines=False, expand=True,
    )
    table.add_column("Stack",    style="bold white", no_wrap=True)
    table.add_column("Provider", style="white")
    table.add_column("Current",  style="dim", justify="center", width=20)
    table.add_column("Latest",   justify="center", width=12)
    table.add_column("Status",   justify="center", width=18)

    updates_available = 0
    updates_applied   = 0

    for sname in target:
        tf_dir       = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        providers_tf = tf_dir / "providers.tf"
        if not providers_tf.exists():
            table.add_row(sname, "[dim]No providers.tf[/dim]", "—", "—", "[dim]—[/dim]")
            continue

        providers = _parse_providers_tf(providers_tf)
        if not providers:
            table.add_row(sname, "[dim]No providers found[/dim]", "—", "—", "[dim]—[/dim]")
            continue

        for prov in providers:
            latest  = _fetch_latest_tf_provider_version(prov["source"])
            current = prov["version"]

            if latest is None:
                table.add_row(sname, prov["name"], current, "[dim]—[/dim]", "[dim]API unavailable[/dim]")
                continue

            current_base = re.sub(r"[>=<~! ]", "", current).split(",")[0].strip()
            outdated     = current_base != latest

            if outdated:
                updates_available += 1
                status_cell = f"[yellow]⬆  {latest} available[/yellow]"
                latest_cell = f"[yellow]{latest}[/yellow]"
            else:
                status_cell = "[green]✓  Up to date[/green]"
                latest_cell = f"[green]{latest}[/green]"

            table.add_row(sname, prov["name"], current, latest_cell, status_cell)

            if do_apply and outdated:
                try:
                    content = providers_tf.read_text(encoding="utf-8")
                    # Only rewrite the version *inside this provider's block* —
                    # anchoring on the provider name avoids clobbering other
                    # providers' versions or the terraform required_version.
                    pattern = re.compile(
                        r'(' + re.escape(prov["name"]) + r'\s*=\s*\{[^}]*?version\s*=\s*")([^"]+)(")',
                        re.DOTALL,
                    )
                    new_content, n = pattern.subn(
                        lambda m, lat=latest: f'{m.group(1)}{lat}{m.group(3)}',
                        content,
                        count=1,
                    )
                    if n:
                        providers_tf.write_text(new_content, encoding="utf-8")
                        updates_applied += 1
                    else:
                        console.print(
                            f"[yellow]⚠  Could not locate version for provider "
                            f"'{prov['name']}' in {providers_tf}[/yellow]"
                        )
                except Exception as e:
                    console.print(f"[red]Failed to update {providers_tf}: {e}[/red]")

    console.print(table)
    console.print()

    if updates_available == 0:
        console.print(Panel("[bold green]✅  All providers are up to date![/bold green]",
                            style="green", expand=False))
    elif do_apply:
        console.print(Panel(
            f"[bold green]✅  Applied {updates_applied} update(s) to providers.tf files.[/bold green]\n"
            "[dim]Run [bold]terraform init -upgrade[/bold] in each stack to download new providers.[/dim]",
            style="green", expand=False,
        ))
    else:
        console.print(Panel(
            f"[bold yellow]⬆   {updates_available} update(s) available.[/bold yellow]\n"
            "[dim]Run [bold]ign upgrade --apply[/bold] to update providers.tf files.[/dim]",
            style="yellow", expand=False,
        ))
    console.print()


# =============================================================================
# ign cost
# =============================================================================

@cli.command()
@click.option("--stack",  default=None, help="Stack to estimate costs for")
@click.option("--all",    "cost_all",   is_flag=True, help="Estimate costs for all stacks")
@click.option("--format", "out_fmt",
              default="table",
              type=click.Choice(["table", "json", "html"], case_sensitive=False),
              help="Infracost output format")
def cost(stack, cost_all, out_fmt):
    """Estimate infrastructure costs using Infracost.

    Requires Infracost: https://www.infracost.io/docs/
    """
    import subprocess

    try:
        r = subprocess.run(["infracost", "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            raise FileNotFoundError
        ver = (r.stdout or r.stderr).strip()
    except FileNotFoundError:
        console.print(Panel(
            "[red]infracost is not installed or not on your PATH.[/red]\n\n"
            "[dim]Install from:[/dim]  [bold]https://www.infracost.io/docs/#quick-start[/bold]\n"
            "[dim]Brew install:[/dim]  [bold]brew install infracost[/bold]\n"
            "[dim]After install:[/dim] [bold]infracost auth login[/bold]",
            title="[bold red]❌  infracost Not Found[/bold red]",
            title_align="left",
            style="red",
            expand=False,
        ))
        return

    if not stack and not cost_all:
        choice = click.prompt(
            "Estimate a stack or all stacks?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        cost_all = choice == "all"
        if not cost_all:
            stack = click.prompt("Stack name")

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target = (
        [p.name for p in _iter_all_stacks()]
        if cost_all else [stack]
    )

    console.print(Panel(
        f"[bold white]Scope:[/bold white]  [cyan]{'All Stacks' if cost_all else stack}[/cyan]\n"
        f"[bold white]Tool:[/bold white]   [cyan]{ver}[/cyan]",
        title="[bold cyan]💰  Cost Estimator[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    for sname in target:
        tf_dir = (_resolve_stack_dir(sname) or (stacks_dir / sname)) / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {sname}: no terraform/ directory[/yellow]")
            continue
        console.print(Rule(f"[bold]{sname}[/bold]", style="cyan"))
        subprocess.run(["infracost", "breakdown", "--path", str(tf_dir), "--format", out_fmt])
        console.print()

    console.print(Panel(
        "[dim]Costs are estimates. Actual costs may differ.[/dim]\n"
        "[dim]For a diff vs last run:[/dim] [bold]infracost diff --path <terraform-dir>[/bold]",
        style="dim",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign checklist
# =============================================================================

@cli.command()
@click.option("--stack", default=None, help="Stack to check")
@click.option("--all",   "check_all", is_flag=True, help="Check all stacks")
def checklist(stack, check_all):
    """Run a pre-deployment readiness checklist for a stack.

    Verifies files exist, placeholder values are replaced, YAML is valid,
    and the service connection has been customised.
    """
    if not stack and not check_all:
        choice = click.prompt(
            "Check a stack or all stacks?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        check_all = choice == "all"
        if not check_all:
            stack = click.prompt("Stack name")

    stacks_dir = Path("stacks")
    if not any((Path.cwd() / p).exists() for p in STACK_DIRS):
        console.print("[bold red]❌  No stacks/ directory found.[/bold red]")
        return

    target      = (
        [p.name for p in _iter_all_stacks()]
        if check_all else [stack]
    )
    scope_label = "All Stacks" if check_all else f"Stack: {stack}"

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope_label}[/cyan]",
        title="[bold cyan]📋  Pre-Deployment Checklist[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    try:
        from yamllint import linter as _yl3
        from yamllint.config import YamlLintConfig as _YLC3
        _yl3_cfg = _YLC3(
            "extends: default\nrules:\n  line-length: disable\n  document-start: disable\n"
        )
        yl3_ok = True
    except ImportError:
        yl3_ok = False

    total_pass = total_fail = total_warn = 0

    for sname in target:
        spath    = _resolve_stack_dir(sname) or (stacks_dir / sname)
        tf_dir   = spath / "terraform"
        yaml_dir = spath / "yaml"

        checks = []  # (item, "pass"|"fail"|"warn", detail)

        if _detect_cicd_platform() == 'github':
            pipeline_checks = [(f".github/workflows/{sname}.yml", Path(".github/workflows") / f"{sname}.yml")]
        else:
            pipeline_checks = [("yaml/ directory", yaml_dir),
                               ("azure-pipelines.yml", spath / "azure-pipelines.yml")]
        for label, p in [
            ("terraform/ directory",   tf_dir),
            *pipeline_checks,
            ("CONFIGURATION.md",       spath / "CONFIGURATION.md"),
            ("terraform/main.tf",      tf_dir / "main.tf"),
            ("terraform/variables.tf", tf_dir / "variables.tf"),
            ("terraform/providers.tf", tf_dir / "providers.tf"),
        ]:
            checks.append((label, "pass" if p.exists() else "fail",
                           "Found" if p.exists() else "Missing"))

        tfvars_search_dir = (tf_dir / "tfvars") if (tf_dir / "tfvars").exists() else tf_dir
        tfvars = list(tfvars_search_dir.glob("*.tfvars")) if tf_dir.exists() else []
        if tfvars:
            count = sum(
                f.read_text(encoding="utf-8", errors="ignore").count(_PLACEHOLDER_UUID)
                for f in tfvars
            )
            checks.append((
                "No placeholder UUIDs in tfvars",
                "pass" if count == 0 else "fail",
                "All replaced" if count == 0 else f"{count} placeholder(s) still present",
            ))
        else:
            checks.append(("tfvars files", "warn", "No .tfvars files found"))

        if yl3_ok and yaml_dir.exists():
            yaml_errs = sum(
                len([p for p in _yl3.run(f.read_text(encoding="utf-8", errors="ignore"), _yl3_cfg)
                     if p.level == "error"])
                for f in list(yaml_dir.glob("*.yml")) + list(yaml_dir.glob("*.yaml"))
            )
            checks.append((
                "YAML files valid",
                "pass" if yaml_errs == 0 else "fail",
                "No errors" if yaml_errs == 0 else f"{yaml_errs} error(s) — run ign validate",
            ))
        elif not yl3_ok:
            checks.append(("YAML lint", "warn", "yamllint not installed"))

        gh_wf = Path(".github/workflows") / f"{sname}.yml"
        if _detect_cicd_platform() == 'github' and gh_wf.exists():
            content = gh_wf.read_text(encoding="utf-8", errors="ignore")
            if "<GITHUB_ORG>" in content:
                checks.append(("CI/CD repo configured", "fail",
                               "<GITHUB_ORG> placeholder in workflow"))
            elif re.search(r"_terraform-pipeline\.yml@(main|develop)\b", content):
                checks.append(("CI/CD repo pinned", "warn",
                               "Workflow tracks a branch - pin to a release tag or SHA"))
            else:
                checks.append(("CI/CD repo pinned", "pass", "Pinned"))

        pipe = spath / "azure-pipelines.yml"
        if pipe.exists():
            content = pipe.read_text(encoding="utf-8", errors="ignore")
            if "DataPlatform - Dev" in content or "YOUR_SERVICE_CONNECTION" in content:
                checks.append(("Service connection customised", "warn",
                                "Default/placeholder value in azure-pipelines.yml"))
            else:
                checks.append(("Service connection customised", "pass", "Looks customised"))

        console.print(Rule(f"[bold white]{sname}[/bold white]", style="cyan"))
        for item, status, detail in checks:
            if status == "pass":
                icon = "[green]✓[/green]"; total_pass += 1
            elif status == "fail":
                icon = "[red]✗[/red]";    total_fail += 1
            else:
                icon = "[yellow]⚠[/yellow]"; total_warn += 1
            console.print(f"  {icon}  [white]{item}[/white]  [dim]{detail}[/dim]")
        console.print()

    if total_fail:
        style, title = "red",    f"[bold red]✗  Not Ready — {total_fail} check(s) failed[/bold red]"
    elif total_warn:
        style, title = "yellow", f"[bold yellow]⚠  Ready with {total_warn} warning(s)[/bold yellow]"
    else:
        style, title = "green",  "[bold green]✅  All Checks Passed — Ready to Deploy![/bold green]"

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    g.add_row("[green]✓  Passed[/green]",     str(total_pass))
    g.add_row("[yellow]⚠  Warnings[/yellow]", str(total_warn))
    g.add_row("[red]✗  Failed[/red]",         str(total_fail))
    console.print(Panel(g, title=title, title_align="left", style=style, expand=False))
    console.print()

    if total_fail:
        raise click.exceptions.Exit(code=1)


# =============================================================================
# ign scaffold
# =============================================================================

@cli.command()
def scaffold():
    """Interactive step-by-step wizard to scaffold a complete infrastructure stack.

    Guides you through project initialisation (if needed), stack naming,
    Azure resource selection, and generates all Terraform and pipeline files.
    """
    console.print(Panel(
        "[white]This wizard guides you through creating a fully configured\n"
        "infrastructure stack with Terraform, YAML pipelines, and Azure Pipelines.[/white]",
        title="[bold cyan]🧙  Stack Scaffold Wizard[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    # ── Step 1: Project ───────────────────────────────────────────────────────
    console.print(Rule("[bold]Step 1 of 4 — Project[/bold]", style="cyan"))
    console.print()

    if not Path("stacks").exists():
        console.print("[yellow]⚠  No stacks/ directory — looks like a fresh environment.[/yellow]")
        if click.confirm("  Initialise a new project first?", default=True):
            proj_name = click.prompt("  Project name")
            proj_loc  = click.prompt("  Azure location", default="uksouth")
            proj_code = click.prompt("  Project code (e.g. edp)", default="edp")
            proj_svc  = click.prompt("  Service connection", default="DataPlatform - Dev")
            console.print()
            console.print(Rule("[bold cyan]Initialising project...[/bold cyan]", style="cyan"))
            for d in [
                "stacks", "bootstrap/terraform",
                "templates/scaffold/terraform", "templates/scaffold/yaml",
                "templates/scripts", "templates/yaml", "templates/yaml/build",
                "templates/yaml/deploy", "templates/utils",
                "templates/tests/config/lint", "templates/tests/config/leaks",
                "templates/tests/scripts",
            ]:
                cli_helper.create_directory(Path(d))
            create_utils_module(proj_code)
            create_pipeline_templates()
            create_scaffold_templates()
            copy_script_templates()
            create_devcontainer()
            create_bootstrap_config(proj_code, proj_loc, proj_name)
            console.print()
            console.print("[green]✓  Project initialised.[/green]")
        else:
            console.print("[yellow]Continuing without initialising.[/yellow]")
    else:
        console.print("[green]✓  Project directory detected.[/green]")
    console.print()

    # ── Step 2: Stack details ─────────────────────────────────────────────────
    console.print(Rule("[bold]Step 2 of 4 — Stack Details[/bold]", style="cyan"))
    console.print()

    cicd        = _detect_cicd_platform()
    stack_name  = click.prompt("  Stack name (e.g. dlz, dmz, unity-catalog)")
    description = click.prompt("  Description", default=f"{stack_name} stack")
    svc_conn    = (click.prompt("  Service connection", default="DataPlatform - Dev")
                   if cicd == 'ado' else None)
    console.print()

    # ── Step 3: Azure Resources ───────────────────────────────────────────────
    console.print(Rule("[bold]Step 3 of 4 — Azure Resources[/bold]", style="cyan"))
    console.print()
    console.print("[dim]  Select which Azure resources to scaffold into this stack:[/dim]")
    console.print()

    inc_storage    = click.confirm("  Include Storage Account?",      default=False)
    inc_keyvault   = click.confirm("  Include Key Vault?",            default=False)
    inc_databricks = click.confirm("  Include Databricks Workspace?", default=False)
    console.print()

    # ── Step 4: Confirm ───────────────────────────────────────────────────────
    console.print(Rule("[bold]Step 4 of 4 — Confirm[/bold]", style="cyan"))
    console.print()

    summary = Table.grid(padding=(0, 3))
    summary.add_column(style="bold cyan", no_wrap=True)
    summary.add_column(style="white")
    summary.add_row("Stack name",         stack_name)
    summary.add_row("Description",        description)
    if cicd == 'ado':
        summary.add_row("Service connection", svc_conn)
    else:
        summary.add_row("Workflow", f".github/workflows/{stack_name}.yml")
    summary.add_row("Storage Account",    "[green]yes[/green]" if inc_storage    else "[dim]no[/dim]")
    summary.add_row("Key Vault",          "[green]yes[/green]" if inc_keyvault   else "[dim]no[/dim]")
    summary.add_row("Databricks",         "[green]yes[/green]" if inc_databricks else "[dim]no[/dim]")

    console.print(Panel(summary, title="[bold]Configuration Summary[/bold]",
                        style="cyan", expand=False))
    console.print()

    if not click.confirm("  Create stack with these settings?", default=True):
        console.print("[yellow]Scaffold cancelled.[/yellow]")
        return

    console.print()
    console.print(Rule("[bold cyan]Creating Stack...[/bold cyan]", style="cyan"))
    console.print()

    stacks_dir = Path("stacks")
    stack_dir  = stacks_dir / stack_name
    tf_dir     = stack_dir / "terraform"
    yaml_dir   = stack_dir / "yaml"

    if stack_dir.exists():
        if not click.confirm(f"  Stack '{stack_name}' already exists. Overwrite?"):
            console.print("[yellow]Scaffold cancelled.[/yellow]")
            return

    cli_helper.create_directory(tf_dir)
    generate_terraform_files(tf_dir, stack_name, description,
                             inc_databricks, inc_storage, inc_keyvault)
    if cicd == 'github':
        generate_github_workflow(stack_name)
    else:
        cli_helper.create_directory(yaml_dir)
        generate_yaml_files(yaml_dir, stack_dir, stack_name, svc_conn)
        generate_azure_pipelines(stack_dir, stack_name, svc_conn)
    generate_configuration_guide(stack_dir, tf_dir, yaml_dir)

    console.print()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan", no_wrap=True)
    grid.add_column()
    grid.add_row("1.", f"Review [bold]stacks/{stack_name}/CONFIGURATION.md[/bold]")
    grid.add_row("2.", f"Update subscription IDs in [bold]stacks/{stack_name}/terraform/tfvars/*.tfvars[/bold]")
    grid.add_row("3.", "Run [bold]ign checklist[/bold] to verify readiness")
    grid.add_row("4.", "Run [bold]ign validate[/bold] to lint YAML files")
    grid.add_row("5.", "Commit and push to trigger your CI/CD pipeline")
    console.print(Panel(
        grid,
        title=f"[bold green]✅  Stack '{stack_name}' Scaffolded Successfully![/bold green]",
        title_align="left",
        style="green",
        expand=False,
    ))
    console.print()




# =============================================================================
# ign rename-stack
# =============================================================================

@cli.command("rename-stack")
@click.argument("old_name")
@click.argument("new_name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def rename_stack(old_name, new_name, yes):
    """Rename a stack: moves the folder and updates all internal references."""
    import shutil

    resolved   = _resolve_stack_dir(old_name)
    old_dir    = resolved if resolved is not None else Path("stacks") / old_name
    new_dir    = old_dir.parent / new_name

    console.print(Panel(
        f"[bold white]From:[/bold white] [yellow]{old_name}[/yellow]\n"
        f"[bold white]To:[/bold white]   [green]{new_name}[/green]",
        title="[bold cyan]✏️   Rename Stack[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    if not old_dir.exists():
        console.print(f"[bold red]✗  Stack '{old_name}' not found in stacks/ or landing-zones/[/bold red]")
        return

    if new_dir.exists():
        console.print(f"[bold red]✗  A stack named '{new_name}' already exists.[/bold red]")
        return

    _RENAME_EXTS = {".tf", ".tfvars", ".yml", ".yaml", ".json", ".md"}

    # Dry-run: collect files that will be touched
    to_update = []
    for f in old_dir.rglob("*"):
        if f.is_file() and f.suffix in _RENAME_EXTS:
            try:
                content = f.read_text(encoding="utf-8")
            except Exception:
                continue
            if old_name in content:
                to_update.append(f)

    old_wf = Path(".github/workflows") / f"{old_name}.yml"
    new_wf = Path(".github/workflows") / f"{new_name}.yml"
    if old_wf.exists() and new_wf.exists():
        console.print(f"[bold red]✗  Workflow {new_wf} already exists.[/bold red]")
        return

    console.print(f"[dim]  Will rename folder:[/dim] {old_dir.parent.name}/{old_name} → {new_dir.parent.name}/{new_name}")
    if old_wf.exists():
        console.print(f"[dim]  Will rename workflow:[/dim] {old_wf.as_posix()} → {new_wf.as_posix()}")
    console.print(f"[dim]  Will update {len(to_update)} file(s) containing '{old_name}'[/dim]")
    console.print()

    if not yes and not click.confirm("Proceed?"):
        console.print("[yellow]Rename cancelled.[/yellow]")
        return

    # 1. Move directory
    shutil.move(str(old_dir), str(new_dir))
    console.print(f"  [green]✔[/green]  Moved folder")

    # 2. Update references inside files
    updated = 0
    for rel in to_update:
        # path relative to old_dir → same relative under new_dir
        rel_path  = rel.relative_to(old_dir)
        new_fpath = new_dir / rel_path
        if not new_fpath.exists():
            continue
        try:
            content = new_fpath.read_text(encoding="utf-8")
            # Word-boundary match so we only rewrite the stack name as a whole
            # token, not substrings inside unrelated identifiers/URLs
            # (e.g. renaming "dev" must not touch "developer_portal").
            new_content = re.sub(
                r'(?<![\w-])' + re.escape(old_name) + r'(?![\w-])',
                new_name,
                content,
            )
            if new_content != content:
                new_fpath.write_text(new_content, encoding="utf-8")
                console.print(f"  [green]✔[/green]  Updated [dim]{new_fpath}[/dim]")
                updated += 1
        except Exception as exc:
            console.print(f"  [yellow]⚠[/yellow]  Could not update {new_fpath}: {exc}")

    # 3. GitHub Actions caller workflow lives outside the stack folder
    if old_wf.exists():
        try:
            content = old_wf.read_text(encoding="utf-8")
            new_content = re.sub(
                r'(?<![\w-])' + re.escape(old_name) + r'(?![\w-])',
                new_name,
                content,
            )
            new_wf.write_text(new_content, encoding="utf-8")
            old_wf.unlink()
            console.print(f"  [green]✔[/green]  Renamed workflow [dim]{new_wf}[/dim]")
            updated += 1
        except Exception as exc:
            console.print(f"  [yellow]⚠[/yellow]  Could not rename workflow {old_wf}: {exc}")

    console.print()
    console.print(Panel(
        f"[bold green]✅  Stack renamed to '{new_name}'. {updated} file(s) updated.[/bold green]",
        style="green",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign env-clone
# =============================================================================

@cli.command("env-clone")
@click.argument("stack")
@click.argument("source_env")
@click.argument("new_env")
def env_clone(stack, source_env, new_env):
    """Clone an environment's tfvars into a new environment for a stack.

    Example: ign env-clone my-stack dev staging
    """
    tf_dir     = (_resolve_stack_dir(stack) or (Path("stacks") / stack)) / "terraform"

    console.print(Panel(
        f"[bold white]Stack:[/bold white]  [cyan]{stack}[/cyan]\n"
        f"[bold white]From:[/bold white]   [yellow]{source_env}[/yellow]\n"
        f"[bold white]To:[/bold white]     [green]{new_env}[/green]",
        title="[bold cyan]📋  Clone Environment[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    if not tf_dir.exists():
        console.print(f"[bold red]✗  No terraform/ directory found for stack '{stack}'.[/bold red]")
        return

    # Support both terraform/tfvars/ subdirectory and terraform/ root
    tfvars_dir = (tf_dir / "tfvars") if (tf_dir / "tfvars").exists() else tf_dir

    src = tfvars_dir / f"{source_env}.tfvars"
    dst = tfvars_dir / f"{new_env}.tfvars"

    if not src.exists():
        console.print(f"[bold red]✗  Source file not found: {src}[/bold red]")
        return

    if dst.exists():
        if not click.confirm(f"  '{new_env}.tfvars' already exists. Overwrite?"):
            console.print("[yellow]Clone cancelled.[/yellow]")
            return

    content = src.read_text(encoding="utf-8")
    lines   = content.splitlines()

    # Prompt for any line containing a UUID, a lifecycle env label, or a
    # CAF-aligned region abbreviation (landing zones are region-scoped).
    _ENV_NAMES  = set(_ENV_ORDER) | _CAF_REGION_ABBRS
    _UUID_RE    = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I)

    new_lines = []
    replacements = 0
    console.print(f"[bold]Review values to update (press Enter to keep current):[/bold]\n")

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") or "=" not in stripped:
            new_lines.append(line)
            continue

        key, _, val = stripped.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")

        needs_update = bool(_UUID_RE.search(val)) or (source_env in val) or (val.lower() in _ENV_NAMES)
        if needs_update:
            console.print(f"  [cyan]{key}[/cyan] = [yellow]{val}[/yellow]")
            new_val = click.prompt(f"  New value for '{key}'", default=val)
            if new_val != val:
                # Reconstruct line preserving original quoting style, replacing
                # only within the value part (after '=') so a value that also
                # appears inside the key can't corrupt the key.
                head, sep, tail = line.partition("=")
                orig_val_in_line = tail.strip()
                if orig_val_in_line[:1] in ('"', "'"):
                    q = orig_val_in_line[0]
                    new_tail = tail.replace(f"{q}{val}{q}", f"{q}{new_val}{q}", 1)
                else:
                    new_tail = tail.replace(val, new_val, 1)
                new_lines.append(head + sep + new_tail)
                replacements += 1
                continue

        new_lines.append(line)

    dst.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    console.print()
    console.print(Panel(
        f"[bold green]✅  Created {dst}  ({replacements} value(s) updated)[/bold green]",
        style="green",
        expand=False,
    ))
    console.print()


# =============================================================================
# ign changelog
# =============================================================================

@cli.command()
@click.option("--from-tag", "from_tag", default=None, help="Start tag (exclusive). Defaults to previous release.")
@click.option("--to-tag",   "to_tag",   default=None, help="End tag (inclusive). Defaults to latest release.")
@click.option("--out", "-o", default=None, help="Write output to a file instead of stdout.")
def changelog(from_tag, to_tag, out):
    """Generate a CHANGELOG from GitHub release notes between two tags."""
    import urllib.request
    import urllib.error
    import json as _json
    import os

    token = os.environ.get("GITHUB_TOKEN", "")
    headers = {
        "User-Agent": "ign-cli/1.0",
        "Accept":     "application/vnd.github+json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    console.print(Panel(
        f"[bold white]Repo:[/bold white] [cyan]github.com/{_UPDATE_REPO}[/cyan]",
        title="[bold cyan]📝  Changelog Generator[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()
    console.print("[dim]Fetching releases...[/dim]")

    try:
        req = urllib.request.Request(
            f"https://api.github.com/repos/{_UPDATE_REPO}/releases?per_page=50",
            headers=headers,
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            releases = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 401:
            console.print("[red]✗  GitHub 401 — set GITHUB_TOKEN for private repos.[/red]")
        else:
            console.print(f"[red]✗  GitHub API error (HTTP {e.code}).[/red]")
        return
    except Exception as exc:
        console.print(f"[yellow]⚠  Could not reach GitHub: {exc}[/yellow]")
        return

    if not releases:
        console.print("[yellow]⚠  No releases found.[/yellow]")
        return

    # Filter by tag range
    tags = [r["tag_name"] for r in releases]

    if to_tag and to_tag not in tags:
        console.print(f"[red]✗  Tag '{to_tag}' not found. Available: {', '.join(tags[:10])}[/red]")
        return
    if from_tag and from_tag not in tags:
        console.print(f"[red]✗  Tag '{from_tag}' not found. Available: {', '.join(tags[:10])}[/red]")
        return

    to_idx = tags.index(to_tag) if to_tag else 0

    # --from-tag is exclusive (it's the baseline), so slice up to but not
    # including it. When omitted, include everything down to the oldest release.
    if from_tag:
        from_idx = tags.index(from_tag)
        selected = releases[to_idx:from_idx]
    else:
        selected = releases[to_idx:]

    if not selected:
        console.print("[yellow]⚠  No releases in the specified range.[/yellow]")
        return

    # Build markdown
    lines = ["# Changelog\n"]
    for rel in selected:
        tag       = rel["tag_name"]
        published = rel.get("published_at", "")[:10]
        name      = rel.get("name") or tag
        body      = (rel.get("body") or "").strip()
        url       = rel.get("html_url", "")

        lines.append(f"## [{name}]({url}) — {published}\n")
        if body:
            lines.append(body)
        else:
            lines.append("_No release notes provided._")
        lines.append("")

    md_output = "\n".join(lines)

    if out:
        Path(out).write_text(md_output, encoding="utf-8")
        console.print(Panel(
            f"[bold green]✅  Changelog written to [bold]{out}[/bold] ({len(selected)} release(s))[/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Rule("[bold cyan]CHANGELOG[/bold cyan]", style="cyan"))
        console.print()
        from rich.markdown import Markdown
        console.print(Markdown(md_output))

    console.print()


# =============================================================================
# ign pr-check
# =============================================================================

@cli.command("pr-check")
@click.argument("stack", required=False)
@click.option("--all", "check_all", is_flag=True, help="Run against all stacks")
def pr_check(stack, check_all):
    """Run all quality gates (validate, lint-tf, secrets, checklist) in one pass.

    Exits with code 1 if any gate fails — suitable for CI pipelines.
    """
    import subprocess
    import sys

    if not stack and not check_all:
        choice = click.prompt(
            "Check a single stack or all?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        if choice == "stack":
            stack = click.prompt("Stack name")
        else:
            check_all = True

    scope = "All Stacks" if check_all else stack

    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]",
        title="[bold cyan]🚦  PR Quality Gate[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    gates = [
        ("YAML Validate",  ["validate"]  + (["--all"] if check_all else ["--stack", stack])),
        ("Terraform Lint", ["lint-tf"]   + (["--all"] if check_all else ["--stack", stack])),
        ("Secret Scan",    ["secrets"]   + (["--all"] if check_all else ["--stack", stack])),
        ("Checklist",      ["checklist"] + (["--all"] if check_all else ["--stack", stack])),
    ]

    results = []
    overall_pass = True

    for gate_name, args in gates:
        console.print(Rule(f"[bold white]{gate_name}[/bold white]", style="dim"))
        result = subprocess.run(
            [sys.executable, __file__] + args,
            capture_output=False,
        )
        passed = result.returncode == 0
        if not passed:
            overall_pass = False
        results.append((gate_name, passed))
        console.print()

    # Summary table
    t = Table(box=box.ROUNDED, header_style="bold cyan", border_style="cyan", expand=False)
    t.add_column("Gate",   style="bold white", min_width=20)
    t.add_column("Result", justify="center", width=10)
    for gname, passed in results:
        icon = "[bold green]✅  PASS[/bold green]" if passed else "[bold red]✗  FAIL[/bold red]"
        t.add_row(gname, icon)

    console.print(t)
    console.print()

    if overall_pass:
        console.print(Panel(
            "[bold green]✅  All gates passed — ready to merge![/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Panel(
            "[bold red]✗  One or more gates failed. Fix issues before merging.[/bold red]",
            style="red",
            expand=False,
        ))
        sys.exit(1)

    console.print()


# =============================================================================
# ign tfsec
# =============================================================================

@cli.command()
@click.argument("stack", required=False)
@click.option("--all", "scan_all", is_flag=True, help="Scan all stacks")
@click.option("--tool", type=click.Choice(["tfsec", "checkov"], case_sensitive=False), default=None,
              help="Force a specific tool (auto-detected by default)")
def tfsec(stack, scan_all, tool):
    """Run tfsec or checkov on Terraform code and display findings by severity."""
    import subprocess
    import shutil
    import json as _json

    if not stack and not scan_all:
        choice = click.prompt(
            "Scan a single stack or all?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        if choice == "stack":
            stack = click.prompt("Stack name")
        else:
            scan_all = True

    # Auto-detect available tool
    if not tool:
        if shutil.which("tfsec"):
            tool = "tfsec"
        elif shutil.which("checkov"):
            tool = "checkov"
        else:
            console.print(Panel(
                "[bold red]✗  Neither tfsec nor checkov found on PATH.[/bold red]\n\n"
                "[white]Install one of:[/white]\n"
                "  [bold]choco install tfsec[/bold]  (Windows)\n"
                "  [bold]pip install checkov[/bold]",
                title="[bold red]Missing Security Scanner[/bold red]",
                title_align="left",
                style="red",
                expand=False,
            ))
            return

    stacks_dir = Path("stacks")
    targets = (
        _iter_all_stacks()
        if scan_all
        else [_resolve_stack_dir(stack) or (stacks_dir / stack)]
    )

    scope = "All Stacks" if scan_all else stack
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]   "
        f"[bold white]Tool:[/bold white]  [cyan]{tool}[/cyan]",
        title="[bold cyan]🔒  Terraform Security Scan[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    all_findings = []

    scanned = 0
    for tgt in targets:
        tf_dir = tgt / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no terraform/ directory[/yellow]")
            continue
        scanned += 1

        if tool == "tfsec":
            cmd = ["tfsec", str(tf_dir), "--format", "json", "--no-colour"]
        else:
            cmd = ["checkov", "-d", str(tf_dir), "-o", "json", "--quiet"]

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            raw  = proc.stdout or proc.stderr
        except FileNotFoundError:
            console.print(f"[red]✗  {tool} not found on PATH.[/red]")
            return
        except subprocess.TimeoutExpired:
            console.print(f"[yellow]⚠  {tool} timed out on {tgt.name}[/yellow]")
            continue

        try:
            data = _json.loads(raw)
        except _json.JSONDecodeError:
            console.print(f"[yellow]⚠  Could not parse {tool} output for {tgt.name}[/yellow]")
            continue

        # Normalise findings to (severity, rule_id, description, file, start_line)
        if tool == "tfsec":
            for r in data.get("results", []):
                sev  = r.get("severity", "UNKNOWN").upper()
                rid  = r.get("rule_id", "")
                desc = r.get("description", "")
                loc  = r.get("location", {})
                fname = loc.get("filename", "")
                line  = loc.get("start_line", 0)
                all_findings.append((sev, rid, desc, fname, line))
        else:
            for check in data.get("results", {}).get("failed_checks", []):
                sev   = check.get("severity", "MEDIUM").upper()
                rid   = check.get("check_id", "")
                desc  = check.get("check_type", "")
                fname = check.get("repo_file_path", "")
                line  = check.get("file_line_range", [0])[0]
                all_findings.append((sev, rid, desc, fname, line))

    if scanned == 0:
        console.print(Panel(
            f"[bold yellow]⚠  No stacks scanned — '{scope}' not found or has no terraform/ directory.[/bold yellow]",
            style="yellow",
            expand=False,
        ))
        console.print()
        return

    if not all_findings:
        console.print(Panel(
            "[bold green]✅  No security issues found![/bold green]",
            style="green",
            expand=False,
        ))
        console.print()
        return

    _SEV_ORDER   = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    _SEV_COLOURS = {"CRITICAL": "bold red", "HIGH": "red", "MEDIUM": "yellow", "LOW": "dim yellow", "UNKNOWN": "dim"}
    all_findings.sort(key=lambda x: _SEV_ORDER.get(x[0], 9))

    counts: Dict[str, int] = {}
    console.print()
    for sev, rid, desc, fname, line in all_findings:
        counts[sev] = counts.get(sev, 0) + 1
        colour = _SEV_COLOURS.get(sev, "white")
        badge  = f"[{colour}] {sev:<8} [/{colour}]"
        console.print(f"  {badge}  [bold white]{rid}[/bold white]  [dim]{desc}[/dim]")
        console.print(f"            [cyan]{fname}[/cyan][dim]:{line}[/dim]")
        console.print()

    g = Table.grid(padding=(0, 3))
    g.add_column(style="bold", no_wrap=True)
    g.add_column()
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        n = counts.get(sev, 0)
        if n:
            colour = _SEV_COLOURS.get(sev, "white")
            g.add_row(f"[{colour}]{sev}[/{colour}]", str(n))
    g.add_row("[white]Total[/white]", str(len(all_findings)))

    sev_style = "red" if counts.get("CRITICAL") or counts.get("HIGH") else "yellow"
    console.print(Panel(
        g,
        title=f"[bold {sev_style}]🔒  {len(all_findings)} Security Finding(s)[/bold {sev_style}]",
        title_align="left",
        style=sev_style,
        expand=False,
    ))
    console.print()


# =============================================================================
# ign policy
# =============================================================================

# House rules: (rule_id, description, check_fn)
# check_fn(content: str, path: Path) -> list[str]  (list of violation messages)

def _policy_required_tags(content: str, path: Path) -> List[str]:
    """Every resource block must have a tags argument."""
    issues = []
    in_resource = False
    brace_depth = 0
    resource_name = ""
    has_tags = False

    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("resource ") and "{" in stripped:
            in_resource = True
            brace_depth = stripped.count("{") - stripped.count("}")
            resource_name = stripped.split('"')[1] if '"' in stripped else stripped
            has_tags = False
            continue
        if in_resource:
            brace_depth += stripped.count("{") - stripped.count("}")
            if re.match(r'tags\s*=', stripped) or re.match(r'tags\s*\{', stripped):
                has_tags = True
            if brace_depth <= 0:
                if not has_tags:
                    issues.append(f"Resource '{resource_name}' is missing a 'tags' argument")
                in_resource = False
    return issues


def _policy_no_public_ip(content: str, path: Path) -> List[str]:
    """No resource should expose a public IP via allocation_method = 'Static'/'Dynamic' on a public IP resource."""
    issues = []
    in_public_ip = False
    brace_depth  = 0
    for i, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        if re.search(r'resource\s+"azurerm_public_ip"', stripped):
            in_public_ip = True
            brace_depth  = stripped.count("{") - stripped.count("}")
            continue
        if in_public_ip:
            brace_depth += stripped.count("{") - stripped.count("}")
            if re.match(r'allocation_method\s*=\s*"(Static|Dynamic)"', stripped):
                issues.append(f"Line {i}: Public IP resource with allocation_method — review if intentional")
            if brace_depth <= 0:
                in_public_ip = False
    return issues


def _policy_storage_soft_delete(content: str, path: Path) -> List[str]:
    """Storage accounts should have blob_properties soft_delete enabled."""
    issues = []
    if "azurerm_storage_account" not in content:
        return issues
    if "blob_properties" not in content:
        issues.append("azurerm_storage_account missing blob_properties (soft-delete not configured)")
        return issues
    # Check delete_retention_policy is present
    if "delete_retention_policy" not in content:
        issues.append("azurerm_storage_account blob_properties missing delete_retention_policy")
    return issues


def _policy_naming_convention(content: str, path: Path) -> List[str]:
    """Resource names should use variables/locals, not hardcoded strings."""
    issues = []
    for i, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        m = re.match(r'name\s*=\s*"([^${}][^"]*)"', stripped)
        if m and not stripped.startswith("#"):
            val = m.group(1)
            # Allow short placeholder-style names but flag obvious hardcoded env names
            if re.search(r'(dev|tst|uat|prd|prod|staging)', val, re.I) and len(val) > 5:
                issues.append(f"Line {i}: Hardcoded environment name in resource name '{val}' — use var/local")
    return issues


_POLICY_RULES = [
    ("POL-001", "Required tags on all resources",              _policy_required_tags),
    ("POL-002", "No unrestricted public IP resources",         _policy_no_public_ip),
    ("POL-003", "Storage account soft-delete configured",      _policy_storage_soft_delete),
    ("POL-004", "No hardcoded environment names in resource names", _policy_naming_convention),
]


@cli.command()
@click.argument("stack", required=False)
@click.option("--all", "check_all", is_flag=True, help="Check all stacks")
def policy(stack, check_all):
    """Check Terraform files against house policy rules (tags, naming, security)."""
    if not stack and not check_all:
        choice = click.prompt(
            "Check a single stack or all?",
            type=click.Choice(["stack", "all"], case_sensitive=False),
            default="stack",
        )
        if choice == "stack":
            stack = click.prompt("Stack name")
        else:
            check_all = True

    stacks_dir = Path("stacks")
    targets = (
        _iter_all_stacks()
        if check_all
        else [_resolve_stack_dir(stack) or (stacks_dir / stack)]
    )

    scope = "All Stacks" if check_all else stack
    console.print(Panel(
        f"[bold white]Scope:[/bold white] [cyan]{scope}[/cyan]   "
        f"[bold white]Rules:[/bold white] [cyan]{len(_POLICY_RULES)}[/cyan]",
        title="[bold cyan]📐  Policy Check[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))
    console.print()

    total_violations = 0
    all_clean = True
    checked = 0

    for tgt in targets:
        tf_dir = tgt / "terraform"
        if not tf_dir.exists():
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no terraform/ directory[/yellow]")
            continue

        tf_files = list(tf_dir.glob("*.tf"))
        if not tf_files:
            console.print(f"[yellow]⚠  Skipping {tgt.name}: no .tf files[/yellow]")
            continue
        checked += 1

        stack_violations = []

        for tf_file in sorted(tf_files):
            try:
                content = tf_file.read_text(encoding="utf-8")
            except Exception:
                continue
            for rule_id, rule_desc, check_fn in _POLICY_RULES:
                try:
                    msgs = check_fn(content, tf_file)
                except Exception:
                    msgs = []
                for msg in msgs:
                    stack_violations.append((rule_id, tf_file.name, msg))

        if stack_violations:
            all_clean = False
            total_violations += len(stack_violations)
            console.print(Rule(f"[bold yellow]{tgt.name}[/bold yellow]", style="yellow"))
            for rule_id, fname, msg in stack_violations:
                console.print(f"  [yellow]{rule_id}[/yellow]  [dim]{fname}[/dim]")
                console.print(f"          {msg}")
            console.print()
        else:
            console.print(f"  [green]✔[/green]  [bold]{tgt.name}[/bold] — all rules passed")

    console.print()

    if checked == 0:
        console.print(Panel(
            f"[bold yellow]⚠  No stacks checked — '{scope}' not found or has no terraform files.[/bold yellow]",
            style="yellow",
            expand=False,
        ))
        console.print()
        return

    if all_clean:
        console.print(Panel(
            "[bold green]✅  All stacks comply with policy rules![/bold green]",
            style="green",
            expand=False,
        ))
    else:
        console.print(Panel(
            f"[bold yellow]⚠  {total_violations} violation(s) found across stacks.[/bold yellow]\n"
            "[dim]Fix the issues above before merging.[/dim]",
            title="[bold yellow]Policy Violations[/bold yellow]",
            title_align="left",
            style="yellow",
            expand=False,
        ))

    console.print()


# =============================================================================
# ign mcp
# =============================================================================

@cli.group(invoke_without_command=True)
@click.pass_context
def mcp(ctx: click.Context):
    """MCP server commands — start the server or install it into VS Code.

    Run  'ign mcp start'    to start the stdio server (used by MCP clients).
    Run  'ign mcp install'  to register the server in VS Code automatically.

    The 'ign-mcp' console script (installed with the package) can also be
    used directly as the server command in any MCP client config.
    """
    if ctx.invoked_subcommand is None:
        # Backwards-compatible: bare 'ign mcp' still starts the server.
        ctx.invoke(mcp_start)


@mcp.command("start")
def mcp_start():
    """Start the ign MCP server (stdio transport).

    Configure in Copilot CLI with:
      /mcp add ign ign-mcp

    Configure in VS Code (or run 'ign mcp install' to do this automatically):
      Add to settings.json → mcp.servers:
        "ign": { "type": "stdio", "command": "ign-mcp" }
    """
    import importlib.util

    mcp_path = Path(__file__).with_name("mcp_server.py")
    if not mcp_path.exists():
        console.print(Panel(
            "[bold red]✗  mcp_server.py not found next to ignition.py[/bold red]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    try:
        import mcp as _mcp_pkg  # noqa: F401
    except ImportError:
        console.print(Panel(
            "[bold red]✗  mcp package not installed.[/bold red]\n"
            "[dim]Run: pip install mcp>=1.0.0[/dim]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    # Hand off to mcp_server.main() — runs until the MCP client disconnects
    spec   = importlib.util.spec_from_file_location("mcp_server", mcp_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.main()


@mcp.command("install")
@click.option("--workspace", is_flag=True, default=False,
              help="Write to .vscode/mcp.json in the current directory instead of VS Code user settings.")
@click.option("--copilot", is_flag=True, default=False,
              help="Also write to ~/.copilot/mcp-config.json for GitHub Copilot CLI.")
def mcp_install(workspace: bool, copilot: bool):
    """Register the ign MCP server in VS Code (and optionally Copilot CLI).

    By default writes to your VS Code user settings so the server is available
    in every project.  Pass --workspace to write a .vscode/mcp.json instead.

    \b
    Examples
    --------
      ign mcp install                  # VS Code user settings (global)
      ign mcp install --workspace      # .vscode/mcp.json (project-local)
      ign mcp install --copilot        # also add to Copilot CLI mcp-config.json
    """
    import json
    import os
    import platform
    import shutil

    # ------------------------------------------------------------------
    # Verify ign-mcp is actually available on PATH
    # ------------------------------------------------------------------
    ign_mcp_exe = shutil.which("ign-mcp")
    if ign_mcp_exe is None:
        console.print(Panel(
            "[bold yellow]⚠  'ign-mcp' not found on PATH.\n"
            "[/bold yellow][dim]Make sure the ign package is installed and its "
            "scripts directory is on your PATH.[/dim]",
            style="yellow", expand=False,
        ))

    server_entry: dict = {"type": "stdio", "command": "ign-mcp"}

    installed: list[str] = []
    skipped:   list[str] = []

    # ------------------------------------------------------------------
    # Helper: merge server entry into a JSON settings file
    # ------------------------------------------------------------------
    def _upsert_json(path: Path, key_path: list[str], value: dict) -> bool:
        """Insert/update a nested key in a JSON file.  Returns True if changed."""
        data: dict = {}
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                console.print(f"[yellow]  ⚠  Could not parse {path} — skipping.[/yellow]")
                return False

        node = data
        for segment in key_path[:-1]:
            node = node.setdefault(segment, {})

        leaf_key = key_path[-1]
        existing = node.get(leaf_key)
        if existing == value:
            return False  # nothing to do

        node[leaf_key] = value
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        return True

    # ------------------------------------------------------------------
    # VS Code user settings  (~/.../Code/User/settings.json)
    # ------------------------------------------------------------------
    if not workspace:
        system = platform.system()
        if system == "Windows":
            base = Path(os.environ.get("APPDATA", "~")).expanduser()
            vscode_settings = base / "Code" / "User" / "settings.json"
        elif system == "Darwin":
            vscode_settings = Path.home() / "Library" / "Application Support" / "Code" / "User" / "settings.json"
        else:
            vscode_settings = Path.home() / ".config" / "Code" / "User" / "settings.json"

        changed = _upsert_json(vscode_settings, ["mcp", "servers", "ign"], server_entry)
        label = f"VS Code user settings  ({vscode_settings})"
        (installed if changed else skipped).append(label)

    # ------------------------------------------------------------------
    # Workspace .vscode/mcp.json
    # ------------------------------------------------------------------
    if workspace:
        ws_mcp = Path.cwd() / ".vscode" / "mcp.json"
        data: dict = {}
        if ws_mcp.exists():
            try:
                data = json.loads(ws_mcp.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                console.print(f"[yellow]  ⚠  Could not parse {ws_mcp} — will overwrite.[/yellow]")

        servers = data.setdefault("servers", {})
        changed = servers.get("ign") != server_entry
        servers["ign"] = server_entry
        ws_mcp.parent.mkdir(parents=True, exist_ok=True)
        ws_mcp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        label = f"Workspace MCP config  ({ws_mcp})"
        (installed if changed else skipped).append(label)

    # ------------------------------------------------------------------
    # GitHub Copilot CLI  (~/.copilot/mcp-config.json)
    # ------------------------------------------------------------------
    if copilot:
        copilot_mcp = Path.home() / ".copilot" / "mcp-config.json"
        # Copilot CLI reads mcp-config.json; uses mcpServers (camelCase).
        # Stdio servers need command + args[]; type must not be set (only "http"/"sse" are valid).
        copilot_entry: dict = {"command": "ign-mcp", "args": []}
        changed = _upsert_json(copilot_mcp, ["mcpServers", "ign"], copilot_entry)
        label = f"GitHub Copilot CLI    ({copilot_mcp})"
        (installed if changed else skipped).append(label)

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    lines: list[str] = []
    for item in installed:
        lines.append(f"[green]✓[/green]  {item}")
    for item in skipped:
        lines.append(f"[dim]–  {item}  (already configured)[/dim]")

    if installed:
        lines.append("")
        lines.append("[dim]Reload VS Code (Ctrl+Shift+P → Developer: Reload Window) to activate.[/dim]")

    console.print(Panel(
        "\n".join(lines) if lines else "[dim]Nothing to do.[/dim]",
        title="[bold]ign MCP server[/bold]",
        expand=False,
    ))


# =============================================================================
# ign update
# =============================================================================

_UPDATE_REPO = "telefonicatechuki/devops-cli"


def _parse_version_tuple(version: str):
    """Parse an x.y.z version string into a comparable int tuple."""
    text = version.strip().lstrip("v")
    match = re.match(r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)", text)
    if not match:
        return (-1, -1, -1)

    return (
        int(match.group("major")),
        int(match.group("minor")),
        int(match.group("patch")),
    )


def _extract_latest_tag(output: str) -> str:
    """Handle gh's JSON or line-based query output and return a single tag."""
    text = output.strip()
    if not text:
        return ""

    if text[0] in "[{":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return ""
        if isinstance(data, list):
            if not data:
                return ""
            first = data[0]
            if isinstance(first, dict):
                return str(first.get("tagName") or first.get("name") or "").strip()
            return str(first).strip()
        if isinstance(data, dict):
            return str(data.get("tagName") or data.get("name") or "").strip()
        return str(data).strip()

    return next((line.strip() for line in text.splitlines() if line.strip()), "")


@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.option("--check", is_flag=True, help="Only check for updates, don't install")
@click.option("--pre-release", is_flag=True, help="Include pre-releases")
def update(yes: bool, check: bool, pre_release: bool):
    """Check GitHub for a newer ign release and install it."""
    import os
    import shutil
    import subprocess
    import sys
    import tempfile

    if shutil.which("gh") is None:
        console.print(Panel(
            "[bold red]✗  GitHub CLI ('gh') not found on PATH.[/bold red]\n"
            "[dim]Install it, then run 'gh auth login':\n"
            "  Windows: winget install GitHub.cli\n"
            "  macOS:   brew install gh\n"
            "  Linux:   sudo apt install gh[/dim]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    current_version = __version__

    try:
        args = ["gh", "release", "list", "--repo", _UPDATE_REPO, "--json", "tagName"]
        if not pre_release:
            args.append("--exclude-pre-releases")
        r = subprocess.run(
            args + ["--limit", "1", "-q", ".[0].tagName"],
            capture_output=True, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        console.print(Panel(
            "[bold red]✗  Timed out contacting GitHub.[/bold red]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)
    except Exception as e:
        console.print(Panel(f"[bold red]✗  {e}[/bold red]", style="red", expand=False))
        raise click.exceptions.Exit(code=1)

    if r.returncode != 0:
        console.print(Panel(
            f"[bold red]✗  Could not check for updates.[/bold red]\n"
            f"[dim]{r.stderr.strip() or r.stdout.strip()}[/dim]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)

    latest_tag = _extract_latest_tag(r.stdout)
    if not latest_tag:
        console.print(Panel(
            "[bold red]✗  No matching releases were found.[/bold red]",
            style="red", expand=False,
        ))
        raise click.exceptions.Exit(code=1)
    latest_version = latest_tag.lstrip("v")

    if _parse_version_tuple(latest_version) <= _parse_version_tuple(current_version):
        console.print(Panel(
            f"[bold green]✅  You're up to date.[/bold green]  [dim](v{current_version})[/dim]",
            style="green", expand=False,
        ))
        return

    console.print(Panel(
        f"[bold white]Current:[/bold white] [yellow]v{current_version}[/yellow]\n"
        f"[bold white]Latest:[/bold white]  [green]{latest_tag}[/green]",
        title="[bold cyan]⬆  Update Available[/bold cyan]",
        title_align="left",
        style="cyan",
        expand=False,
    ))

    if check:
        return

    if not yes and not click.confirm("Download and install this update?"):
        console.print("[dim]Skipped.[/dim]")
        return

    def _start_windows_delayed_install(install_cmd: List[str], wheel: Path) -> None:
        import shutil as _shutil
        import subprocess as _subprocess
        import textwrap

        staging_dir = Path(tempfile.mkdtemp(prefix="ign-update-"))
        staged_wheel = staging_dir / wheel.name
        _shutil.copy2(wheel, staged_wheel)
        staged_install_cmd = [
            str(staged_wheel) if arg == str(wheel) else arg
            for arg in install_cmd
        ]

        helper_script = textwrap.dedent(f"""
            import ctypes
            import pathlib
            import shutil
            import subprocess
            import sys
            import time

            pid = {os.getpid()}
            cmd = {json.dumps(staged_install_cmd)}
            staging_dir = pathlib.Path(r"{staging_dir}")

            kernel32 = ctypes.windll.kernel32
            process_query_limited_information = 0x1000

            while True:
                handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
                if not handle:
                    break
                kernel32.CloseHandle(handle)
                time.sleep(0.25)

            result = subprocess.run(cmd)
            shutil.rmtree(staging_dir, ignore_errors=True)
            sys.exit(result.returncode)
        """)

        creationflags = 0
        if hasattr(_subprocess, "DETACHED_PROCESS"):
            creationflags |= _subprocess.DETACHED_PROCESS
        if hasattr(_subprocess, "CREATE_NEW_PROCESS_GROUP"):
            creationflags |= _subprocess.CREATE_NEW_PROCESS_GROUP

        _subprocess.Popen(
            [sys.executable, "-c", helper_script],
            creationflags=creationflags,
            stdin=_subprocess.DEVNULL,
            stdout=_subprocess.DEVNULL,
            stderr=_subprocess.DEVNULL,
        )

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        console.print(f"[dim]Downloading {latest_tag}...[/dim]")
        try:
            r = subprocess.run(
                ["gh", "release", "download", latest_tag, "--repo", _UPDATE_REPO,
                 "--pattern", "*.whl", "--dir", str(tmp_path), "--clobber"],
                capture_output=True, text=True, timeout=60,
            )
        except Exception as e:
            console.print(Panel(f"[bold red]✗  Download failed: {e}[/bold red]", style="red", expand=False))
            raise click.exceptions.Exit(code=1)

        if r.returncode != 0:
            console.print(Panel(
                f"[bold red]✗  Download failed.[/bold red]\n[dim]{r.stderr.strip()}[/dim]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

        wheels = list(tmp_path.glob("*.whl"))
        if not wheels:
            console.print(Panel(
                "[bold red]✗  No .whl file found in the release assets.[/bold red]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

        whl = wheels[0]

        uv_exe = shutil.which("uv")
        is_windows = sys.platform.startswith("win")
        if uv_exe:
            console.print("[dim]Installing with uv...[/dim]")
            install_cmd = ["uv", "tool", "install", str(whl), "--force"]
            if is_windows:
                _start_windows_delayed_install(install_cmd, whl)
                console.print(
                    "[dim]Windows will finish the install after this command exits.[/dim]"
                )
                console.print(Panel(
                    f"[bold green]✅  Update queued for {latest_tag}.[/bold green]\n"
                    "[dim]Open a new shell in a few seconds, then run 'ign --version'.[/dim]",
                    style="green", expand=False,
                ))
                return
            install = subprocess.run(install_cmd)
        else:
            console.print(
                "[yellow]⚠  'uv' not found — falling back to pip.[/yellow]\n"
                "[dim]Installing uv is recommended: https://astral.sh/uv[/dim]"
            )
            install_cmd = [sys.executable, "-m", "pip", "install", "--force-reinstall", str(whl)]
            if is_windows:
                _start_windows_delayed_install(install_cmd, whl)
                console.print(
                    "[dim]Windows will finish the install after this command exits.[/dim]"
                )
                console.print(Panel(
                    f"[bold green]✅  Update queued for {latest_tag}.[/bold green]\n"
                    "[dim]Open a new shell in a few seconds, then run 'ign --version'.[/dim]",
                    style="green", expand=False,
                ))
                return
            install = subprocess.run(install_cmd)

        if install.returncode != 0:
            console.print(Panel(
                "[bold red]✗  Install failed. See output above.[/bold red]",
                style="red", expand=False,
            ))
            raise click.exceptions.Exit(code=1)

    console.print(Panel(
        f"[bold green]✅  Updated to {latest_tag}.[/bold green]\n"
        "[dim]Open a new shell and run 'ign --version' to confirm.[/dim]",
        style="green", expand=False,
    ))


if __name__ == '__main__':
    cli()
