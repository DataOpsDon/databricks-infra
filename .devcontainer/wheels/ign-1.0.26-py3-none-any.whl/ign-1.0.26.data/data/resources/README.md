# Terraform Infrastructure-as-Code (IaC) Modules

## 🎯 Overview

This repository serves as the **central library** for our internal `ign` CLI tool. It contains reusable Terraform modules, complete stack templates, CI/CD pipeline configurations, and utility scripts that the CLI uses to generate infrastructure projects.

**How it works:**
1. **Contributors** add new modules, stacks, and templates to this repository
2. **Releases** are created periodically to package the latest contributions
3. **The CLI** pulls in these changes at each release, making them available to the team
4. **Users** leverage the CLI to quickly generate projects with stacks, modules, and complete CI/CD frameworks

This repository is the foundation that powers rapid, standardized infrastructure development across our team.

## 📁 Repository Structure

```
tf-iac-modules/
├── bootstrap/          # Bootstrap configurations for initial setup
│   └── terraform/      # Terraform state backend and service connection setup
│
├── modules/            # Reusable Terraform modules and stack templates
│   ├── azure/          # Azure resource modules (*.tf files)
│   └── stacks/         # Complete infrastructure stack templates
│
└── templates/          # Template files for code generation
    ├── pipelines/      # CI/CD pipeline templates (ADO & GitHub)
    ├── scripts/        # Shell scripts for Azure DevOps & Terraform
    ├── terraform/      # Base Terraform template files
    └── yaml/           # YAML configuration templates
```

## 🚀 Quick Start

### For Contributors

**You're in the right place!** This repository is where you add new capabilities that will be available in the `ign` CLI.

Choose what you want to contribute:

- **[Add a new Azure resource module](#adding-terraform-modules)** → Add reusable `.tf` files
- **[Create a complete stack template](#adding-stack-templates)** → Build ready-to-use infrastructure patterns
- **[Update pipeline templates](#modifying-pipeline-templates)** → Enhance CI/CD workflows
- **[Add utility scripts](#contributing-scripts)** → Extend automation capabilities

**Release Process:**
1. Pick up an issue and contribute to this repository via pull request, or, raise a new issue.
2. Changes are reviewed and merged
3. A new release is created (versioned)
4. The `ign` CLI pulls in the latest release, making your contributions available to the team

### For CLI Users

Once contributions are released, the `ign` CLI provides these capabilities:

```bash
# List available modules (from this repository)
ign list-modules

# List available stack templates (from this repository)
ign list-stack-templates

# Add a resource to your stack
ign add-resource --stack-name my-stack --resource-type storage --resource-name mystg

# Apply a complete stack template
ign add-stack-template --stack-name example-stack
```

## 📚 Documentation

### Core Documentation

- **[Modules README](modules/README.md)** - How to add and use Terraform modules
- **[Stacks README](modules/stacks/README.md)** - Complete stack templates guide
- **[Pipeline Templates](templates/pipelines/README.md)** - CI/CD pipeline documentation
- **[Script Templates](templates/scripts/README.md)** - Utility scripts reference
- **[Terraform Templates](templates/terraform/README.md)** - Base template files

### Terraform Documentation
Using a tool called [terraform-docs](https://github.com/terraform-docs/terraform-docs/) we can easily document our Terraform code into an easy to ready ReadMe file. 

To use terraform-docs follow these steps

**Install terraform-docs:** 

Run this Chocolatey command in PowerShell. 

choco install terraform-docs

**Add the setup file**

Use this link to add the [terraform-docs file](templates/utils/.terraform.docs.yaml) to the folder containing your Terraform code.

**Run terraform-docs**

Open PowerShell, set the location to the Terraform folder and run the following.

terraform-docs -c .\.terraform.docs.yaml .

This will add the Terraform documentation to your ReadMe file.

### Platform-Specific Guides

- **[Azure DevOps Pipelines](templates/pipelines/README.md#azure-devops-templates)**
- **[GitHub Actions](templates/pipelines/github/README.md)** (Coming Soon)

## 🔧 Contributing

### Adding Terraform Modules

Terraform modules are individual `.tf` files that define reusable Azure resources. These can be added to any infrastructure stack.

**Location:** `modules/azure/`

**Quick Steps:**

1. Create a new `.tf` file in `modules/azure/`:

    Bash:
   ```bash
   touch modules/azure/my-resource.tf
   ```
    PowerShell
   ```powershell
   cd modules/aure
   new-item -name "my-resource.tf" -type file
   ```

2. Write standard Terraform code using the `{{resource_name}}` placeholder:
   ```hcl
   # My Azure Resource Module
   # Contributor: Your Name
   # Description: Brief description for CLI listing

   module "{{resource_name}}" {
     source              = "Azure/avm-res-<resource>/azurerm"
     version             = "0.1.0"
     name                = "myres-${var.location_short}-${var.project}-{{resource_name}}"
     location            = module.resource_group.resource.location
     resource_group_name = module.resource_group.name
     tags                = var.tags
   }
   ```

3. Test it:
   ```bash
   ign list-modules  # Verify your module appears
   ign add-resource --stack-name test --resource-type my-resource --resource-name demo
   ```

**📖 Full Guide:** See [modules/README.md](modules/README.md) for detailed instructions, best practices, and examples.

### Adding Stack Templates

Stack templates are complete, ready-to-deploy infrastructure configurations including Terraform files, pipelines, and scripts.

**Location:** `modules/stacks/`

**Quick Steps:**

1. Create the directory structure:
   ```bash
   mkdir -p modules/stacks/my-stack/{terraform,yaml,scripts}
   ```

2. Add required files:
   - `terraform/` - All Terraform configuration files
   - `yaml/` - Pipeline templates (build.yml, deploy.yml, state.yml)
   - `azure-pipelines.yml` - Main pipeline configuration
   - `scripts/` (optional) - Helper scripts

3. Test the template:
   ```bash
   ign add-stack-template --stack-name my-stack
   ```

**📖 Full Guide:** See [modules/stacks/README.md](modules/stacks/README.md) for complete instructions and examples.

### Modifying Pipeline Templates

Pipeline templates define CI/CD workflows for building and deploying infrastructure.

**Location:** `templates/pipelines/`

**Available Templates:**

- **Azure DevOps** (`ado/`) - Currently available
  - `build-terraform.yml.template` - Build and validation
  - `deploy-terraform.yml.template` - Deployment workflows
  - `environments.yml.template` - Multi-environment orchestration
  - `run-terraform-checks.yml.template` - Security and validation checks

- **GitHub Actions** (`github/`) - Coming soon

**Modifying Templates:**

1. Edit the template file in `templates/pipelines/ado/` or `templates/pipelines/github/`
2. Test by generating a new stack: `ign add-stack --stack-name test-stack`
3. Review generated files in your stack's `yaml/` directory

**📖 Full Guide:** See [templates/pipelines/README.md](templates/pipelines/README.md) for detailed documentation.

### Contributing Scripts

Utility scripts automate common Azure DevOps and Terraform operations.

**Location:** `templates/scripts/`

**Available Scripts:**

| Script | Purpose |
|--------|---------|
| `azp-backend.sh` | Create/update Azure backend storage for Terraform state |
| `azp-spn-generator.sh` | Generate Service Principals with certificate authentication |
| `tf-apply.sh` | Apply Terraform changes with retry logic |
| `tf-destroy.sh` | Destroy infrastructure with hierarchy cleanup |
| `tf-fmt.sh` | Format Terraform files |
| `tf-init.sh` | Initialize Terraform with backend configuration |
| `tf-install.sh` | Install Terraform binary |
| `tf-plan.sh` | Generate Terraform execution plans |

**Adding New Scripts:**

1. Create your script in `templates/scripts/`
2. Follow existing patterns for error handling and logging
3. Add documentation to the scripts README
4. Test thoroughly in a pipeline context

**📖 Full Guide:** See [templates/scripts/README.md](templates/scripts/README.md) for script documentation.

## 🏗️ Bootstrap Configuration

The `bootstrap/` directory contains Terraform configurations for initial project setup:

- **Terraform State Backend** - Azure Storage configuration
- **Service Connections** - OIDC federated credentials setup
- **User Managed Identities** - Deployment identity configuration

**Configuration File:** `bootstrap/terraform/config.yaml`

Key settings include:
- Environment configuration (dev, test, prod)
- Azure locations and subscriptions
- Terraform state storage settings
- Service connection details
- Tags and naming conventions

## 📋 Best Practices

### Module Development

✅ **DO:**
- Use Azure Verified Modules (AVM) when available
- Pin module versions explicitly
- Include helpful comments and descriptions
- Use existing variables (`var.location`, `var.tags`, etc.)
- Reference existing modules (`module.resource_group.name`)

❌ **DON'T:**
- Hardcode values (locations, names, etc.)
- Skip version pinning
- Use template syntax (`.template` files) for modules
- Duplicate existing functionality

### Stack Templates

✅ **DO:**
- Include complete, working configurations
- Provide environment-specific `.tfvars` files
- Document prerequisites and setup steps
- Follow consistent naming conventions
- Test templates end-to-end

❌ **DON'T:**
- Include sensitive data or real credentials
- Create dependencies on external resources
- Skip pipeline configurations

### Pipeline Templates

✅ **DO:**
- Use parameters for flexibility
- Include security scanning and validation
- Support multiple environments
- Document parameter usage
- Follow platform-specific best practices

❌ **DON'T:**
- Hardcode subscription IDs or credentials
- Skip error handling
- Create overly complex templates

## 🧪 Testing Your Contributions

Before submitting a pull request, test your contributions locally using the `ign` CLI.

### Module Testing

```bash
# Build and install CLI from source (for testing unreleased changes)
uv build
uv tool install --force dist/ign-*.whl

# List modules to verify discovery
ign list-modules

# Create test stack and add your module
ign add-stack --stack-name test-stack
ign add-resource --stack-name test-stack --resource-type your-module --resource-name demo

# Review generated files
cat spokes/test-stack/terraform/main.tf
```

### Stack Template Testing

```bash
# Create test directory
mkdir /tmp/test-project && cd /tmp/test-project

# Initialize and apply template
ign init
ign add-stack-template --stack-name your-stack

# Verify all files are present
ls -la spokes/your-stack/
ls -la spokes/your-stack/terraform/
ls -la spokes/your-stack/yaml/

# Validate Terraform configuration
cd spokes/your-stack/terraform
terraform init
terraform validate
```

### Pipeline Template Testing

```bash
# Generate stack with your modified template
ign add-stack --stack-name pipeline-test

# Review generated pipeline files
cat spokes/pipeline-test/yaml/*.yml
cat spokes/pipeline-test/azure-pipelines.yml

# Validate YAML syntax
# (Use your CI/CD platform's validation tools)
```

**Note:** Testing requires the CLI to be installed with your local changes. After your contribution is merged and released, it will be available to all team members through the standard CLI installation.

## 🤝 Contribution Workflow

1. **Fork or clone this repository**
2. **Create a feature branch**: `git checkout -b feature/my-contribution`
3. **Make your changes** following the guidelines above
4. **Test thoroughly** using the CLI (see [Testing Your Contributions](#-testing-your-contributions))
5. **Commit with clear messages**: `git commit -m "Add: Azure Container Registry module"`
6. **Push your changes**: `git push origin feature/my-contribution`
7. **Create a Pull Request** with:
   - Clear description of changes
   - Testing evidence
   - Documentation updates
8. **After merge**: Your contribution will be included in the next CLI release

### Release Cycle

- Changes merged to `main` are included in the next release
- Releases are versioned (e.g., v1.2.0) and tagged
- The `ign` CLI pulls from specific release versions
- Users can update their CLI to get the latest modules and templates

## 📝 Naming Conventions

### Modules (`.tf` files)
- Use lowercase with hyphens: `container-registry.tf`
- Be descriptive: `application-insights.tf`, not `appins.tf`
- Match Azure resource naming: `key-vault.tf`, not `keyvault.tf`

### Stack Templates (directories)
- Use lowercase with hyphens: `example-stack`, `alz-connectivity`
- Use abbreviations sparingly and only if widely recognized: `alz` (Azure Landing Zone)
- Be specific: `unity-catalog` instead of `catalog`

### Files
- Terraform: `main.tf`, `variables.tf`, `outputs.tf`, `providers.tf`, `data.tf`, `locals.tf`
- Variables: `dev.tfvars`, `test.tfvars`, `prod.tfvars`
- Pipelines: `build.yml`, `deploy.yml`, `state.yml`, `azure-pipelines.yml`

## 🔍 Finding What You Need

### I want to add a resource to my infrastructure
→ Check [modules/README.md](modules/README.md) and browse `modules/azure/`

### I need a complete infrastructure pattern
→ Check [modules/stacks/README.md](modules/stacks/README.md) and browse `modules/stacks/`

### I'm setting up CI/CD pipelines
→ Check [templates/pipelines/README.md](templates/pipelines/README.md)

### I need to modify Terraform automation scripts
→ Check [templates/scripts/README.md](templates/scripts/README.md)

### I'm bootstrapping a new project
→ Check `bootstrap/terraform/config.yaml`

## 💡 Tips for Contributors

- **Start Small**: Begin with a simple module before tackling complex stack templates
- **Follow Examples**: Review existing modules and stacks to understand established patterns
- **Test Locally**: Install the CLI from source to test your changes before submitting
- **Ask Questions**: Open an issue or reach out to the team for clarification before starting major work
- **Document**: Update README files when adding new features or templates
- **Be Consistent**: Follow existing naming conventions and file structures
- **Think Reusability**: Design contributions that can be used across different projects and teams

## 📦 Package Structure

The `ign` CLI packages and uses content from this repository:
- All module files from `modules/azure/`
- All stack templates from `modules/stacks/`
- All template files from `templates/`
- Configuration schema and validation

When you install or update the CLI, it pulls from the latest release of this repository, making all contributed modules, stacks, and templates available for project generation.
