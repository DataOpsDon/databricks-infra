#!/usr/bin/env python3
"""Lint Terraform module snippets in modules/azure/.

These files are NOT standalone Terraform modules - they are snippets that the
`ign` CLI stitches into a stack's main.tf. They use the `{{resource_name}}`
placeholder and reference symbols defined elsewhere in the assembled stack
(module.resource_group, module.naming, var.tags, ...). That means the usual
`terraform validate` / `tflint` / `terraform-docs` tooling cannot run on them,
so this script enforces our house standard with lightweight text rules instead.

Standard (see modules/MODULE_STANDARD.md):
  ERROR (fails the check):
    - file has no `module "..."` block
    - a module with a registry source (Azure/..., .../azurerm) has no pinned `version`
    - a `variable` block has no `description`
    - the file has no `# Description:` header comment
  WARNING (printed, does not fail):
    - module source is not an Azure Verified Module (Azure/avm-*) and there is
      no `# avm-exempt: <reason>` marker in the file
    - module block does not wire `tags`
    - module block does not wire `enable_telemetry`

Usage:
    python scripts/lint_modules.py [file ...]
If no files are passed, every modules/azure/*.tf file is linted.
"""

from __future__ import annotations

import glob
import os
import re
import sys

# Anchored at the repo root (parent of this script's directory).
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_GLOB = os.path.join(REPO_ROOT, "modules", "azure", "*.tf")

AVM_SOURCE_RE = re.compile(r'source\s*=\s*"Azure/avm-[^"]+"')
ANY_SOURCE_RE = re.compile(r'source\s*=\s*"([^"]+)"')
VERSION_RE = re.compile(r'version\s*=\s*"[^"]+"')
EXEMPT_RE = re.compile(r"#\s*avm-exempt:\s*\S+", re.IGNORECASE)
DESCRIPTION_HEADER_RE = re.compile(r"#\s*Description:", re.IGNORECASE)
# A registry source we expect to be version-pinned (namespace/name/provider form
# or an explicit registry host). Local (./...) and git sources are exempt.
REGISTRY_SOURCE_RE = re.compile(
    r'source\s*=\s*"(Azure/|registry\.terraform\.io/|[^"./][^"]*/[^"]+/[^"]+)"'
)


def find_blocks(text: str, kind: str):
    """Yield (label, body) for every top-level `<kind> "<label>" { ... }` block.

    Uses brace counting so nested objects inside the block are handled. The
    `{{resource_name}}` placeholder is left intact (its braces are balanced).
    """
    header = re.compile(kind + r'\s+"([^"]*)"\s*\{')
    for m in header.finditer(text):
        label = m.group(1)
        depth = 0
        i = m.end() - 1  # position of the opening brace
        start = m.end()
        while i < len(text):
            c = text[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    yield label, text[start:i]
                    break
            i += 1


def lint_file(path: str):
    """Return (errors, warnings) lists of human-readable strings for one file."""
    errors: list[str] = []
    warnings: list[str] = []
    rel = os.path.relpath(path, REPO_ROOT).replace(os.sep, "/")

    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()

    # --- header description comment -------------------------------------------
    if not DESCRIPTION_HEADER_RE.search(text):
        errors.append(
            f"{rel}: missing header comment '# Description: <text>' "
            "(the CLI reads this for `list-modules`)"
        )

    # --- module block(s) ------------------------------------------------------
    # A snippet usually defines exactly one `module` block. Some files are pure
    # helpers (only `data`/`resource` blocks, e.g. shared private DNS lookups) -
    # those are intentional and skip the module checks. A file with none of the
    # three is treated as an unfinished stub (warning, not error).
    module_blocks = list(find_blocks(text, "module"))
    has_data_or_resource = bool(re.search(r'^\s*(data|resource)\s+"', text, re.M))
    if not module_blocks and not has_data_or_resource:
        warnings.append(
            f"{rel}: no `module`/`data`/`resource` block found (unfinished stub?)"
        )

    file_has_avm = bool(AVM_SOURCE_RE.search(text))
    file_is_exempt = bool(EXEMPT_RE.search(text))

    for label, body in module_blocks:
        ident = f'{rel}: module "{label}"'

        source_match = ANY_SOURCE_RE.search(body)
        if not source_match:
            errors.append(f"{ident}: no `source` set")
            continue
        source = source_match.group(1)

        # version pinning for registry sources
        if REGISTRY_SOURCE_RE.search(body) and not VERSION_RE.search(body):
            errors.append(
                f'{ident}: registry source "{source}" is not version-pinned '
                "(add `version = \"x.y.z\"`)"
            )

        # tags / telemetry wiring (warnings)
        if "tags" not in body:
            warnings.append(f"{ident}: does not set `tags` (wire `tags = var.tags`)")
        if "enable_telemetry" not in body:
            warnings.append(
                f"{ident}: does not set `enable_telemetry` "
                "(wire `enable_telemetry = var.enable_telemetry`)"
            )

    # --- AVM preference (warning, opt-out via `# avm-exempt:`) -----------------
    if module_blocks and not file_has_avm and not file_is_exempt:
        warnings.append(
            f"{rel}: no Azure Verified Module source (Azure/avm-*) found. "
            "Use an AVM module if one exists, or add a marker comment "
            "'# avm-exempt: <reason>' to acknowledge the exception."
        )

    # --- variable descriptions ------------------------------------------------
    for label, body in find_blocks(text, "variable"):
        if "description" not in body:
            errors.append(
                f'{rel}: variable "{label}" has no `description`'
            )

    return errors, warnings


def main(argv: list[str]) -> int:
    paths = argv[1:] if len(argv) > 1 else sorted(glob.glob(DEFAULT_GLOB))
    if not paths:
        print("lint_modules: no files to lint", file=sys.stderr)
        return 0

    total_errors = 0
    total_warnings = 0
    for path in paths:
        if not os.path.isfile(path):
            continue
        errors, warnings = lint_file(path)
        for w in warnings:
            print(f"WARN  {w}")
        for e in errors:
            print(f"ERROR {e}")
        total_errors += len(errors)
        total_warnings += len(warnings)

    print(
        f"\nlint_modules: {len(paths)} file(s) checked, "
        f"{total_errors} error(s), {total_warnings} warning(s)"
    )
    return 1 if total_errors else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
