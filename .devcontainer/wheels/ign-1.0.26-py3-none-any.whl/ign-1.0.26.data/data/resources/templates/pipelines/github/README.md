# GitHub Actions Templates (Azure)

GitHub Actions flavour of the Terraform CI/CD standard, targeting **Microsoft Azure**.
Used when `ign init --cloud azure --cicd github` is selected.

The pattern is **one shared CI/CD repo, many consuming repos**:

- The shared repo holds a reusable workflow and composite actions. It is versioned and
  released; consumers pin a tag.
- Each infrastructure repo has one small caller workflow per stack that only decides which
  environment runs for which branch/event.

## Layout

```
github/
├── cicd-repo/                      # Scaffolded by `ign init-cicd-repo`
│   ├── .github/workflows/_terraform-pipeline.yml   # Reusable: CI -> Plan -> Apply
│   ├── .github/workflows/release.yml               # Semver tags + releases on merge
│   ├── .github/actions/tf-ci/action.yaml           # OIDC login, init, fmt, validate, Checkov
│   ├── .github/actions/tf-plan/action.yaml         # OIDC login, init, plan, artifact, PR comment
│   ├── .github/actions/tf-apply/action.yaml        # OIDC login, init, apply reviewed plan
│   ├── CODEOWNERS, .gitignore, README.md
├── consumer/                       # .gitattributes / .gitignore / CODEOWNERS for infra repos
├── scripts/setup-github-oidc.ps1   # Manual OIDC setup (alternative to `ign bootstrap`)
└── stack-workflow.yml.template     # Caller workflow -> .github/workflows/<stack>.yml
```

## Placeholders

| Placeholder | Filled by | Example |
|---|---|---|
| `{github_org}` | `init` / `init-cicd-repo` | `my-org` |
| `{cicd_repo}` | `init` / `init-cicd-repo` | `terraform-azure-cicd` |
| `{cicd_ref}` | `init` / `init-cicd-repo` | `v1.2.0` |
| `{stack_name}` | `add-stack` | `network` |

## How it fits together

1. Shared CI/CD repo: created automatically by the first `ign bootstrap` in the organisation
   (`createCicdRepo_gh`), or scaffold it yourself with `ign init-cicd-repo` and push it as
   `<org>/terraform-azure-cicd` (then allow organisation access to its actions).
2. `ign init --cloud azure --cicd github` → infra repo with `Makefile`, `templates/scripts/tf-*.sh`
   (called by the composite actions) and `templates/scaffold/github/stack-workflow.yml`.
3. `ign bootstrap --apply` → state storage, build/deploy managed identities, and on GitHub:
   role teams + repository guardrails (first run), the `<env>` / `<env>/apply` environments
   with their variables, approvers and branch policy, and the OIDC federated credentials.
   See `bootstrap/README.md` (In GitHub).
4. `ign add-stack` → `stacks/<name>/terraform` + `.github/workflows/<name>.yml`.

## Branch / environment model

| Event | Environment | Apply |
|---|---|---|
| push `feature/**`, PR into `develop` | `dev` | no |
| push `develop` | `dev` | yes (`dev/apply` environment) |
| PR into `main` | `prd` | no |
| push `main` | `prd` | yes (`prd/apply` environment) |

Add required reviewers on the `*/apply` environments for an approval gate.

## Authentication

OIDC only. Two user-assigned managed identities per environment:

| Identity | Roles | Federated subject |
|---|---|---|
| build | Reader on the subscription, Storage Blob Data Contributor on state | `repo:<org>/<repo>:environment:<env>` |
| deploy | Owner (conditional - cannot grant privileged roles), Storage Blob Data Contributor on state | `repo:<org>/<repo>:environment:<env>/apply` |

The composite actions export `ARM_USE_OIDC=true` and `ARM_USE_AZUREAD=true`, so the azurerm
provider and the azurerm state backend both use the OIDC token.
