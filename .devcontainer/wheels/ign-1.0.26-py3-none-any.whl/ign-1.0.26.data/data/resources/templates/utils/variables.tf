# =============================================================================
# Naming Module Variables
# =============================================================================

variable "location" {
  description = "The Azure region for resource deployment"
  type        = string
}

variable "location_short" {
  description = "Short code for the Azure region"
  type        = string
  default     = ""
}

variable "project" {
  description = "Project identifier"
  type        = string
}

variable "lz" {
  description = "Landing zone identifier"
  type        = string
}

variable "suffix" {
  description = "Suffix for resource naming"
  type        = string
}

# Optional backward compatibility
variable "lz_short" {
  description = "Short landing zone identifier (optional)"
  type        = string
  default     = ""
}