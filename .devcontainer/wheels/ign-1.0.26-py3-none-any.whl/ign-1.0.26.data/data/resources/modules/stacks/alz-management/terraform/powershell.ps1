terraform init `
  -backend-config="resource_group_name=rg-intdevplat-state-prd-sdc-01" `
  -backend-config="storage_account_name=sttfstateidpprdsdc01" `
  -backend-config="container_name=infra-testing-tfstate" `
  -backend-config="key=state.tfstate"

terraform fmt -check