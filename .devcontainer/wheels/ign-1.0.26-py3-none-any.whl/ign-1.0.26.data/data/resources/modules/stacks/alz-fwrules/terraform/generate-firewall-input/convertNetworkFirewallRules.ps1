<#
.SYNOPSIS
    Converts Network firewall rules CSV into Terraform-compatible tfvars for Azure Firewall Policy.
    Service Tags are also supported via Destination Type of DestinationAddresses

.DESCRIPTION
    - Parses network rules from a structured CSV file
    - Organises them into Rule Collection Groups and Rule Collections
    - Outputs both raw JSON and Terraform-compatible .tfvars format
    - Handles arrays, wildcards, and optional fields with graceful fallbacks
    - Designed for maintainability and clarity for team collaboration

.PARAMETER CsvPath
    Path to the input CSV file containing firewall rules.

.PARAMETER PerGroup
    Optional switch to output separate JSON files per Rule Collection Group.

.EXAMPLE
    .\convertNetworkFirewallRules.ps1 -CsvPath ".\NetworkFirewallRules.csv"
#>

param(
    [Parameter(Mandatory)]
    [string]$CsvPath,
    
    [switch]$PerGroup
)

# --- Helper: Split comma-separated values into arrays ---------------------------------------------------------------
# Splits a comma-separated string into an array, trims whitespace, removes empties, and deduplicates.
# If '*' is mixed with other values, favours '*' and warns for clarity.
function Split-List {
    param(
        [AllowNull()][string]$Value
    )
    if ([string]::IsNullOrWhiteSpace($Value)) { return @() }
    # Split by comma, trim, drop empties, dedupe, preserve "*" if present
    $items = $Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
    # If "*" is present alongside other values, keep "*" only and warn
    if ($items.Count -gt 1 -and $items -contains '*') {
        Write-Warning "Found '*' mixed with explicit values. Using '*' only: [$Value]"
        return @('*')
    }
    return $items | Select-Object -Unique
}

# --- Helper: Normalise protocol names --------------------------------------
# Converts various protocol strings to standardised casing ('TCP', 'UDP', 'Any').
# Logs unknown values but passes them through.
function Normalize-Protocol {
    param([string]$p)
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    $p = $p.Trim()
    switch -Regex ($p.ToUpper()) {
        'ANY' { 'Any'; break }
        'TCP' { 'TCP'; break }
        'UDP' { 'UDP'; break }
        default {
            Write-Warning "Unknown protocol '$p'. Keeping as-is."
            $p
        }
    }
}

# --- Helper: Convert string to integer safely -----------------------
# Attempts to parse string as integer.
# If parsing fails, logs warning and defaults to 0 to avoid breaking output structure.
function Get-Int {
    param([string]$s, [string]$fieldName = 'number')
    if ([int]::TryParse($s, [ref]([int]$null))) { return [int]$s }
    Write-Warning "Expected integer in '$fieldName' but got '$s'. Defaulting to 0."
    return 0
}

# --- load csv & validate -------------------------------------------------------

if (-not (Test-Path -LiteralPath $CsvPath)) {
    throw "CSV not found: $CsvPath"
}

$rows = Import-Csv -LiteralPath $CsvPath

if (-not $rows -or $rows.Count -eq 0) {
    throw "CSV appears empty: $CsvPath"
}

# Required columns for network rules
# Verifies that expected columns exist in the CSV.
# Halts execution early with descriptive error if columns are missing.
$required = @(
    'RuleCollectionGroup','RuleCollectionGroupPriority',
    'RuleCollectionName','RuleCollectionPriority','RuleCollectionAction',
    'RuleType','RuleName','SourceType','Source','Protocols','DestinationPorts','DestinationType','Destination'
)

$missingCols = $required | Where-Object { -not ($rows[0].PSObject.Properties.Name -contains $_) }
if ($missingCols) {
    throw "Missing required columns: $($missingCols -join ', ')"
}

# --- build structure: Group -> Collection -> Rules ------------------------

# dictionary if rule collection groups
$groups = @{}

foreach ($row in $rows) {
    # Skip non-network rules (future-proof)
    if ($row.RuleType -and $row.RuleType -ne 'NetworkRule') { continue }

    # extract key fields
    $groupName  = $row.RuleCollectionGroup
    $groupPrio  = Get-Int -s $row.RuleCollectionGroupPriority -fieldName 'RuleCollectionGroupPriority'
    $collName   = $row.RuleCollectionName
    $collPrio   = Get-Int -s $row.RuleCollectionPriority -fieldName 'RuleCollectionPriority'
    $collAction = $row.RuleCollectionAction

    # basic validation
    if ([string]::IsNullOrWhiteSpace($groupName)) { Write-Warning "Row missing RuleCollectionGroup. Skipping."; continue }
    if ([string]::IsNullOrWhiteSpace($collName))  { Write-Warning "Row missing RuleCollectionName. Skipping."; continue }
    if ([string]::IsNullOrWhiteSpace($collAction)){ Write-Warning "Row missing RuleCollectionAction. Skipping."; continue }
    if ([string]::IsNullOrWhiteSpace($row.RuleName)) { Write-Warning "Row missing RuleName. Skipping."; continue }

    # create or update rule collection group
    if (-not $groups.ContainsKey($groupName)) {
        $groups[$groupName] = [ordered]@{
            name                        = $groupName
            priority                    = $groupPrio
            network_rule_collections    = @{}  # keyed by collection name
        }
    } else {
        # Keep the highest precision seen; if priority differs, warn once
        if ($groups[$groupName].priority -ne $groupPrio) {
            Write-Warning "Inconsistent priority for group '$groupName'. Using first seen: $($groups[$groupName].priority), saw: $groupPrio"
        }
    }

    # create or update rule collection
    $collections = $groups[$groupName].network_rule_collections
    if (-not $collections.ContainsKey($collName)) {
        $collections[$collName] = [ordered]@{
            name     = $collName
            priority = $collPrio
            action   = $collAction  # 'Allow' or 'Deny'
            rules    = @()
        }
    } else {
        if ($collections[$collName].priority -ne $collPrio) {
            Write-Warning "Inconsistent priority for collection '$collName'. Using first seen: $($collections[$collName].priority), saw: $collPrio"
        }
        if ($collections[$collName].action -ne $collAction) {
            Write-Warning "Inconsistent action for collection '$collName'. Using first seen: $($collections[$collName].action), saw: $collAction"
        }
    }

    # Build rule
    $protocols = Split-List -Value $row.Protocols | ForEach-Object { Normalize-Protocol $_ }
    if (-not $protocols -or $protocols.Count -eq 0) {
        # Default to Any if empty
        $protocols = @('Any')
    }

    $destPorts = Split-List -Value $row.DestinationPorts
    if (-not $destPorts -or $destPorts.Count -eq 0) {
        Write-Warning "Empty DestinationPorts for rule '$($row.RuleName)'. Using '*'."
        $destPorts = @('*')
    }

    # Map Source to terraform field
    $srcList = Split-List -Value $row.Source
    $src = [ordered]@{
        source_addresses = @()
        source_ip_groups = @()
        source_fqdns     = @()
    }
    switch ($row.SourceType) {
        'SourceAddresses' { $src.source_addresses = $srcList }
        'SourceIpGroups'  { $src.source_ip_groups = $srcList }
        'SourceFqdns'     { $src.source_fqdns     = $srcList }
        default {
            Write-Warning "Unknown SourceType '$($row.SourceType)' for rule '$($row.RuleName)'. Treating as addresses."
            $src.source_addresses = $srcList
        }
    }

    # Map Destination type to Terraform field
    $dstList = Split-List -Value $row.Destination
    $dst = [ordered]@{
        destination_addresses = @()
        destination_ip_groups = @()
        destination_fqdns     = @()
    }
    switch ($row.DestinationType) {
        'DestinationAddresses' { $dst.destination_addresses = $dstList }
        'DestinationIpGroups'  { $dst.destination_ip_groups = $dstList }
        'DestinationFqdns'     { $dst.destination_fqdns     = $dstList }
        default {
            Write-Warning "Unknown DestinationType '$($row.DestinationType)' for rule '$($row.RuleName)'. Treating as addresses."
            $dst.destination_addresses = $dstList
        }
    }

    # Compose Terraform-style rule object
    # Builds a Terraform-compatible rule object from CSV fields. Maps source and destination values to appropriate types and normalises protocols.
   $rule = [ordered]@{
    name                  = $row.RuleName
    protocols             = @( $protocols | ForEach-Object { "$_" } )
    destination_ports     = @( $destPorts | ForEach-Object { "$_" } )
    source_ip_groups      = @( $src.source_ip_groups | ForEach-Object { "$_" } )
    source_addresses      = @( $src.source_addresses | ForEach-Object { "$_" } )
    destination_ip_groups = @( $dst.destination_ip_groups | ForEach-Object { "$_" } )
    destination_addresses = @( $dst.destination_addresses | ForEach-Object { "$_" } )
}
    # Attach rule
    $collections[$collName].rules += ,$rule
}

# Finalise: convert collection maps to arrays and sort by priority
$groupArray = @()
foreach ($g in $groups.Values) {
    $collArray = $g.network_rule_collections.Values | Sort-Object priority
    $g.network_rule_collections = $collArray
    $groupArray += ,$g
}
$groupArray = $groupArray | Sort-Object priority

# --- generate native .tfvars file (HCL format) ---------------------------------
# Converts nested data structures into HCL syntax for use in .tfvars files.
# Recursively formats dictionaries, arrays, and primitive types.
function ConvertTo-HCL {
    param (
        $value,
        [int]$indent = 0
    )

    $prefix = " " * $indent

    if ($value -is [System.Collections.IDictionary] -or $value -is [Hashtable]) {
        $items = $value.GetEnumerator() | Sort-Object Name
        $body = ($items | ForEach-Object {
            $key = $_.Key
            $val = ConvertTo-HCL $_.Value ($indent + 2)
            "$prefix  $key = $val"
        }) -join "`n"
        return "{`n$body`n$prefix}"
    }

    elseif ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
        if ($value.Count -eq 0) { return "[]" }
        $lines = $value | ForEach-Object {
            $val = ConvertTo-HCL $_ ($indent + 2)
            "$prefix  $val"
        }
        return "[`n" + ($lines -join ",`n") + "`n$prefix]"
    }

    elseif ($value -is [string]) {
        return "`"$value`""
    }

    else {
        return $value.ToString()
    }
}

# Wrap your array and render
$tfFolder = Resolve-Path "$PSScriptRoot\..\..\terraform"
$hclPath = Join-Path $tfFolder 'network-rules.tfvars'

# Formatting file from "rules" to "rule"
foreach ($group in $groupArray) {
    foreach ($collection in $group.network_rule_collections) {
        $collection.rule = $collection.rules
        $collection.Remove('rules')
    }
    $group.network_rule_collections = @($group.network_rule_collections)

}

$hclBody = "network_rule_collection_group = " + (ConvertTo-HCL @($groupArray))
Set-Content -LiteralPath $hclPath -Value $hclBody -Encoding UTF8
Write-Host "HCL tfvars file written to:" -ForegroundColor Green
Write-Host "$hclPath" -ForegroundColor Cyan