# =============================================================================
# ALZ Security Stack - Output Values
# =============================================================================
# This file defines outputs from the security stack that can be consumed by
# other stacks or external systems. Includes security service endpoints,
# monitoring configurations, and network information.
# =============================================================================

# -----------------------------------------------------------------------------
# Resource Group Outputs
# -----------------------------------------------------------------------------

output "resource_group_id" {
  description = "Resource ID of the security resource group."
  value       = module.resource_group.resource_id
}

output "resource_group_name" {
  description = "Name of the security resource group."
  value       = module.resource_group.name
}

# -----------------------------------------------------------------------------
# Network Outputs
# -----------------------------------------------------------------------------

output "security_virtual_network_id" {
  description = "Resource ID of the security virtual network."
  value       = module.security_virtual_network.resource_id
}

output "security_virtual_network_name" {
  description = "Name of the security virtual network."
  value       = module.security_virtual_network.name
}

output "subnet_ids" {
  description = "Map of subnet names to their resource IDs."
  value = {
    security_services = module.security_virtual_network.subnets["security_services"].resource_id
    monitoring        = module.security_virtual_network.subnets["monitoring"].resource_id
    private_endpoints = module.security_virtual_network.subnets["private_endpoints"].resource_id
    management        = module.security_virtual_network.subnets["management"].resource_id
  }
}

output "nsg_ids" {
  description = "Map of Network Security Group names to their resource IDs."
  value = {
    security_services = module.security_services_nsg.resource_id
    monitoring        = module.monitoring_nsg.resource_id
    private_endpoints = module.private_endpoints_nsg.resource_id
    management        = module.management_nsg.resource_id
  }
}

# -----------------------------------------------------------------------------
# Security & Monitoring Outputs
# -----------------------------------------------------------------------------

output "log_analytics_workspace_id" {
  description = "Resource ID of the security Log Analytics workspace."
  value       = module.log_analytics_workspace.resource_id
}

output "log_analytics_workspace_name" {
  description = "Name of the security Log Analytics workspace."
  value       = module.log_analytics_workspace.name
}

output "sentinel_workspace_id" {
  description = "Resource ID of the Microsoft Sentinel workspace (same as Log Analytics)."
  value       = module.log_analytics_workspace.resource_id
}

output "key_vault_id" {
  description = "Resource ID of the security Key Vault."
  value       = module.key_vault.resource_id
}

output "key_vault_name" {
  description = "Name of the security Key Vault."
  value       = module.key_vault.name
}

output "key_vault_uri" {
  description = "URI of the security Key Vault."
  value       = module.key_vault.uri
}

# -----------------------------------------------------------------------------
# Storage Outputs
# -----------------------------------------------------------------------------

output "security_storage_account_id" {
  description = "Resource ID of the security logs storage account."
  value       = module.security_storage_account.resource_id
}

output "security_storage_account_name" {
  description = "Name of the security logs storage account."
  value       = module.security_storage_account.name
}

output "evidence_storage_account_id" {
  description = "Resource ID of the security evidence storage account."
  value       = module.evidence_storage_account.resource_id
}

output "evidence_storage_account_name" {
  description = "Name of the security evidence storage account."
  value       = module.evidence_storage_account.name
}

# -----------------------------------------------------------------------------
# Recovery Services Outputs
# -----------------------------------------------------------------------------

output "recovery_services_vault_id" {
  description = "Resource ID of the Recovery Services Vault."
  value       = module.recovery_services_vault.resource_id
}

output "recovery_services_vault_name" {
  description = "Name of the Recovery Services Vault."
  value       = module.recovery_services_vault.name
}

# -----------------------------------------------------------------------------
# Automation Outputs
# -----------------------------------------------------------------------------

output "automation_account_id" {
  description = "Resource ID of the Automation Account."
  value       = var.enable_automation_account ? module.automation_account[0].resource_id : null
}

output "automation_account_name" {
  description = "Name of the Automation Account."
  value       = var.enable_automation_account ? module.automation_account[0].name : null
}

# -----------------------------------------------------------------------------
# Data Connector Status
# -----------------------------------------------------------------------------

output "enabled_data_connectors" {
  description = "Map of data connectors and their enabled status."
  value       = local.enabled_data_connectors
}

# -----------------------------------------------------------------------------
# Defender for Cloud Configuration
# -----------------------------------------------------------------------------

output "defender_for_cloud_plans" {
  description = "Map of Defender for Cloud plans and their tier status."
  value       = local.defender_for_cloud_plans
}

# -----------------------------------------------------------------------------
# Private Endpoint Information
# -----------------------------------------------------------------------------

output "private_endpoints" {
  description = "Information about created private endpoints."
  value = {
    key_vault_pe = {
      id   = try(module.key_vault.private_endpoints["key_vault_pe"].id, null)
      fqdn = try(module.key_vault.private_endpoints["key_vault_pe"].private_dns_zone_configs[0].record_sets[0].fqdn, null)
    }
    security_storage_pe = {
      id   = try(module.security_storage_account.private_endpoints["security_storage_pe"].id, null)
      fqdn = try(module.security_storage_account.private_endpoints["security_storage_pe"].private_dns_zone_configs[0].record_sets[0].fqdn, null)
    }
    evidence_storage_pe = {
      id   = try(module.evidence_storage_account.private_endpoints["evidence_storage_pe"].id, null)
      fqdn = try(module.evidence_storage_account.private_endpoints["evidence_storage_pe"].private_dns_zone_configs[0].record_sets[0].fqdn, null)
    }
  }
}