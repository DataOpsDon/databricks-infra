// ---------------------------------------------------------------------------------------------------------------------
// Connectivity Stack - Auxiliary Resources
// This file contains standalone resources not encapsulated by AVM modules:
//   1. Role assignment granting Reader access (typically for tooling/service principal visibility).
//   2. Diagnostic settings forwarding Azure Firewall logs to Log Analytics for centralised monitoring.
//
// Notes:
// - Replace hardcoded subscription scope and principal_id with variables/data sources if reusing across environments.
// - Extend diagnostic setting with metrics or additional log categories as required (e.g., AzureFirewallApplicationRule, NetworkRule logs).
// ---------------------------------------------------------------------------------------------------------------------

// Resource: azurerm_role_assignment.reader_this
// Purpose: Grants Reader role at subscription scope to a principal (service principal / managed identity) for visibility.
// Notes: Avoid hardcoding subscription.
