# =============================================================================
# ALZ Security Stack - Local Values
# =============================================================================
# This file defines local values and computed configurations for the security
# stack, including subnet calculations, security rules, and naming conventions.
# =============================================================================

locals {
  # -----------------------------------------------------------------------------
  # Resource Protection
  # -----------------------------------------------------------------------------

  rg_no_delete_lock = {
    kind = "CanNotDelete"
    name = "Security-Infrastructure-Lock"
  }

  # -----------------------------------------------------------------------------
  # Network Configuration
  # -----------------------------------------------------------------------------

  # Subnet ranges calculated from VNet address space
  subnet_ranges = {
    security_services = cidrsubnet(var.vnet_address_space, 2, 0) # /26 - Security services
    monitoring        = cidrsubnet(var.vnet_address_space, 3, 2) # /27 - Monitoring infrastructure  
    private_endpoints = cidrsubnet(var.vnet_address_space, 3, 3) # /27 - Private endpoints
    management        = cidrsubnet(var.vnet_address_space, 4, 8) # /28 - Management access
  }

  # -----------------------------------------------------------------------------
  # Security Rules for Network Security Groups
  # -----------------------------------------------------------------------------

  security_services_rules = {
    # Allow HTTPS traffic for security services
    allow_https_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowHTTPSInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "443"
    }

    # Allow secure management protocols
    allow_management_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowManagementInbound"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["22", "3389", "5986"]
    }

    # Allow security log collection
    allow_log_collection = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowLogCollection"
      priority                   = 1200
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["514", "601", "1514"]
    }
  }

  monitoring_rules = {
    # Allow monitoring agent communication
    allow_monitoring_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowMonitoringInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["443", "5723", "8084"]
    }
  }

  private_endpoint_rules = {
    # Allow private endpoint traffic
    allow_private_endpoint_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowPrivateEndpointInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "443"
    }
  }

  management_rules = {
    # Allow administrative access from trusted networks
    allow_admin_access = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowAdminAccess"
      priority                   = 1000
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["22", "3389", "443"]
    }
  }

  # -----------------------------------------------------------------------------
  # Security Configuration
  # -----------------------------------------------------------------------------

  # Key Vault access policies for security services
  key_vault_access_policies = {
    security_admin = {
      tenant_id = data.azurerm_client_config.current.tenant_id
      object_id = data.azurerm_client_config.current.object_id

      key_permissions = [
        "Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import",
        "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update",
        "Verify", "WrapKey", "Release", "Rotate", "GetRotationPolicy", "SetRotationPolicy"
      ]

      secret_permissions = [
        "Backup", "Delete", "Get", "List", "Purge", "Recover", "Restore", "Set"
      ]

      certificate_permissions = [
        "Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers",
        "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers",
        "Purge", "Recover", "Restore", "SetIssuers", "Update"
      ]
    }
  }

  # -----------------------------------------------------------------------------
  # Sentinel Data Connectors Configuration
  # -----------------------------------------------------------------------------

  # Map of enabled data connectors based on variables
  enabled_data_connectors = {
    azure_firewall         = var.enable_azure_firewall_connector
    key_vault              = var.enable_key_vault_connector
    storage_account        = var.enable_storage_connector
    network_security_group = var.enable_nsg_connector
    virtual_network        = var.enable_virtual_network_connector
    aks                    = var.enable_aks_connector
    sql_database           = var.enable_sql_connector
    application_gateway    = var.enable_application_gateway_connector
    load_balancer          = var.enable_load_balancer_connector
    waf                    = var.enable_waf_connector
    logic_apps             = var.enable_logic_apps_connector
    service_fabric         = var.enable_service_fabric_connector
  }

  # -----------------------------------------------------------------------------
  # Defender for Cloud Configuration
  # -----------------------------------------------------------------------------

  defender_for_cloud_plans = {
    VirtualMachines = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
    StorageAccounts = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
    KeyVaults = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
    SqlServers = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
    AppServices = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
    Containers = {
      tier = var.enable_defender_for_cloud ? "Standard" : "Free"
    }
  }
}
