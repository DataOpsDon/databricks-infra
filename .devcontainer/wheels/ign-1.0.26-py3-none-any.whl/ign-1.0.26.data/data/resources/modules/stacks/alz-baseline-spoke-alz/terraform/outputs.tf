# ---------------------------------------------------------------------------------------------------------------------
# ALZ Baseline Spoke Outputs
# Outputs from the baseline spoke infrastructure deployment
# ---------------------------------------------------------------------------------------------------------------------

# Resource Group Outputs
output "resource_group_name" {
  description = "The name of the baseline spoke resource group"
  value       = module.resource_group.name
}

output "resource_group_id" {
  description = "The resource ID of the baseline spoke resource group"
  value       = module.resource_group.resource_id
}

output "resource_group_location" {
  description = "The location of the baseline spoke resource group"
  value       = module.resource_group.resource.location
}

# Virtual Network Outputs
output "baseline_virtual_network_name" {
  description = "The name of the baseline spoke virtual network"
  value       = module.baseline_virtual_network.name
}

output "baseline_virtual_network_id" {
  description = "The resource ID of the baseline spoke virtual network"
  value       = module.baseline_virtual_network.resource_id
}

output "baseline_virtual_network_address_space" {
  description = "The address space of the baseline spoke virtual network"
  value       = module.baseline_virtual_network.virtual_network_address_space
}

# Subnet Outputs
output "subnet_ids" {
  description = "Map of subnet names to their resource IDs"
  value = {
    application       = module.baseline_virtual_network.subnets["application"].resource_id
    data              = module.baseline_virtual_network.subnets["data"].resource_id
    management        = module.baseline_virtual_network.subnets["management"].resource_id
    private_endpoints = module.baseline_virtual_network.subnets["private_endpoints"].resource_id
  }
}

output "subnet_address_prefixes" {
  description = "Map of subnet names to their address prefixes"
  value = {
    application       = local.subnet_ranges.application
    data              = local.subnet_ranges.data
    management        = local.subnet_ranges.management
    private_endpoints = local.subnet_ranges.private_endpoints
  }
}

# Security Outputs
output "key_vault_id" {
  description = "The resource ID of the Key Vault"
  value       = module.key_vault.resource_id
}

output "key_vault_name" {
  description = "The name of the Key Vault"
  value       = module.key_vault.name
}

output "key_vault_uri" {
  description = "The URI of the Key Vault"
  value       = module.key_vault.vault_uri
}

# Backup and Recovery Outputs
output "recovery_services_vault_id" {
  description = "The resource ID of the Recovery Services Vault"
  value       = module.recovery_services_vault.resource_id
}

output "recovery_services_vault_name" {
  description = "The name of the Recovery Services Vault"
  value       = module.recovery_services_vault.name
}

# Storage Outputs
output "baseline_storage_account_id" {
  description = "The resource ID of the baseline storage account"
  value       = module.baseline_storage_account.resource_id
}

output "baseline_storage_account_name" {
  description = "The name of the baseline storage account"
  value       = module.baseline_storage_account.name
}

output "asr_storage_account_id" {
  description = "The resource ID of the ASR storage account (if enabled)"
  value       = var.enable_site_recovery ? module.asr_storage_account[0].resource_id : null
}

output "asr_storage_account_name" {
  description = "The name of the ASR storage account (if enabled)"
  value       = var.enable_site_recovery ? module.asr_storage_account[0].name : null
}

# Operational Outputs
output "automation_account_id" {
  description = "The resource ID of the Automation Account (if enabled)"
  value       = var.enable_automation ? module.automation_account[0].resource_id : null
}

output "automation_account_name" {
  description = "The name of the Automation Account (if enabled)"
  value       = var.enable_automation ? module.automation_account[0].name : null
}

output "log_analytics_workspace_id" {
  description = "The resource ID of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.resource_id
}

output "log_analytics_workspace_name" {
  description = "The name of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.name
}

output "log_analytics_workspace_workspace_id" {
  description = "The workspace ID of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.workspace_id
}

# Network Security Group Outputs
output "nsg_ids" {
  description = "Map of NSG names to their resource IDs"
  value = {
    application       = module.application_subnet_nsg.resource_id
    data              = module.data_subnet_nsg.resource_id
    management        = module.management_nsg.resource_id
    private_endpoints = module.private_endpoints_nsg.resource_id
  }
}

# Application Security Group Outputs
output "asg_ids" {
  description = "Map of ASG names to their resource IDs"
  value = {
    web_servers        = azurerm_application_security_group.web_servers.id
    app_servers        = azurerm_application_security_group.app_servers.id
    database_servers   = azurerm_application_security_group.database_servers.id
    management_servers = azurerm_application_security_group.management_servers.id
    monitoring_agents  = azurerm_application_security_group.monitoring_agents.id
  }
}

# Network Watcher Output
output "network_watcher_id" {
  description = "The resource ID of the Network Watcher"
  value       = module.network_watcher.resource_id
}

# Route Table Outputs
output "route_table_ids" {
  description = "Map of route table names to their resource IDs"
  value = {
    application       = module.route_table_application.resource_id
    data              = module.route_table_data.resource_id
    management        = module.route_table_management.resource_id
    private_endpoints = module.route_table_private_endpoints.resource_id
  }
}