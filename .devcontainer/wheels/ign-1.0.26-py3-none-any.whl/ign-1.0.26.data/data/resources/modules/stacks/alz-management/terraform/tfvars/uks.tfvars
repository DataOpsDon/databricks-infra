dns_servers        = [""] // CHANGE THIS
vnet_address_space = ""   // CHANGE THIS
location           = "uksouth"
location_short     = "uks"
nsgs = {
  dbwhost = {
    security_rules = {}
  }
  dbwcont = {
    security_rules = {}
  }
  ado = {
    security_rules = {}
  }
  pep = {
    security_rules = {}
  }
}

route_tables_routes = {
  dbwhost = {
    routes = {
      AllToFirewall = {
        name                   = "AllToFirewall"
        address_prefix         = "0.0.0.0/0"
        next_hop_type          = "VirtualAppliance"
        next_hop_in_ip_address = "" // CHANGE THIS
      }
    }
  }
  dbwcont = {
    routes = {
      AllToFirewall = {
        name                   = "AllToFirewall"
        address_prefix         = "0.0.0.0/0"
        next_hop_type          = "VirtualAppliance"
        next_hop_in_ip_address = "" // CHANGE THIS
      }
    }
  }
  ado = {
    routes = {
      AllToFirewall = {
        name                   = "AllToFirewall"
        address_prefix         = "0.0.0.0/0"
        next_hop_type          = "VirtualAppliance"
        next_hop_in_ip_address = "" // CHANGE THIS
      }
    }
  }
  pep = {
    routes = {
      AllToFirewall = {
        name                   = "AllToFirewall"
        address_prefix         = "0.0.0.0/0"
        next_hop_type          = "VirtualAppliance"
        next_hop_in_ip_address = "" // CHANGE THIS
      }
    }
  }
}

agent_profile_resource_predictions_manual = {
  days_data = [
    # Sunday
    {}, # Empty map to skip Sunday
    # Monday
    {
      "08:00:00" = 1
      "17:00:00" = 0
    },
    # Tuesday
    {
      "08:00:00" = 1
      "17:00:00" = 0
    },
    # Wednesday
    {
      "08:00:00" = 1
      "17:00:00" = 0
    },
    # Thursday
    {
      "08:00:00" = 1
      "17:00:00" = 0
    },
    # Friday
    {
      "08:00:00" = 1
      "17:00:00" = 0
    },
    # Saturday
    {} # Empty map to skip Saturday
  ]
}