variable "subscription_id" {
  description = "Azure subscription ID"
  type        = string
}

variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "uksouth"
}

variable "location_short" {
  description = "Short location code"
  type        = string
  default     = "uks"
}

variable "environment" {
  description = "Environment name (dev, tst, uat, prd)"
  type        = string
}

variable "project" {
  description = "Project code"
  type        = string
  default     = "edp"
}

variable "enable_telemetry" {
  description = "Enable telemetry for Azure resources"
  type        = bool
  default     = true
}

