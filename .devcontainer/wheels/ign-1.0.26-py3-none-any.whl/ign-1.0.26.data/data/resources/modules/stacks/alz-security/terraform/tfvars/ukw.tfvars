# =============================================================================
# ALZ Security Stack - UK West Regional Configuration  
# =============================================================================

# Regional settings
location       = "ukwest"
location_short = "ukw"

# Network configuration for UK West region
vnet_address_space = "10.12.0.0/24" # Different address space for UK West
dns_servers        = []

# Security-specific network configuration
# Example routes (customize based on your requirements)
# security_routes = {
#   to_hub = {
#     name           = "ToHub"
#     address_prefix = "10.10.0.0/16"
#     next_hop_type  = "VirtualNetworkGateway" 
#   }
#   to_onprem = {
#     name           = "ToOnPrem"
#     address_prefix = "172.16.0.0/16"
#     next_hop_type  = "VirtualNetworkGateway"
#   }
# }
# Regional configuration complete