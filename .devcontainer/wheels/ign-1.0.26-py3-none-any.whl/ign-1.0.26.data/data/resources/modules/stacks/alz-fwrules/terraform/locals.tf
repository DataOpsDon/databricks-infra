locals {
  rg_no_delete_lock = {
    kind = "CanNotDelete"
    name = "No Delete Lock"
  }
}
