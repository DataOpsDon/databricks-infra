output "databricks_workspace_url" {
  value = module.databricks.databricks_workspace_url
}

output "databricks_id" {
  value = module.databricks.databricks_workspace_id
}

output "data_lake_name" {
  value = module.storage_account.name
}

output "data_lake_id" {
  value = module.storage_account.resource_id
}

output "data_lake_container_gold" {
  value = module.storage_account.containers["gold"]
}

output "data_lake_container_silver" {
  value = module.storage_account.containers["silver"]
}

output "data_lake_container_bronze" {
  value = module.storage_account.containers["bronze"]
}

output "unity_catalog_container" {
  value = module.storage_account.containers["unity_catalog"]
}

output "data_lake_container_landing" {
  value = module.storage_account.containers["landing"]
}

// Storage Access Connector (for Unity Catalog)
output "databricks_storage_access_connector_name" {
  value = "ac-${module.naming.name.databricks_workspace}-dlz-storage"
}

output "databricks_storage_access_connector_principal_id" {
  value = module.databricks.databricks_access_connector_principal_ids["storage"]
}

output "databricks_storage_access_connector_id" {
  value = module.databricks.databricks_access_connector_ids["storage"]
}

// Service Access Connector (for service-to-service authentication)
output "databricks_service_access_connector_name" {
  value = "ac-${module.naming.name.databricks_workspace}-dlz-service"
}

output "databricks_service_access_connector_principal_id" {
  value = module.databricks.databricks_access_connector_principal_ids["service"]
}

output "databricks_service_access_connector_id" {
  value = module.databricks.databricks_access_connector_ids["service"]
}

// Ingestion Access Connector
output "databricks_ingestion_access_connector_name" {
  value = "ac-${module.naming.name.databricks_workspace}-dlz-ingest"
}

output "databricks_ingestion_access_connector_principal_id" {
  value = module.databricks.databricks_access_connector_principal_ids["ingest"]
}

output "databricks_ingestion_access_connector_id" {
  value = module.databricks.databricks_access_connector_ids["ingest"]
}

output "databricks_name" {
  value = module.databricks.name
}

output "key_vault_name" {
  value = module.key_vault.name
}

output "key_vault_id" {
  value = module.key_vault.resource_id
}

output "key_vault_uri" {
  value = module.key_vault.uri
}
