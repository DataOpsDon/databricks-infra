subscription_id  = "1e1f62ac-0120-4c72-b6a7-87eb14060fb9"
location         = "uksouth"
location_short   = "uks"
enable_telemetry = true
tags = {
  costcentre = "EDP"
  wbscode    = "H1S00"
  owner      = "IT Networks"
  status     = "Production"
}