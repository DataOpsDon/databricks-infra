// Environment
subscription_id = ""
environment     = "prod"

// Entra Groups
dataengineers_group_principal_id = ""
dataadmins_group_principal_id    = ""
datareaders_group_principal_id   = ""