# ---------------------------------------------------------------------------------------------------------------------
# UK South Regional Configuration for ALZ Baseline Spoke
# ---------------------------------------------------------------------------------------------------------------------

location           = "uksouth"
location_short     = "uks"
vnet_address_space = "10.1.0.0/24"
dns_servers        = []

# Optional: Hub VNet resource ID for peering (update with your hub VNet)
# hub_vnet_resource_id = "/subscriptions/your-sub-id/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub"

# Custom routes (add specific routes if needed)
application_routes      = {}
data_routes             = {}
management_routes       = {}
private_endpoint_routes = {}