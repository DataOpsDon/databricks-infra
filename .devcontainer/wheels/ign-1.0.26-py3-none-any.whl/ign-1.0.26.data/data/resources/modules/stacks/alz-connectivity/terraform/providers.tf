// ---------------------------------------------------------------------------------------------------------------------
// Providers & Backend configuration for ALZ Connectivity stack.
// Notes:
//   - AzureRM provider only (no ALZ pattern library needed here).
//   - backend "azurerm": remote state stored in Azure Storage (details supplied via env/backend config).
//   - OIDC used for auth in pipelines (no client secret) with subscription passed via variable.
// ---------------------------------------------------------------------------------------------------------------------
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm" // Core Azure provider
    }
  }
  backend "azurerm" {} // Remote state backend
}

// AzureRM provider: workload identity (OIDC) authentication.
provider "azurerm" {
  features {}
  use_oidc            = true
  subscription_id     = var.subscription_id
  storage_use_azuread = true
}
