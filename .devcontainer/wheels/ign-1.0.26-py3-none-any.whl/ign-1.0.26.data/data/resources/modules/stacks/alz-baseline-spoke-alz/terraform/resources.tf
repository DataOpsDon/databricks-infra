# ---------------------------------------------------------------------------------------------------------------------
# ALZ Baseline Spoke - Additional Resources
# This file contains standalone resources not encapsulated by AVM modules for the baseline spoke:
#   1. Flow logs for Network Security Groups to monitor network traffic
#   2. Diagnostic settings for additional monitoring and compliance
#   3. Resource locks for critical infrastructure protection
#   4. Role assignments for automation accounts and managed identities
#
# Notes:
# - Update subscription scope and principal IDs with appropriate variables
# - Extend diagnostic settings with additional log categories as required for compliance
# ---------------------------------------------------------------------------------------------------------------------

# Optional: Resource lock for critical resources (uncomment if needed)
/*
resource "azurerm_management_lock" "baseline_spoke_lock" {
  name       = "baseline-spoke-no-delete"
  scope      = module.resource_group.resource_id
  lock_level = "CanNotDelete"
  notes      = "Prevents accidental deletion of baseline spoke infrastructure"
}
*/

# Optional: Flow logs for NSGs (requires Network Watcher storage account)
/*
resource "azurerm_network_watcher_flow_log" "application_nsg_flow_log" {
  count                     = var.enable_nsg_flow_logs ? 1 : 0
  network_watcher_name      = module.network_watcher.name
  resource_group_name       = module.resource_group.name
  network_security_group_id = module.application_subnet_nsg.resource_id
  storage_account_id        = module.baseline_storage_account.resource_id
  enabled                   = true

  retention_policy {
    enabled = true
    days    = 30
  }

  traffic_analytics {
    enabled               = true
    workspace_id          = module.log_analytics_workspace.workspace_id
    workspace_region      = var.location
    workspace_resource_id = module.log_analytics_workspace.resource_id
    interval_in_minutes   = 10
  }

  tags = var.tags
}
*/

# Optional: Role assignment for Automation Account managed identity
/*
resource "azurerm_role_assignment" "automation_contributor" {
  count                = var.enable_automation ? 1 : 0
  scope                = module.resource_group.resource_id
  role_definition_name = "Contributor"
  principal_id         = module.automation_account[0].identity[0].principal_id
}
*/

# Optional: Diagnostic settings for subscription-level Activity Log
/*
resource "azurerm_monitor_diagnostic_setting" "subscription_activity_log" {
  name                       = "baseline-spoke-activity-log"
  target_resource_id         = "/subscriptions/${var.subscription_id}"
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category_group = "Audit"
  }
  
  enabled_log {
    category_group = "Administrative"
  }
}
*/