variable "subscription_id" {
  description = "The subscription ID to use for the AzureRM provider."
  type        = string
}

variable "location" {
  description = "The Azure region where resources will be created."
  type        = string
}

variable "location_short" {
  description = "Short code for the Azure region, used in resource names."
  type        = string
}

variable "enable_telemetry" {
  description = "Flag to enable or disable telemetry."
  type        = bool
}

variable "environment" {
  description = "The environment for which the resources are being created (e.g., dev, tst, ppd, prd)."
  type        = string
}

variable "project" {
  description = "The name of the project e.g. 'fwk', 'ttdp'"
  type        = string
}

variable "dataadmins_group_principal_id" {
  type        = string
  description = "The principal ID of the Admins group"
}

variable "dataengineers_group_principal_id" {
  type        = string
  description = "The principal ID of the data engineers group"
}

variable "datareaders_group_principal_id" {
  type        = string
  description = "The principal ID of the data readers group"
}

variable "databricks_spn_id" {
  type        = string
  description = "The principal ID of databricks workspaces"
}

variable "lz" {
  description = "Landing zone code used in resource naming (e.g., 'hub', 'h1s02')"
  type        = string
}