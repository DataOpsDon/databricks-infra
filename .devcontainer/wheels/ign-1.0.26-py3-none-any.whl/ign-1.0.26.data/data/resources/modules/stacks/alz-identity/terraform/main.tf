// ---------------------------------------------------------------------------------------------------------------------
// ALZ Identity Stack - Identity & Security Components
// This Terraform file deploys the identity subscription infrastructure including networking, security, and backup
// components using Azure Verified Modules (AVM) pattern + resource modules.
//
// Notes:
// - Naming centralised via `naming` for consistent resource names across identity assets.
// - Virtual network with dedicated subnets for domain controllers, management, and private endpoints.
// - Recovery Services Vault for backup and disaster recovery of identity infrastructure.
// - Key Vault for secrets, certificates, and key management with proper access policies.
// - Separate NSGs and route tables for each subnet to manage traffic flows and security.
// - Log Analytics workspace for centralized logging and monitoring.
// - Storage account for diagnostics, logs, and backup data.
// - Application Security Groups for micro-segmentation of identity workloads.
// ---------------------------------------------------------------------------------------------------------------------

// Module: naming
// Purpose: Provides consistent base naming primitives used across identity resources.
// Notes: Values are currently static for this stack; adjust if introducing environment-driven variability.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "edp"
  lz       = "i1s00"    // Identity landing zone code
  suffix   = "identity" // Suffix distinguishes identity assets
  lz_short = "identity" // Short descriptor for identity
}

// Module: resource_group
// Purpose: Resource group for all identity components (VNet, domain controllers, Key Vault, Recovery Vault, NSGs).
// Notes: Consider enabling lock if required for production environments
module "resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = module.naming.name.resource_group
  //lock             = local.rg_no_delete_lock 
  tags = var.tags
}

// Module: domain_controllers_nsg
// Purpose: Network Security Group for domain controller subnet with specific rules for AD traffic
// Notes: Includes rules for AD replication, LDAP, Kerberos, DNS, and management traffic
module "domain_controllers_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-i1s00-identity-dc"
  security_rules = {
    allow_ad_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowADInbound"
      priority                   = 1000
      protocol                   = "*"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_ranges    = ["53", "88", "135", "389", "445", "464", "636", "3268", "3269", "49152-65535"]
    }
    allow_rdp_management = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRDPManagement"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = local.subnet_ranges.management
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3389"
    }
  }
  tags = var.tags
}

// Module: management_nsg
// Purpose: Network Security Group for management subnet allowing administrative access
// Notes: Restricts access to management tools and jump boxes
module "management_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-i1s00-identity-mgmt"
  security_rules = {
    allow_rdp_bastion = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowRDPFromBastion"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "3389"
    }
    allow_ssh_bastion = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowSSHFromBastion"
      priority                   = 1100
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "22"
    }
  }
  tags = var.tags
}

// Module: private_endpoints_nsg
// Purpose: Network Security Group applied to private endpoint subnet
// Notes: Allows traffic for private endpoints while maintaining security
module "private_endpoints_nsg" {
  source              = "Azure/avm-res-network-networksecuritygroup/azurerm"
  version             = "0.4.0"
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  location            = var.location
  name                = "nsg-snet-${var.location_short}-edp-i1s00-identity-pep"
  security_rules = {
    allow_https_inbound = {
      access                     = "Allow"
      direction                  = "Inbound"
      name                       = "AllowHTTPSInbound"
      priority                   = 1000
      protocol                   = "Tcp"
      source_address_prefix      = "VirtualNetwork"
      source_port_range          = "*"
      destination_address_prefix = "*"
      destination_port_range     = "443"
    }
  }
  tags = var.tags
}

// Module: route_table_domain_controllers
// Purpose: Route table for domain controller subnet with routes to hub network
// Notes: Enables proper routing for AD replication and hybrid connectivity
module "route_table_domain_controllers" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-i1s00-identity-dc"
  bgp_route_propagation_enabled = true
  routes                        = var.domain_controller_routes
  tags                          = var.tags
}

// Module: route_table_management
// Purpose: Route table for management subnet
// Notes: Routes for management and administrative traffic
module "route_table_management" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-i1s00-identity-mgmt"
  bgp_route_propagation_enabled = true
  routes                        = var.management_routes
  tags                          = var.tags
}

// Module: route_table_private_endpoints
// Purpose: Route table for private endpoint subnet
// Notes: Routes for private endpoint connectivity
module "route_table_private_endpoints" {
  source                        = "Azure/avm-res-network-routetable/azurerm"
  version                       = "0.4.1"
  resource_group_name           = module.resource_group.name
  enable_telemetry              = var.enable_telemetry
  location                      = var.location
  name                          = "rt-snet-${var.location_short}-edp-i1s00-identity-pep"
  bgp_route_propagation_enabled = false
  routes                        = var.private_endpoint_routes
  tags                          = var.tags
}

// Module: identity_virtual_network
// Purpose: Deploys identity virtual network with subnets for domain controllers, management, and private endpoints
// Notes: Subnet CIDRs sourced from locals for consistency. No firewall needed in identity subscription.
module "identity_virtual_network" {
  source           = "Azure/avm-res-network-virtualnetwork/azurerm"
  version          = "0.15.0"
  enable_telemetry = var.enable_telemetry
  name             = module.naming.name.virtual_network
  address_space    = [var.vnet_address_space]
  location         = var.location
  dns_servers      = var.dns_servers
  parent_id        = module.resource_group.resource.id

  subnets = {
    domain_controllers = {
      name                                      = "snet-${var.location_short}-edp-i1s00-identity-dc"
      address_prefixes                          = [local.subnet_ranges.domain_controllers]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.domain_controllers_nsg.resource_id
      }
      route_table = {
        id = module.route_table_domain_controllers.resource_id
      }
    }
    management = {
      name                                      = "snet-${var.location_short}-edp-i1s00-identity-mgmt"
      address_prefixes                          = [local.subnet_ranges.management]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.management_nsg.resource_id
      }
      route_table = {
        id = module.route_table_management.resource_id
      }
    }
    private_endpoints = {
      name                                      = "snet-${var.location_short}-edp-i1s00-identity-pep"
      address_prefixes                          = [local.subnet_ranges.private_endpoints]
      private_endpoint_network_policies_enabled = true
      network_security_group = {
        id = module.private_endpoints_nsg.resource_id
      }
      route_table = {
        id = module.route_table_private_endpoints.resource_id
      }
    }
  }

  tags = var.tags
}

// Module: key_vault
// Purpose: Azure Key Vault for storing secrets, certificates, and encryption keys for identity services
// Notes: Private endpoint enabled for secure access. RBAC enabled for modern access control.
module "key_vault" {
  source              = "Azure/avm-res-keyvault-vault/azurerm"
  version             = "0.11.2"
  name                = module.naming.name.key_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "premium"

  # Security configuration
  purge_protection_enabled      = true
  soft_delete_retention_days    = 90
  public_network_access_enabled = false
  enable_rbac_authorization     = true

  # Network configuration
  network_acls = {
    default_action = "Deny"
    bypass         = "AzureServices"
  }

  # Private endpoint configuration
  private_endpoints = {
    key_vault_pe = {
      name                          = "pe-${module.naming.name.key_vault}"
      subnet_resource_id            = module.identity_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = []
      private_service_connection = {
        name                           = "psc-${module.naming.name.key_vault}"
        private_connection_resource_id = null
        subresource_names              = ["vault"]
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: recovery_services_vault
// Purpose: Recovery Services Vault for backup and disaster recovery of identity infrastructure
// Notes: Geo-redundant storage for cross-region protection. Soft delete enabled for protection against accidental deletion.
module "recovery_services_vault" {
  source              = "Azure/avm-res-recoveryservices-vault/azurerm"
  version             = "0.3.2"
  name                = module.naming.name.recovery_services_vault
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Vault configuration
  sku                   = "Standard"
  storage_mode_type     = "GeoRedundant"
  cross_region_restore  = true
  soft_delete_enabled   = true
  public_network_access = "Disabled"

  # Identity configuration for encryption
  identity = {
    type = "SystemAssigned"
  }

  # VM backup policy for domain controllers
  backup_policies = {
    daily_vm_policy = {
      name     = "daily-dc-backup"
      type     = "V2"
      timezone = "UTC"
      backup = {
        frequency = "Daily"
        time      = "02:00"
      }
      retention_daily = {
        count = 30
      }
      retention_weekly = {
        count    = 12
        weekdays = ["Sunday"]
      }
      retention_monthly = {
        count    = 12
        weekdays = ["Sunday"]
        weeks    = ["First"]
      }
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}


// Module: storage_account
// Purpose: Storage account for diagnostics, logs, and backup data
// Notes: Secure configuration with private endpoints and network restrictions
module "storage_account" {
  source              = "Azure/avm-res-storage-storageaccount/azurerm"
  version             = "0.6.4"
  name                = module.naming.name.storage_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Storage configuration
  account_tier                  = "Standard"
  account_replication_type      = "GRS"
  public_network_access_enabled = false
  shared_access_key_enabled     = true

  # Security configuration
  network_rules = {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  # Private endpoint for secure access
  private_endpoints = {
    storage_pe = {
      name                          = "pe-${module.naming.name.storage_account}"
      subnet_resource_id            = module.identity_virtual_network.subnets["private_endpoints"].resource_id
      private_dns_zone_resource_ids = []
      private_service_connection = {
        name                           = "psc-${module.naming.name.storage_account}"
        private_connection_resource_id = null
        subresource_names              = ["blob"]
      }
    }
  }

  # Containers for different purposes
  containers = {
    backup = {
      name = "backup"
    }
    diagnostics = {
      name = "diagnostics"
    }
    logs = {
      name = "logs"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: application_security_groups
// Purpose: Application Security Groups for micro-segmentation of identity workloads
// Notes: Used in NSG rules for more granular traffic control based on application roles
resource "azurerm_application_security_group" "domain_controllers" {
  name                = "asg-${var.location_short}-edp-i1s00-identity-dc"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "management_servers" {
  name                = "asg-${var.location_short}-edp-i1s00-identity-mgmt"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

resource "azurerm_application_security_group" "monitoring_agents" {
  name                = "asg-${var.location_short}-edp-i1s00-identity-mon"
  location            = var.location
  resource_group_name = module.resource_group.name
  tags                = var.tags
}

// Module: log_analytics_workspace
// Purpose: Log Analytics workspace for identity services monitoring and security analytics
// Notes: Central logging for AD security events, performance metrics, and operational insights
module "log_analytics_workspace" {
  source              = "Azure/avm-res-operationalinsights-workspace/azurerm"
  version             = "0.6.0"
  name                = module.naming.name.log_analytics_workspace
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Workspace configuration
  sku               = "PerGB2018"
  retention_in_days = var.log_analytics_retention_days

  # Security configuration
  internet_ingestion_enabled = false
  internet_query_enabled     = false

  # Solutions for identity monitoring
  solution_plan_map = {
    "SecurityInsights" = {
      product   = "OMSGallery/SecurityInsights"
      publisher = "Microsoft"
    }
    "Security" = {
      product   = "OMSGallery/Security"
      publisher = "Microsoft"
    }
    "ADReplication" = {
      product   = "OMSGallery/ADReplication"
      publisher = "Microsoft"
    }
    "ADAssessment" = {
      product   = "OMSGallery/ADAssessment"
      publisher = "Microsoft"
    }
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: domain_controller_1
// Purpose: Primary domain controller virtual machine for Active Directory services
// Notes: High availability setup with managed disks and backup integration
module "domain_controller_1" {
  count = var.deploy_domain_controllers ? 1 : 0

  source              = "Azure/avm-res-compute-virtualmachine/azurerm"
  version             = "0.21.0"
  name                = "${module.naming.name.virtual_machine}-dc01"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # VM configuration
  size                            = var.domain_controller_vm_size
  disable_password_authentication = false
  admin_username                  = var.admin_username
  admin_password                  = var.admin_password

  # OS configuration
  os_type = "Windows"
  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  source_image_reference = {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-azure-edition-core"
    version   = "latest"
  }

  # Network configuration
  network_interfaces = {
    network_interface_1 = {
      name = "${module.naming.name.network_interface}-dc01"
      ip_configurations = {
        internal = {
          name                          = "internal"
          private_ip_address_allocation = "Static"
          private_ip_address            = local.domain_controller_ips.dc01
          subnet_id                     = module.identity_virtual_network.subnets["domain_controllers"].resource_id
        }
      }
    }
  }

  # Data disks for AD database and logs
  data_disk_managed_disks = {
    disk1 = {
      name                 = "${module.naming.name.virtual_machine}-dc01-data"
      storage_account_type = "Premium_LRS"
      create_option        = "Empty"
      disk_size_gb         = var.ad_data_disk_size_gb
      lun                  = 0
      caching              = "None"
    }
  }

  # Extensions for domain controller setup
  extensions = {
    active_directory_setup = {
      name                       = "ADSetup"
      publisher                  = "Microsoft.Compute"
      type                       = "CustomScriptExtension"
      type_handler_version       = "1.10"
      auto_upgrade_minor_version = true
      settings = jsonencode({
        fileUris         = []
        commandToExecute = "powershell.exe -ExecutionPolicy Unrestricted -Command \"Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools\""
      })
    }
  }

  enable_telemetry = var.enable_telemetry
  tags = merge(var.tags, {
    Role = "DomainController"
    Type = "Primary"
  })
}

// Module: domain_controller_2
// Purpose: Secondary domain controller virtual machine for high availability
// Notes: Provides redundancy and load distribution for AD services
module "domain_controller_2" {
  count = var.deploy_domain_controllers && var.enable_ha_domain_controllers ? 1 : 0

  source              = "Azure/avm-res-compute-virtualmachine/azurerm"
  version             = "0.21.0"
  name                = "${module.naming.name.virtual_machine}-dc02"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # VM configuration
  size                            = var.domain_controller_vm_size
  disable_password_authentication = false
  admin_username                  = var.admin_username
  admin_password                  = var.admin_password

  # OS configuration
  os_type = "Windows"
  os_disk = {
    caching              = "ReadWrite"
    storage_account_type = "Premium_LRS"
  }

  source_image_reference = {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-azure-edition-core"
    version   = "latest"
  }

  # Network configuration
  network_interfaces = {
    network_interface_1 = {
      name = "${module.naming.name.network_interface}-dc02"
      ip_configurations = {
        internal = {
          name                          = "internal"
          private_ip_address_allocation = "Static"
          private_ip_address            = local.domain_controller_ips.dc02
          subnet_id                     = module.identity_virtual_network.subnets["domain_controllers"].resource_id
        }
      }
    }
  }

  # Data disks for AD database and logs
  data_disk_managed_disks = {
    disk1 = {
      name                 = "${module.naming.name.virtual_machine}-dc02-data"
      storage_account_type = "Premium_LRS"
      create_option        = "Empty"
      disk_size_gb         = var.ad_data_disk_size_gb
      lun                  = 0
      caching              = "None"
    }
  }

  # Extensions for domain controller setup
  extensions = {
    active_directory_setup = {
      name                       = "ADSetup"
      publisher                  = "Microsoft.Compute"
      type                       = "CustomScriptExtension"
      type_handler_version       = "1.10"
      auto_upgrade_minor_version = true
      settings = jsonencode({
        fileUris         = []
        commandToExecute = "powershell.exe -ExecutionPolicy Unrestricted -Command \"Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools\""
      })
    }
  }

  enable_telemetry = var.enable_telemetry
  tags = merge(var.tags, {
    Role = "DomainController"
    Type = "Secondary"
  })
}

// Module: automation_account
// Purpose: Azure Automation Account for identity infrastructure management and maintenance
// Notes: Provides runbooks for AD maintenance, monitoring, and automated tasks
module "automation_account" {
  count = var.enable_automation_account ? 1 : 0

  source              = "Azure/avm-res-automation-automationaccount/azurerm"
  version             = "0.3.1"
  name                = module.naming.name.automation_account
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Basic configuration
  sku_name                      = "Basic"
  public_network_access_enabled = false

  # Identity configuration
  identity = {
    type = "SystemAssigned"
  }

  # Link to Log Analytics workspace for enhanced monitoring
  linked_workspace_id = module.log_analytics_workspace.resource_id

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Module: private_dns_zones
// Purpose: Private DNS zones for identity services and Azure service integration
// Notes: Provides DNS resolution for private endpoints and internal services
module "private_dns_zones" {
  count = var.enable_private_dns_zones ? 1 : 0

  source              = "Azure/avm-res-network-privatednszone/azurerm"
  version             = "0.3.2"
  domain_name         = var.domain_name
  resource_group_name = module.resource_group.name

  # Virtual network links
  virtual_network_links = {
    identity_vnet = {
      vnetlinkname     = "link-${module.naming.name.virtual_network}"
      vnetid           = module.identity_virtual_network.resource_id
      autoregistration = true
    }
  }

  # DNS records for domain controllers
  dns_a_records = {
    dc01 = {
      name    = "dc01"
      records = [local.domain_controller_ips.dc01]
      ttl     = 300
    }
    dc02 = var.enable_ha_domain_controllers ? {
      name    = "dc02"
      records = [local.domain_controller_ips.dc02]
      ttl     = 300
    } : null
  }

  enable_telemetry = var.enable_telemetry
  tags             = var.tags
}

// Resource: VM backup protection for domain controllers
// Purpose: Enables backup for domain controller VMs using Recovery Services Vault
// Notes: Critical for disaster recovery and point-in-time recovery of AD infrastructure
resource "azurerm_backup_protected_vm" "dc01_backup" {
  count = var.deploy_domain_controllers ? 1 : 0

  resource_group_name = module.resource_group.name
  recovery_vault_name = module.recovery_services_vault.resource.name
  source_vm_id        = module.domain_controller_1[0].virtual_machine_azurerm.id
  backup_policy_id    = module.recovery_services_vault.backup_policies["daily_vm_policy"].id
}

resource "azurerm_backup_protected_vm" "dc02_backup" {
  count = var.deploy_domain_controllers && var.enable_ha_domain_controllers ? 1 : 0

  resource_group_name = module.resource_group.name
  recovery_vault_name = module.recovery_services_vault.resource.name
  source_vm_id        = module.domain_controller_2[0].virtual_machine_azurerm.id
  backup_policy_id    = module.recovery_services_vault.backup_policies["daily_vm_policy"].id
}

// Resource: Network peering to hub (conditional)
// Purpose: Establishes connectivity to hub network for hybrid and cross-subscription access
// Notes: Enable only if hub connectivity is required
resource "azurerm_virtual_network_peering" "identity_to_hub" {
  count = var.enable_hub_peering ? 1 : 0

  name                      = "peer-${module.naming.name.virtual_network}-to-hub"
  resource_group_name       = module.resource_group.name
  virtual_network_name      = module.identity_virtual_network.name
  remote_virtual_network_id = var.hub_virtual_network_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = var.use_hub_gateway
}

// Data source for current Azure client configuration
data "azurerm_client_config" "current" {}
