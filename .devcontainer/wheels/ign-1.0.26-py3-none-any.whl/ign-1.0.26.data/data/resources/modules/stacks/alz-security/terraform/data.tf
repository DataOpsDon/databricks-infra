# =============================================================================
# ALZ Security Stack - Data Sources
# =============================================================================
# This file defines data sources for retrieving information from other Azure
# resources and Terraform state files to support security stack deployment.
# =============================================================================

# -----------------------------------------------------------------------------
# Current Azure Configuration
# -----------------------------------------------------------------------------

data "azurerm_client_config" "current" {
  # Retrieves current authentication context including tenant ID and object ID
  # for configuring Key Vault access policies and other security resources
}

# -----------------------------------------------------------------------------
# Remote State References (Optional)
# -----------------------------------------------------------------------------
# Uncomment these data sources if you need to reference resources from other stacks

# Management stack remote state (for shared resources like Log Analytics)
/*
data "terraform_remote_state" "management" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"      # UPDATE: State RG name
    storage_account_name = "stterraformstate"        # UPDATE: State storage account
    container_name       = "tfstate"
    key                  = var.management_state_key
  }
}
*/

# Connectivity stack remote state (for hub network information)
/*
data "terraform_remote_state" "connectivity" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"      # UPDATE: State RG name
    storage_account_name = "stterraformstate"        # UPDATE: State storage account
    container_name       = "tfstate"
    key                  = var.connectivity_state_key
  }
}
*/

# Identity stack remote state (for domain controller and DNS information)
/*
data "terraform_remote_state" "identity" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"      # UPDATE: State RG name
    storage_account_name = "stterraformstate"        # UPDATE: State storage account
    container_name       = "tfstate"
    key                  = "identity.tfstate"
  }
}
*/