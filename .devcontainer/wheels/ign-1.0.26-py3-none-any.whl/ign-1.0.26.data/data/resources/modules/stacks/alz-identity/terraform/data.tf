# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack Data Sources
# Data sources for retrieving information from other Terraform states and Azure resources
# ---------------------------------------------------------------------------------------------------------------------

# Current Azure client configuration
data "azurerm_client_config" "current" {}

# Optional: Remote state from hub connectivity stack (uncomment if needed)
/*
data "terraform_remote_state" "hub_connectivity" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "hub-connectivity"
    key                  = "terraform.tfstate"
  }
}
*/

# Optional: Remote state from management stack (uncomment if needed)
/*
data "terraform_remote_state" "management" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "management"
    key                  = "terraform.tfstate"
  }
}
*/

# Optional: Remote state from security stack (uncomment if needed for monitoring integration)
/*
data "terraform_remote_state" "security" {
  backend = "azurerm"
  config = {
    subscription_id      = var.state_sub_id
    resource_group_name  = "rg-terraform-state"
    storage_account_name = "stterraformstate"
    container_name       = "security"
    key                  = "terraform.tfstate"
  }
}
*/