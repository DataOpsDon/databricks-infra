nat_rule_collection_group = [
  {
    name     = "DefaultNatRuleCollectionGroup"
    priority = 100
  }
]
