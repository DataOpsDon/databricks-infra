// ---------------------------------------------------------------------------------------------------------------------
// ALZ Connectivity Stack - Hub Networking & Core Connectivity Components
// This Terraform file deploys the shared hub network (VNet, Firewall, DNS resolver, route tables, NSGs, gateway, PIPs)
// using Azure Verified Modules (AVM) pattern + resource modules.
//
// Notes:
// - Naming centralised via `naming` for consistent resource names across connectivity assets.
// - Hub virtual network + firewall defined in `av_ptn_hubnetworking` with custom subnets for gateway, DNS, private endpoints.
// - Separate NSGs and route tables attached to subnets to manage traffic & private endpoint flows.
// - DNS resolver inbound endpoint uses static IP from locals (see locals.tf) to integrate with enterprise DNS forwarding.
// - VNet Gateway created after hub network to enable ExpressRoute/VPN scenarios (optional, controlled via `deploy_vnet_gateway`).
// - Private DNS zones optionally provisioned (only in uksouth) and linked to hub VNet.
// ---------------------------------------------------------------------------------------------------------------------

// Module: naming
// Purpose: Provides consistent base naming primitives used across hub connectivity resources.
// Notes: Values are currently static for this stack; adjust if introducing environment-driven variability.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "edp"
  lz       = "h1s00"   // Hub landing zone code (platform / shared services)
  suffix   = "hub"     // Suffix distinguishes hub assets
  lz_short = "connect" // Short descriptor for connectivity
}

// Module: resource_group
// Purpose: Resource group for all connectivity components (VNet, firewall, gateway, DNS resolver, route tables, NSGs).
// Notes: Consider enabling lock if required
module "resource_group" {
  source           = "Azure/avm-res-resources-resourcegroup/azurerm"
  version          = "0.2.1"
  enable_telemetry = var.enable_telemetry
  location         = var.location
  name             = module.naming.name.resource_group
  //lock             = local.rg_no_delete_lock 
  tags = var.tags
}


// Module: av_ptn_hubnetworking
// Purpose: Deploys hub virtual network, firewall, and foundational subnets with peering & route table integration.
// Notes: Firewall references remote state policy; ensure fwrules state is applied before this stack. Subnet CIDRs sourced from locals for consistency.
module "avm-ptn-alz-connectivity-hub-and-spoke-vnet" {
  source           = "Azure/avm-ptn-alz-connectivity-hub-and-spoke-vnet/azurerm"
  version          = "0.16.9"
  enable_telemetry = false
  hub_virtual_networks = {
    primary = {
      enabled_resources = {
        virtual_network_gateway_express_route = false
        virtual_network_gateway_vpn           = false
      }
      location = local.resource_groups["hub_primary"].location
      # default_hub_address_space = "10.0.0.0/16"
      default_parent_id = module.resource_groups["hub_primary"].resource_id
      firewall = {
        sku_tier = "Standard"
      }
      firewall_policy = {
        sku = "Standard"
      }
    }
  }
}

resource "random_string" "suffix" {
  length  = 4
  numeric = true
  special = false
  upper   = false
}


module "resource_groups" {
  source   = "Azure/avm-res-resources-resourcegroup/azurerm"
  version  = "0.2.0"
  for_each = local.resource_groups

  location         = each.value.location
  name             = each.value.name
  enable_telemetry = false
  tags             = local.common_tags
}