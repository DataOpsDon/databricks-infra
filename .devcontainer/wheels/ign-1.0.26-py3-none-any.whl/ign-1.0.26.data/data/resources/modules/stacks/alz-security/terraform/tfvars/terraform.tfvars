
# =============================================================================
# ALZ Security Stack - Default Configuration
# =============================================================================
# This file contains the default configuration values for the security stack.
# Update these values according to your specific security requirements and
# organizational policies.
# =============================================================================

# -----------------------------------------------------------------------------
# Required Configuration
# -----------------------------------------------------------------------------

subscription_id  = "00000000-0000-0000-0000-000000000000" # UPDATE: Security subscription ID
state_sub_id     = "00000000-0000-0000-0000-000000000000" # UPDATE: Management subscription ID (for state storage)
enable_telemetry = false

# -----------------------------------------------------------------------------
# Governance & Tagging
# -----------------------------------------------------------------------------

tags = {
  costcentre  = "Security Operations"
  wbscode     = "SEC001"
  owner       = "Security Team"
  status      = "Production"
  environment = "Security"
  stack       = "alz-security"
  purpose     = "Security Operations & Monitoring"
}

# -----------------------------------------------------------------------------
# Security Configuration
# -----------------------------------------------------------------------------

# Microsoft Sentinel and Log Analytics configuration
sentinel_pricing_tier        = "PerGB2018"
log_analytics_retention_days = 90
log_analytics_daily_quota_gb = -1 # Unlimited

# Key Vault configuration for security secrets
key_vault_sku = "premium"

# Storage configuration for security logs and evidence
storage_account_tier     = "Standard"
storage_replication_type = "GRS" # Geo-redundant for disaster recovery

# -----------------------------------------------------------------------------
# Network Configuration
# -----------------------------------------------------------------------------

vnet_address_space = "10.2.0.0/24" # Security VNet address space
dns_servers        = []            # Use Azure default DNS

# -----------------------------------------------------------------------------
# Data Connector Configuration
# -----------------------------------------------------------------------------
# Enable comprehensive Azure service monitoring in Sentinel

enable_azure_firewall_connector      = true
enable_key_vault_connector           = true
enable_storage_connector             = true
enable_nsg_connector                 = true
enable_virtual_network_connector     = true
enable_aks_connector                 = true
enable_sql_connector                 = true
enable_application_gateway_connector = true
enable_load_balancer_connector       = true
enable_waf_connector                 = true
enable_logic_apps_connector          = true
enable_service_fabric_connector      = true

# -----------------------------------------------------------------------------
# Security Features
# -----------------------------------------------------------------------------

# Microsoft Defender for Cloud configuration
enable_defender_for_cloud                = true
enable_security_center_auto_provisioning = true
enable_just_in_time_access               = true
enable_adaptive_network_hardening        = true

# -----------------------------------------------------------------------------
# Connectivity Configuration
# -----------------------------------------------------------------------------

enable_hub_peering     = false # Enable when hub connectivity is available
hub_virtual_network_id = ""    # UPDATE: Hub VNet resource ID when peering enabled
use_hub_gateway        = false # Use hub gateway for hybrid connectivity

# -----------------------------------------------------------------------------
# Remote State Configuration
# -----------------------------------------------------------------------------

management_state_key   = "management.tfstate"
connectivity_state_key = "connectivity.tfstate"
