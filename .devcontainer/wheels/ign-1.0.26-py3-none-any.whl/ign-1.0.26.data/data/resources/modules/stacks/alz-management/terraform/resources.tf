// ---------------------------------------------------------------------------------------------------------------------
// Management Stack - Standalone Resources
// This file contains individual Azure resources not encapsulated by AVM modules for this stack.
// Included:
//   1. DevCenter Project binding to DevCenter instance.
//   2. Role assignments (Network Contributor, Reader) at VNet/subscription scopes for service principals / managed identities.
// ---------------------------------------------------------------------------------------------------------------------

// Resource: azurerm_dev_center_project.this
// Purpose: Associates a project with the deployed DevCenter enabling DevOps pool integration & environment provisioning.
// Notes: Name derived from naming module; consider tagging for cost tracking if needed.


// Resource: azurerm_role_assignment.nc_this
// Purpose: Grants Network Contributor at VNet scope for network configuration operations (peering, subnet updates).
// Notes: Consider restricting to specific subnets or using custom role with minimized actions.

// Resource: azurerm_role_assignment.reader_this
// Purpose: Grants Reader role at VNet scope for visibility without modification rights.
// Notes: Same principal currently used; validate necessity of both roles; Reader may be redundant if Network Contributor assigned.


// Resource: azurerm_role_assignment.reader_this_sub
// Purpose: Grants Reader role at subscription scope for broad visibility across resources.
// Notes: Hardcoded subscription & principal IDs; replace with data source or variable. Ensure compliance with least privilege standards.
