
# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack Configuration
# Terraform variables file for deploying identity subscription infrastructure
# ---------------------------------------------------------------------------------------------------------------------

# Core Infrastructure Configuration
subscription_id    = "" # Update with your identity subscription ID
enable_telemetry   = false
vnet_address_space = "10.0.0.0/24" # Update with your identity VNet CIDR

# Networking Configuration
dns_servers          = [] # Leave empty initially - will be populated with DC IPs after deployment
hub_vnet_resource_id = "" # Optional: Resource ID of hub VNet for peering

# Active Directory Configuration
domain_name         = "contoso.local"
domain_netbios_name = "CONTOSO"
forest_mode         = "WinThreshold"
domain_mode         = "WinThreshold"

# Security Configuration
enable_just_in_time_access           = true
enable_azure_ad_connect              = true
enable_privileged_access_workstation = false

# Backup Retention Configuration (longer for identity infrastructure)
backup_retention_daily   = 30
backup_retention_weekly  = 12
backup_retention_monthly = 12
backup_retention_yearly  = 5

# Log Analytics Configuration (higher retention for security/compliance)
log_analytics_retention_days = 180
log_analytics_daily_quota_gb = 5

# Storage Configuration (GRS recommended for identity data)
storage_account_replication_type = "GRS"

# Route Configuration (empty by default - add custom routes as needed)
domain_controller_routes = {}
management_routes        = {}
private_endpoint_routes  = {}

# Resource Tags
tags = {
  costcentre  = "EDP"
  wbscode     = "I1S00"
  owner       = "Identity Team"
  status      = "Production"
  environment = "Identity"
  workload    = "Active Directory"
  project     = "ALZ Implementation"
  criticality = "Mission Critical"
}
