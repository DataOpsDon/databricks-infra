data "azurerm_client_config" "main" {}

/*
data "azurerm_virtual_network" "this" {
  name                = "vnet-uks-${var.project}-${module.naming.lz}-${var.environment}"
  resource_group_name = "rg-uks-${var.project}-${module.naming.lz}-${var.environment}"
}

data "azurerm_network_security_group" "host_this" {
  name                = "nsg-snet-uks-${var.project}-${module.naming.lz}-${var.environment}-dbwhost"
  resource_group_name = "rg-uks-${var.project}-${module.naming.lz}-${var.environment}"
}

data "azurerm_network_security_group" "cont_this" {
  name                = "nsg-snet-uks-${var.project}-${module.naming.lz}-${var.environment}-dbwcont"
  resource_group_name = "rg-uks-${var.project}-${module.naming.lz}-${var.environment}"
}

data "azurerm_subnet" "dlz" {
  name                 = "snet-uks-${var.project}-${module.naming.lz}-${var.environment}-dlz"
  resource_group_name  = "rg-uks-${var.project}-${module.naming.lz}-${var.environment}"
  virtual_network_name = data.azurerm_virtual_network.this.name
}
*/