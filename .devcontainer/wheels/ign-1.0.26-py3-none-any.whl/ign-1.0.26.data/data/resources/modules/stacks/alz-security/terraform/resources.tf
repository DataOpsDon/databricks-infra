# =============================================================================
# ALZ Security Stack - Additional Resources
# =============================================================================
# This file contains standalone resources not encapsulated by AVM modules for
# security infrastructure including diagnostic settings, role assignments, and
# security policies that enhance the security posture of the environment.
# =============================================================================

# -----------------------------------------------------------------------------
# Microsoft Defender for Cloud Configuration
# -----------------------------------------------------------------------------

# Configure Defender for Cloud pricing tiers for enhanced security features
resource "azurerm_security_center_subscription_pricing" "defender_plans" {
  for_each = var.enable_defender_for_cloud ? local.defender_for_cloud_plans : {}

  tier          = each.value.tier
  resource_type = each.key
}

# Enable automatic provisioning of security agents
resource "azurerm_security_center_auto_provisioning" "main" {
  count = var.enable_security_center_auto_provisioning ? 1 : 0

  auto_provision = "On"
}

# Configure security contacts for alerts and notifications
resource "azurerm_security_center_contact" "security_contact" {
  count = var.enable_defender_for_cloud ? 1 : 0

  name                = "Security Team"
  email               = "security-team@company.com" # UPDATE: Security team email
  phone               = "+1234567890"               # UPDATE: Security team phone
  alert_notifications = true
  alerts_to_admins    = true
}

# -----------------------------------------------------------------------------
# Activity Log Diagnostic Settings (Optional)
# -----------------------------------------------------------------------------

# Forward subscription activity logs to security Log Analytics workspace
/*
resource "azurerm_monitor_diagnostic_setting" "subscription_activity_log" {
  name               = "security-activity-log"
  target_resource_id = "/subscriptions/${var.subscription_id}"
  log_analytics_workspace_id = module.log_analytics_workspace.resource_id

  enabled_log {
    category_group = "Audit"
  }
  
  enabled_log {
    category_group = "Administrative" 
  }
  
  enabled_log {
    category_group = "Security"
  }
  
  enabled_log {
    category_group = "Policy"
  }
}
*/

# -----------------------------------------------------------------------------
# Role Assignments (Optional)
# -----------------------------------------------------------------------------

# Grant Security Reader role to security team
/*
resource "azurerm_role_assignment" "security_reader" {
  scope                = "/subscriptions/${var.subscription_id}"
  role_definition_name = "Security Reader"
  principal_id         = "00000000-0000-0000-0000-000000000000"  # UPDATE: Security team principal ID
}
*/

# Grant Sentinel Contributor role to security analysts
/*
resource "azurerm_role_assignment" "sentinel_contributor" {
  scope                = module.log_analytics_workspace.resource_id
  role_definition_name = "Microsoft Sentinel Contributor"
  principal_id         = "00000000-0000-0000-0000-000000000000"  # UPDATE: Security analysts group ID
}
*/

# -----------------------------------------------------------------------------
# Azure Policy Assignments (Optional)
# -----------------------------------------------------------------------------

# Assign security baseline policies to the subscription
/*
resource "azurerm_subscription_policy_assignment" "security_baseline" {
  name                 = "security-baseline"
  subscription_id      = "/subscriptions/${var.subscription_id}"
  policy_definition_id = "/providers/Microsoft.Authorization/policySetDefinitions/179d1daa-458f-4e47-8086-2a68d0d6c38f"  # Azure Security Benchmark
  
  parameters = jsonencode({
    logAnalyticsWorkspaceId = {
      value = module.log_analytics_workspace.resource_id
    }
  })
  
  identity {
    type = "SystemAssigned"
  }
  
  location = var.location
}
*/