# Configuration Guide - alz-connectivity

This document lists all files that need to be updated with your specific configuration values before deploying this stack.

## ⚠️ Required Updates

Before deploying this stack, you must update the following files with your Azure subscription IDs and other configuration values:

### 1. State Configuration (`yaml/state.yml`)

Update the Terraform state backend configuration:

- **`stateSubscriptionId`**: Your Azure subscription ID for Terraform state storage
- **`stateResourceGroupName`**: Resource group name where Terraform state is stored
- **`stateStorageAccountName`**: Storage account name for Terraform state
- **`stateStorageAccountContainerName`**: Container name for Terraform state files

Example:
```yaml
variables:
  - name: stateSubscriptionId
    value: 'your-subscription-id-here'
  - name: stateResourceGroupName
    value: 'rg-terraform-state'
  - name: stateStorageAccountName
    value: 'stterraformstate'
  - name: stateStorageAccountContainerName
    value: 'tfstate'
```

### 2. Terraform Variable Files (`terraform/*.tfvars`)

Update the following `.tfvars` files with your subscription IDs:

- **`terraform/terraform.tfvars`**
  - Common variables shared across all environments

- **`terraform/uks.tfvars`**
  - Location-specific variables for UK South

- **`terraform/ukw.tfvars`**
  - Location-specific variables for UK West

Example for environment-specific files (e.g., `dev.tfvars`):
```hcl
subscription_id            = "your-subscription-id-here"
management_subscription_id = "your-management-subscription-id-here"
location                   = "uksouth"
environment                = "dev"
```

## 📝 Additional Configuration

You may also need to update:

- **Service Connection:** Check `azure-pipelines.yml` and ensure the service connection name matches your Azure DevOps configuration
- **Resource Names**: Review and customize resource names in `terraform/main.tf` if needed
- **Variables**: Review `terraform/variables.tf` for any additional variables that need values

## ✅ Verification

After updating the configuration files:

1. Verify all subscription IDs are correct
2. Ensure state backend configuration points to the correct storage account
3. Review environment-specific values in `.tfvars` files
4. Test with `terraform plan` before applying changes

## 📚 Resources

- [Azure Subscription IDs](https://docs.microsoft.com/en-us/azure/azure-portal/get-subscription-tenant-id)
- [Terraform State Backend](https://www.terraform.io/docs/language/settings/backends/azurerm.html)
