# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack Variables
# Variables for deploying comprehensive identity subscription infrastructure including domain controllers, 
# networking, security, backup, and operational components.
# ---------------------------------------------------------------------------------------------------------------------

# Core Infrastructure Variables
variable "subscription_id" {
  description = "The subscription ID to use for the AzureRM provider."
  type        = string
}

variable "location" {
  description = "The Azure region where resources will be deployed."
  type        = string
}

variable "location_short" {
  description = "Short code for the Azure region, used in resource names."
  type        = string
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "enable_telemetry" {
  description = "Flag to enable telemetry for Azure modules"
  type        = bool
  default     = true
}

# Networking Variables
variable "vnet_address_space" {
  description = "The address space of the identity VNet (e.g., '10.0.0.0/24')"
  type        = string
}

variable "dns_servers" {
  description = "Custom DNS servers for the VNet (typically domain controllers)"
  type        = list(string)
  default     = []
}

variable "hub_vnet_resource_id" {
  description = "Resource ID of the hub virtual network for peering"
  type        = string
  default     = ""
}

# Domain Controller Configuration
variable "domain_name" {
  description = "Active Directory domain name (e.g., contoso.local)"
  type        = string
  default     = "identity.local"
}

variable "domain_netbios_name" {
  description = "NetBIOS name for the domain (e.g., CONTOSO)"
  type        = string
  default     = "IDENTITY"
}

variable "forest_mode" {
  description = "Active Directory forest functional level"
  type        = string
  default     = "WinThreshold"
  validation {
    condition = contains([
      "Win2003", "Win2003Interim", "Win2008", "Win2008R2",
      "Win2012", "Win2012R2", "Win2016", "WinThreshold"
    ], var.forest_mode)
    error_message = "Forest mode must be a valid AD functional level."
  }
}

variable "domain_mode" {
  description = "Active Directory domain functional level"
  type        = string
  default     = "WinThreshold"
  validation {
    condition = contains([
      "Win2003", "Win2003Interim", "Win2008", "Win2008R2",
      "Win2012", "Win2012R2", "Win2016", "WinThreshold"
    ], var.domain_mode)
    error_message = "Domain mode must be a valid AD functional level."
  }
}

# Route Table Variables
variable "domain_controller_routes" {
  description = "Custom routes for domain controller subnet"
  type = map(object({
    name                   = string
    address_prefix         = string
    next_hop_type          = string
    next_hop_in_ip_address = optional(string)
  }))
  default = {}
}

variable "management_routes" {
  description = "Custom routes for management subnet"
  type = map(object({
    name                   = string
    address_prefix         = string
    next_hop_type          = string
    next_hop_in_ip_address = optional(string)
  }))
  default = {}
}

variable "private_endpoint_routes" {
  description = "Custom routes for private endpoint subnet"
  type = map(object({
    name                   = string
    address_prefix         = string
    next_hop_type          = string
    next_hop_in_ip_address = optional(string)
  }))
  default = {}
}

# Backup Configuration Variables
variable "backup_retention_daily" {
  description = "Number of days to retain daily backups for domain controllers"
  type        = number
  default     = 30
  validation {
    condition     = var.backup_retention_daily >= 7 && var.backup_retention_daily <= 9999
    error_message = "Daily backup retention must be between 7 and 9999 days."
  }
}

variable "backup_retention_weekly" {
  description = "Number of weeks to retain weekly backups"
  type        = number
  default     = 12
  validation {
    condition     = var.backup_retention_weekly >= 1 && var.backup_retention_weekly <= 5163
    error_message = "Weekly backup retention must be between 1 and 5163 weeks."
  }
}

variable "backup_retention_monthly" {
  description = "Number of months to retain monthly backups"
  type        = number
  default     = 12
  validation {
    condition     = var.backup_retention_monthly >= 1 && var.backup_retention_monthly <= 1188
    error_message = "Monthly backup retention must be between 1 and 1188 months."
  }
}

variable "backup_retention_yearly" {
  description = "Number of years to retain yearly backups"
  type        = number
  default     = 5
  validation {
    condition     = var.backup_retention_yearly >= 1 && var.backup_retention_yearly <= 99
    error_message = "Yearly backup retention must be between 1 and 99 years."
  }
}

# Log Analytics Configuration
variable "log_analytics_retention_days" {
  description = "Log Analytics workspace data retention in days for identity logs"
  type        = number
  default     = 180
  validation {
    condition     = var.log_analytics_retention_days >= 30 && var.log_analytics_retention_days <= 730
    error_message = "Log Analytics retention must be between 30 and 730 days."
  }
}

variable "log_analytics_daily_quota_gb" {
  description = "Log Analytics workspace daily ingestion quota in GB"
  type        = number
  default     = 5
}

# Security Configuration
variable "enable_just_in_time_access" {
  description = "Enable Just-In-Time VM access for domain controllers"
  type        = bool
  default     = true
}

variable "enable_azure_ad_connect" {
  description = "Prepare infrastructure for Azure AD Connect installation"
  type        = bool
  default     = true
}

variable "enable_privileged_access_workstation" {
  description = "Enable Privileged Access Workstation (PAW) subnet and security"
  type        = bool
  default     = false
}

# Storage Configuration
variable "storage_account_replication_type" {
  description = "Storage account replication type for identity data (recommended: GRS for DR)"
  type        = string
  default     = "GRS"
  validation {
    condition     = contains(["LRS", "GRS", "RAGRS", "ZRS", "GZRS", "RAGZRS"], var.storage_account_replication_type)
    error_message = "Storage replication type must be one of: LRS, GRS, RAGRS, ZRS, GZRS, RAGZRS."
  }
}