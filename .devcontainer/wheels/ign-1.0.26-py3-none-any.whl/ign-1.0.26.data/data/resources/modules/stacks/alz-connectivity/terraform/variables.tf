variable "subscription_id" {
  description = "The subscription ID to use for the AzureRM provider."
  type        = string
}

variable "location" {
  description = "The Azure region where resources will be deployed."
  type        = string
}

variable "tags" {
  type = map(string)
}

variable "location_short" {
  description = "Short code for the Azure region, used in resource names."
  type        = string
}

variable "enable_telemetry" {
  description = "Flag to enable telemetry for the connectivity module"
  type        = bool
}


