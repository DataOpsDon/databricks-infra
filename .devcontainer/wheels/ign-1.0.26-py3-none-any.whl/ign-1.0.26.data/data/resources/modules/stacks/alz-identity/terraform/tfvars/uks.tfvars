# ---------------------------------------------------------------------------------------------------------------------
# UK South Regional Configuration for ALZ Identity Stack
# ---------------------------------------------------------------------------------------------------------------------

location           = "uksouth"
location_short     = "uks"
vnet_address_space = "10.0.0.0/24"
dns_servers        = []

# Optional: Hub VNet resource ID for peering (update with your hub VNet)
# hub_vnet_resource_id = "/subscriptions/your-sub-id/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub"

# Active Directory Configuration for UK South
domain_name         = "contoso.local"
domain_netbios_name = "CONTOSO"

# Custom routes for identity infrastructure (add specific routes if needed)
domain_controller_routes = {}
management_routes        = {}
private_endpoint_routes  = {}

# ------------------------- OPTIONAL CUSTOM ROUTE EXAMPLES -------------------------
# Uncomment and modify these examples if you need custom routing:

# Example: Route traffic through hub firewall
/*
domain_controller_routes = {
  to_on_premises = {
    name                   = "ToOnPremises"
    address_prefix         = "192.168.0.0/16"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.1.1.4"  # Hub firewall IP
  }
}
*/

# Example: Management traffic through hub
/*
management_routes = {
  internet_via_hub = {
    name                   = "InternetViaHub"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.1.1.4"  # Hub firewall IP
  }
}
*/