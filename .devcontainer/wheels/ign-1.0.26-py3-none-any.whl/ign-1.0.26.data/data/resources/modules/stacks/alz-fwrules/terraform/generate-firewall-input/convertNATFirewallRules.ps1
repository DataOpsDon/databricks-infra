param(
    [Parameter(Mandatory)]
    [string]$CsvPath,
    [switch]$DebugOutput
)

# --- Helpers ---
function Split-List {
    param([AllowNull()][string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return @() }
    $items = $Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
    if ($items.Count -gt 1 -and $items -contains '*') {
        Write-Warning "Found '*' mixed with explicit values. Using '*' only: [$Value]"
        return @('*')
    }
    $unique = $items | Select-Object -Unique
    return @($unique)  # ALWAYS return an array
}

function Normalize-Protocol {
    param([string]$p)
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    switch -Regex ($p.ToUpper()) {
        'ANY' { @('TCP','UDP'); break }
        'TCP' { 'TCP'; break }
        'UDP' { 'UDP'; break }
        default { Write-Warning "Unknown protocol '$p'. Keeping as-is."; $p }
    }
}

function Get-Int {
    param([string]$s, [string]$fieldName = 'number')
    if ([int]::TryParse($s, [ref]([int]$null))) { return [int]$s }
    Write-Warning "Expected integer in '$fieldName' but got '$s'. Defaulting to 0."
    return 0
}

# New helpers for validation
function Test-IPv4 {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
    return [System.Net.IPAddress]::TryParse($Value, [ref]([System.Net.IPAddress]$null)) -and ($Value -match '^\d+\.\d+\.\d+\.\d+$')
}
function Test-Fqdn {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
    return ($Value.Length -le 253) -and ($Value -match '^(?=.{1,253}$)(?!-)([a-zA-Z0-9-]{1,63}\.)+[A-Za-z]{2,63}$')
}

# --- Load CSV ---
if (-not (Test-Path -LiteralPath $CsvPath)) { throw "CSV not found: $CsvPath" }
$rows = Import-Csv -LiteralPath $CsvPath
if (-not $rows -or $rows.Count -eq 0) { throw "CSV appears empty: $CsvPath" }

# Required columns
$required = @(
    'RuleCollectionGroup','RuleCollectionGroupPriority',
    'RuleCollectionName','RuleCollectionPriority','RuleCollectionAction',
    'RuleType','RuleName','SourceType','Source','Protocols',
    'DestinationPorts','DestinationType','Destination',
    'TranslatedAddress','TranslatedFQDN','TranslatedPort'
)
$missingCols = $required | Where-Object { -not ($rows[0].PSObject.Properties.Name -contains $_) }
if ($missingCols) { throw "Missing required columns: $($missingCols -join ', ')" }

# --- Build structure ---
$groups = @{}

foreach ($row in $rows) {
    if ($row.RuleType -and $row.RuleType -ne 'NatRule') { continue }

    $groupName  = $row.RuleCollectionGroup
    $groupPrio  = Get-Int $row.RuleCollectionGroupPriority 'RuleCollectionGroupPriority'
    $collName   = $row.RuleCollectionName
    $collPrio   = Get-Int $row.RuleCollectionPriority 'RuleCollectionPriority'
    $collAction = $row.RuleCollectionAction

    if ([string]::IsNullOrWhiteSpace($groupName)) { Write-Warning "Missing RuleCollectionGroup"; continue }
    if ([string]::IsNullOrWhiteSpace($collName))  { Write-Warning "Missing RuleCollectionName"; continue }
    if ([string]::IsNullOrWhiteSpace($collAction)){ Write-Warning "Missing RuleCollectionAction"; continue }
    if ([string]::IsNullOrWhiteSpace($row.RuleName)) { Write-Warning "Missing RuleName"; continue }

    if (-not $groups.ContainsKey($groupName)) {
        $groups[$groupName] = [ordered]@{
            name                 = $groupName
            priority             = $groupPrio
            nat_rule_collections = @{}
        }
    }

    $collections = $groups[$groupName].nat_rule_collections
    if (-not $collections.ContainsKey($collName)) {
        $collections[$collName] = [ordered]@{
            name     = $collName
            priority = $collPrio
            action   = $collAction
            rules    = @()
        }
    }

    # Protocols
    $protocols = Split-List $row.Protocols | ForEach-Object { Normalize-Protocol $_ }
    $protocols = $protocols | ForEach-Object { $_ } # flatten
    if (-not $protocols) { $protocols = @('TCP','UDP') }

    # Destination ports
    $destPorts = Split-List $row.DestinationPorts
    if (-not $destPorts) { $destPorts = @('*') }

    # Source mapping
    $srcList = Split-List $row.Source
    $src = [ordered]@{
        source_addresses = @()
        source_ip_groups = @()
        source_fqdns     = @()
    }
    switch ($row.SourceType) {
        'SourceAddresses' { $src.source_addresses = $srcList }
        'SourceIpGroups'  { $src.source_ip_groups = $srcList }
        'SourceFqdns'     { $src.source_fqdns     = $srcList }
        default           { $src.source_addresses = $srcList }
    }

    # Destination mapping
    $dstList = Split-List $row.Destination
    $dst = [ordered]@{
        destination_addresses = @()
        destination_ip_groups = @()
        destination_fqdns     = @()
    }
    switch ($row.DestinationType) {
        'DestinationAddresses' { $dst.destination_addresses = $dstList }
        'DestinationIpGroups'  { $dst.destination_ip_groups = $dstList }
        'DestinationFqdns'     { $dst.destination_fqdns     = $dstList }
        default                { $dst.destination_addresses = $dstList }
    }

    # Translated mapping (separated columns) - force arrays to avoid char indexing
    $translatedAddressList = @(Split-List $row.TranslatedAddress)
    $translatedFqdnList    = @(Split-List $row.TranslatedFQDN)

    # Port
    if ($row.TranslatedPort -and $row.TranslatedPort -ne "*") {
        $portValue = [int]$row.TranslatedPort
    } else {
        $portValue = $null
    }

    # Normalise translated targets (single value each, others set to $null)
    $translatedAddress = if ($translatedAddressList.Count -gt 0) { $translatedAddressList[0] } else { $null }
    if ($translatedAddressList.Count -gt 1) { Write-Warning "Multiple TranslatedAddress values '${translatedAddressList -join ', '}' found. Using first: $translatedAddress" }

    $translatedFqdn = if ($translatedFqdnList.Count -gt 0) { $translatedFqdnList[0] } else { $null }
    if ($translatedFqdnList.Count -gt 1) { Write-Warning "Multiple TranslatedFQDN values '${translatedFqdnList -join ', '}' found. Using first: $translatedFqdn" }

    # Validation & mutual exclusivity enforcement (relaxed)
    $origTranslatedAddress = $translatedAddress
    $origTranslatedFqdn    = $translatedFqdn
    if ($translatedAddress -and -not (Test-IPv4 $translatedAddress)) { Write-Warning "TranslatedAddress '$translatedAddress' failed IPv4 validation; keeping original string." }
    if ($translatedFqdn -and -not (Test-Fqdn $translatedFqdn)) { Write-Warning "TranslatedFQDN '$translatedFqdn' failed FQDN validation; keeping original string." }
    if ($translatedAddress -and $translatedFqdn) {
        if (Test-IPv4 $translatedAddress) { Write-Warning "Both translated address and FQDN supplied for rule '$($row.RuleName)'. Using address; nulling FQDN."; $translatedFqdn = $null }
        elseif (Test-Fqdn $translatedFqdn) { Write-Warning "Both supplied but address invalid; using FQDN; nulling address."; $translatedAddress = $null }
    }
    if ($DebugOutput) { Write-Host "Rule '$($row.RuleName)': Final Address='$translatedAddress' FQDN='$translatedFqdn'" -ForegroundColor Yellow }

    $translatedPortFinal = if ($null -ne $portValue) { $portValue } else { $null }

    # Build NAT rule object
    $rule = [ordered]@{
        name                  = $row.RuleName
        protocols             = @($protocols)
        source_addresses      = @($src.source_addresses)
        source_ip_groups      = @($src.source_ip_groups)
        source_fqdns          = @($src.source_fqdns)
        destination_addresses = @($dst.destination_addresses)
        destination_ip_groups = @($dst.destination_ip_groups)
        destination_fqdns     = @($dst.destination_fqdns)
        destination_ports     = @($destPorts)
        translated_address    = $translatedAddress
        translated_fqdn       = $translatedFqdn
        translated_port       = $translatedPortFinal
    }

    $collections[$collName].rules += ,$rule
}

# Finalise
$groupArray = @()
foreach ($g in $groups.Values) {
    $collArray = $g.nat_rule_collections.Values | Sort-Object priority
    foreach ($c in $collArray) {
        $c.rule = $c.rules
        $c.Remove('rules')
    }
    $g.nat_rule_collections = $collArray
    $groupArray += ,$g
}
$groupArray = $groupArray | Sort-Object priority

# HCL conversion
function ConvertTo-HCL {
    param ($value, [int]$indent = 0)
    $prefix = " " * $indent
    if ($value -is [System.Collections.IDictionary] -or $value -is [Hashtable]) {
        $items = $value.GetEnumerator() | Sort-Object Name
        $body = ($items | ForEach-Object { "$prefix  $($_.Key) = $(ConvertTo-HCL $_.Value ($indent + 2))" }) -join "`n"
        return "{`n$body`n$prefix}"
    }
    elseif ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
        if ($value.Count -eq 0) { return "[]" }
        $lines = $value | ForEach-Object { "$prefix  $(ConvertTo-HCL $_ ($indent + 2))" }
        return "[`n" + ($lines -join ",`n") + "`n$prefix]"
    }
    elseif ($value -is [string] -or $value -is [char]) {
        $escaped = ($value -replace '"','\\"')
        return '"' + $escaped + '"'
    }
    elseif ($null -eq $value) { return "null" }
    else { return $value.ToString() }
}

# --- Write out the .tfvars ---
$tfFolder = Resolve-Path "$PSScriptRoot\..\..\terraform"
$hclPath  = Join-Path $tfFolder 'nat-rules.tfvars'
$hclBody  = "nat_rule_collection_group = " + (ConvertTo-HCL @($groupArray))

Set-Content -LiteralPath $hclPath -Value $hclBody -Encoding UTF8

Write-Host "HCL tfvars file written to:" -ForegroundColor Green
Write-Host "$hclPath" -ForegroundColor Cyan