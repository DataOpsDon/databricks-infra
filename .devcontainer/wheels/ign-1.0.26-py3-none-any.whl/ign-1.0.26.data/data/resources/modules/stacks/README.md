# Stack Templates

This directory contains pre-configured infrastructure stack templates that can be applied to your projects.

## What are Stack Templates?

Stack templates are complete, ready-to-use infrastructure configurations that provide starting points for common deployment patterns. Each template includes:

- **Terraform configurations** - Complete `.tf` files with resources
- **YAML pipelines** - Azure DevOps pipeline templates
- **Azure Pipeline configuration** - Main `azure-pipelines.yml`
- **Scripts** (optional) - Helper scripts for the stack

## Using Stack Templates

### List Available Templates

```bash
ign list-stack-templates
```

This will show all available stack templates in the library.

### Apply a Template to Your Project

```bash
ign add-stack-template --stack-name example-stack
```

Or use the interactive prompt:

```bash
ign add-stack-template
```

The template will be copied to your project's `spokes/` directory, where you can customize it for your needs.

## Contributing Stack Templates

### Directory Structure

Each stack template should follow this structure:

```
modules/stacks/
└── your-stack-name/
    ├── terraform/              # Terraform configurations
    │   ├── main.tf
    │   ├── variables.tf
    │   ├── outputs.tf
    │   ├── providers.tf
    │   ├── data.tf
    │   ├── locals.tf
    │   ├── *.tfvars           # Environment-specific variables
    │   └── ...
    ├── yaml/                   # Pipeline templates
    │   ├── build.yml
    │   ├── deploy.yml
    │   └── state.yml
    ├── scripts/ (optional)     # Helper scripts
    └── azure-pipelines.yml     # Main pipeline config
```

### Creating a New Stack Template

1. **Create the directory structure**:
   ```bash
   mkdir -p modules/stacks/my-stack/terraform
   mkdir -p modules/stacks/my-stack/yaml
   ```

2. **Add Terraform files** to `terraform/`:
   - `main.tf` - Main resource definitions
   - `variables.tf` - Input variables
   - `outputs.tf` - Output values
   - `providers.tf` - Provider configurations
   - `data.tf` - Data sources
   - `locals.tf` - Local values
   - `dev.tfvars`, `tst.tfvars`, etc. - Environment variables

3. **Add YAML pipeline templates** to `yaml/`:
   - `build.yml` - Build pipeline template
   - `deploy.yml` - Deploy pipeline template
   - `state.yml` - State configuration

4. **Add main pipeline** at root:
   - `azure-pipelines.yml` - Main Azure Pipelines configuration

5. **Test the template**:
   ```bash
   # Build and install CLI
   uv build
   uv tool install --force dist/ign-*.whl
   
   # Test applying the template
   cd /tmp/test-project
   ign init
   ign add-stack-template --stack-name my-stack
   
   # Verify files were copied correctly
   ls -la spokes/my-stack/
   ```

6. **Submit a PR** with your new template

### Template Best Practices

1. **Use placeholders** for project-specific values
2. **Include comments** explaining key configurations
3. **Provide sane defaults** in tfvars files (use placeholder IDs/GUIDs)
4. **Document** any prerequisites or special setup in comments
5. **Follow naming conventions** from the utils module
6. **Keep it modular** - templates should be self-contained

### Example Stack

See `example-stack/` for a simple reference implementation.

## Available Templates

<!-- List templates here as they're added -->

- **example-stack** - Basic stack with resource group, storage, and Key Vault
- *(Add your templates here)*

## Questions?

- Check the main [CONTRIBUTING.md](../../CONTRIBUTING.md) guide
- Open an issue on GitHub
- Review existing templates for examples

