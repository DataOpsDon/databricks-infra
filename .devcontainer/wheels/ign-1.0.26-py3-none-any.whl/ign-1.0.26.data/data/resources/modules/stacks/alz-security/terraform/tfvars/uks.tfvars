# =============================================================================
# ALZ Security Stack - UK South Regional Configuration
# =============================================================================

# Regional settings
location       = "uksouth"
location_short = "uks"

# Network configuration for UK South region
vnet_address_space = "10.2.0.0/24"
dns_servers        = []

# Security-specific network configuration
# Example routes (customize based on your requirements)
# security_routes = {
#   to_hub = {
#     name           = "ToHub"
#     address_prefix = "10.0.0.0/16"
#     next_hop_type  = "VirtualNetworkGateway"
#   }
#   to_onprem = {
#     name           = "ToOnPrem"
#     address_prefix = "192.168.0.0/16"
#     next_hop_type  = "VirtualNetworkGateway"
#   }
# }