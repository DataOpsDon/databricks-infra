vnet_gateway_config = {
  express_route_remote_vnet_traffic_enabled = true
  express_route_virtual_wan_traffic_enabled = true
  vpn_active_active_enabled                 = false
  vpn_bgp_route_translation_for_nat_enabled = false
  vpn_dns_forwarding_enabled                = false
  sku                                       = "Standard"     // change this
  type                                      = "ExpressRoute" // change this
  subnet_address_prefix                     = ""             // change this
  subnet_creation_enabled                   = false
}

public_ip_config = {
  sku              = "Standard" // change this
  sku_tier         = "Regional" // change this
  creation_enabled = false
  zones            = []
}

route_table_01_routes       = {} // add routes or leave empty
route_table_internet_routes = {} // add internet routes if required
peering_names               = {} // add peering names

vnet_address_space  = "" // change this
location            = "ukwest"
location_short      = "ukw"
dns_servers         = []   // add DNS servers
deploy_vnet_gateway = true // toggle gateway deployment

// ------------------------- OPTIONAL SKELETON EXAMPLES BELOW (REMOVE IF NOT NEEDED) -------------------------
// Route table example skeleton (hybrid / appliance routing)
// Uncomment and replace placeholders to define custom routes.
/*
route_table_01_routes = {
  example_spoke = {
    name                   = "Hub-To-Example-Spoke"      // change this
    address_prefix         = "10.10.0.0/16"               // change this
    next_hop_type          = "VirtualAppliance"           // VirtualAppliance | VnetLocal | Internet | None | VirtualNetworkGateway
    next_hop_in_ip_address = "10.10.1.4"                  // change this (firewall / NVA IP)
  }
}
*/

/*
route_table_internet_routes = {
  default = {
    name           = "Firewall-To-Internet"   // change this
    address_prefix = "0.0.0.0/0"
    next_hop_type  = "Internet"
  }
}
*/

/*
peering_names = {
  management = "hub-Peering-management"      // change this
  identity   = "hub-Peering-identity"        // change this
}
*/

// Virtual machine (firewall/NVA) base configuration example
/*
virtual_machine_configuration = {
  storage_account_type = "StandardSSD_LRS"  // change if needed
  admin_username       = "vm-admin"         // change this
  enable_data_disk     = true
  sku                  = "Standard_F4s"      // change this
  os_type              = "linux"            // linux | windows
  source_image_reference = {
    publisher = "fortinet"                  // change this
    offer     = "fortinet_fortigate-vm_v5"   // change this
    sku       = "fortinet_fg-vm"             // change this
    version   = "latest"                     // or pin version
  }
}

vm_configurations = {
  fw01 = {
    name                      = "fw01"                      // change this
    zone                      = "1"                         // change this
    management_public_ip_name = "pip-hub-fw-mgmt-01"        // change this
    static_ip_addresses = {
      external   = "10.10.1.10"   // change
      internal   = "10.10.1.11"   // change
      management = "10.10.1.12"   // change
      haSync     = "10.10.1.13"   // change
    }
  }
  fw02 = {
    name                      = "fw02"                      // change this
    zone                      = "2"                         // change this
    management_public_ip_name = "pip-hub-fw-mgmt-02"        // change this
    static_ip_addresses = {
      external   = "10.10.1.14"   // change
      internal   = "10.10.1.15"   // change
      management = "10.10.1.16"   // change
      haSync     = "10.10.1.17"   // change
    }
  }
}
*/

// External Load Balancer skeleton example
/*
load_balancer_configuration = {
  external_lb = {
    name                = "lb-hub-external"                // change this
    location            = "ukwest"                         // change this
    resource_group_name = "rg-hub-networking"              // change this
    sku                 = "Standard"
    sku_tier            = "Regional"
    frontend_ip_configurations = {
      frontend_configuration_1 = {
        name                                   = "lb-hub-external-frontend" // change
        frontend_private_ip_address_allocation = "Dynamic"
        create_public_ip_address               = false
        public_ip_address_resource_id          = "" // optional existing PIP resource ID
        zones                                  = []
      }
    }
    backend_address_pools = {
      fw01 = {
        name              = "lb-hub-external-backend" // change
        tunnel_interfaces = {}
      }
      fw02 = {
        name              = "lb-hub-external-backend" // change or separate pool
        tunnel_interfaces = {}
      }
    }
    backend_address_pool_network_interfaces = {
      address1 = {
        ip_configuration_name            = "ipconfig"
        backend_address_pool_object_name = "fw01"
        network_interface_resource_id    = "" // nic resource id
      }
      address2 = {
        ip_configuration_name            = "ipconfig"
        backend_address_pool_object_name = "fw02"
        network_interface_resource_id    = "" // nic resource id
      }
    }
    lb_nat_rules = {
      nat_rule_1 = {
        name                             = "lb-external-nat01" // change
        protocol                         = "Tcp"
        frontend_port_start              = 2222
        frontend_port_end                = 2223
        frontend_ip_configuration_name   = "lb-hub-external-frontend"
        backend_address_pool_resource_id = "" // backend pool resource id
        backend_address_pool_object_name = "fw01"
        backend_port                     = 2222
      }
    }
    lb_rules = {
      lb_rule_1 = {
        name                              = "lb-external-rule01" // change
        frontend_ip_configuration_name    = "lb-hub-external-frontend"
        backend_address_pool_object_names = ["fw01"]
        protocol                          = "Tcp"
        frontend_port                     = 80
        backend_port                      = 80
        probe_object_name                 = "probe1"
        idle_timeout_in_minutes           = 5
        enable_tcp_reset                  = false
        probe_resource_id                 = "" // probe resource id
        enable_floating_ip                = true
      }
    }
    lb_probes = {
      probe1 = {
        name                = "hp-lb-hub-external" // change
        protocol            = "Tcp"
        port                = 8008
        interval_in_seconds = 15
      }
    }
  }
}
*/

// Internal Load Balancer skeleton example
/*
load_balancer_internal_configuration = {
  internal_lb = {
    name                = "lb-hub-internal"              // change this
    location            = "ukwest"                       // change this
    resource_group_name = "rg-hub-networking"            // change this
    sku                 = "Standard"
    sku_tier            = "Regional"
    frontend_ip_configurations = {
      frontend_configuration_1 = {
        name                                   = "lb-hub-internal-frontend" // change
        frontend_private_ip_address_version    = "IPv4"
        frontend_private_ip_address_allocation = "Dynamic"
        create_public_ip_address               = false
        frontend_private_ip_subnet_resource_id = "" // subnet resource id
        zones                                  = []
      }
    }
    backend_address_pools = {
      fw01 = {
        name              = "lb-hub-internal-backend" // change
        tunnel_interfaces = {}
      }
      fw02 = {
        name              = "lb-hub-internal-backend" // change or separate pool
        tunnel_interfaces = {}
      }
    }
    backend_address_pool_network_interfaces = {
      address1 = {
        ip_configuration_name            = "ipconfig"
        backend_address_pool_object_name = "fw01"
        network_interface_resource_id    = "" // nic resource id
      }
    }
    lb_rules = {
      lb_rule_1 = {
        name                              = "lb-internal-rule01" // change
        frontend_ip_configuration_name    = "lb-hub-internal-frontend"
        backend_address_pool_object_names = ["fw01"]
        protocol                          = "All"
        frontend_port                     = 0
        backend_port                      = 0
        probe_object_name                 = "probe1"
        idle_timeout_in_minutes           = 5
        enable_tcp_reset                  = false
        probe_resource_id                 = "" // probe resource id
        enable_floating_ip                = true
      }
    }
    lb_probes = {
      probe1 = {
        name                = "hp-lb-hub-internal" // change
        protocol            = "Tcp"
        port                = 8008
        interval_in_seconds = 15
      }
    }
  }
}
*/
// ----------------------- END SKELETON EXAMPLES -----------------------