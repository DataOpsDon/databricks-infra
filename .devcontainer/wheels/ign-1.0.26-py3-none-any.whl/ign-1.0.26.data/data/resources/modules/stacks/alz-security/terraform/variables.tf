# =============================================================================
# ALZ Security Stack - Variable Definitions
# =============================================================================
# This file defines all variables for the Azure Landing Zone security stack.
# The security stack provides centralized security operations including:
# - Microsoft Sentinel SIEM with comprehensive data connectors
# - Log Analytics workspace for security monitoring
# - Security policies and compliance monitoring
# - Key Vault for security secrets and certificates
# - Storage accounts for security logs and evidence
# - Network security monitoring and threat detection
# =============================================================================

# -----------------------------------------------------------------------------
# Required Variables
# -----------------------------------------------------------------------------

variable "subscription_id" {
  description = "The Azure subscription ID for the security subscription."
  type        = string
}

variable "location" {
  description = "The primary Azure region for security resources deployment."
  type        = string
}

variable "location_short" {
  description = "Short code for the Azure region (e.g., 'uks' for UK South), used in resource naming."
  type        = string
}

variable "tags" {
  description = "Common tags to apply to all security resources for governance and cost management."
  type        = map(string)
}

variable "enable_telemetry" {
  description = "Enable telemetry collection for Azure modules to help Microsoft improve services."
  type        = bool
  default     = true
}

# -----------------------------------------------------------------------------
# Security Configuration Variables
# -----------------------------------------------------------------------------

variable "sentinel_pricing_tier" {
  description = "Pricing tier for Microsoft Sentinel (PerGB2018 or CapacityReservation)."
  type        = string
  default     = "PerGB2018"
}

variable "log_analytics_retention_days" {
  description = "Number of days to retain security logs in Log Analytics workspace (30-730)."
  type        = number
  default     = 90
}

variable "log_analytics_daily_quota_gb" {
  description = "Daily ingestion quota for Log Analytics workspace in GB (-1 for unlimited)."
  type        = number
  default     = -1
}

variable "key_vault_sku" {
  description = "SKU for the security Key Vault (standard or premium)."
  type        = string
  default     = "premium"
}

variable "storage_account_tier" {
  description = "Performance tier for security storage accounts (Standard or Premium)."
  type        = string
  default     = "Standard"
}

variable "storage_replication_type" {
  description = "Replication type for security storage accounts (LRS, GRS, RAGRS, ZRS, GZRS, RAGZRS)."
  type        = string
  default     = "GRS"
}

# -----------------------------------------------------------------------------
# Data Connector Configuration
# -----------------------------------------------------------------------------

variable "enable_azure_firewall_connector" {
  description = "Enable Azure Firewall data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_key_vault_connector" {
  description = "Enable Azure Key Vault data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_storage_connector" {
  description = "Enable Azure Storage data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_nsg_connector" {
  description = "Enable Network Security Group data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_virtual_network_connector" {
  description = "Enable Virtual Network data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_aks_connector" {
  description = "Enable Azure Kubernetes Service data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_sql_connector" {
  description = "Enable Azure SQL Database data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_application_gateway_connector" {
  description = "Enable Application Gateway data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_load_balancer_connector" {
  description = "Enable Load Balancer data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_waf_connector" {
  description = "Enable Web Application Firewall data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_logic_apps_connector" {
  description = "Enable Logic Apps data connector for Sentinel."
  type        = bool
  default     = true
}

variable "enable_service_fabric_connector" {
  description = "Enable Service Fabric data connector for Sentinel."
  type        = bool
  default     = true
}

# -----------------------------------------------------------------------------
# Network Configuration
# -----------------------------------------------------------------------------

variable "vnet_address_space" {
  description = "Address space for the security virtual network (CIDR notation)."
  type        = string
  default     = "10.2.0.0/24"
}

variable "dns_servers" {
  description = "List of DNS server IP addresses for the security virtual network."
  type        = list(string)
  default     = []
}

# -----------------------------------------------------------------------------
# Connectivity & Integration
# -----------------------------------------------------------------------------

variable "enable_hub_peering" {
  description = "Enable virtual network peering to the hub network for centralized connectivity."
  type        = bool
  default     = false
}

variable "hub_virtual_network_id" {
  description = "Resource ID of the hub virtual network for peering (required if enable_hub_peering is true)."
  type        = string
  default     = ""
}

variable "use_hub_gateway" {
  description = "Use the hub network gateway for hybrid connectivity (requires hub peering)."
  type        = bool
  default     = false
}

# -----------------------------------------------------------------------------
# Remote State Configuration
# -----------------------------------------------------------------------------

variable "state_sub_id" {
  description = "Subscription ID where Terraform state storage account is located."
  type        = string
}

variable "management_state_key" {
  description = "State key for the management stack to retrieve shared resources."
  type        = string
  default     = "management.tfstate"
}

variable "connectivity_state_key" {
  description = "State key for the connectivity stack to retrieve hub network information."
  type        = string
  default     = "connectivity.tfstate"
}

# -----------------------------------------------------------------------------
# Feature Toggles
# -----------------------------------------------------------------------------

variable "enable_defender_for_cloud" {
  description = "Enable Microsoft Defender for Cloud enhanced security features."
  type        = bool
  default     = true
}

variable "enable_security_center_auto_provisioning" {
  description = "Enable automatic provisioning of security agents on VMs."
  type        = bool
  default     = true
}

variable "enable_just_in_time_access" {
  description = "Enable Just-In-Time VM access for enhanced security."
  type        = bool
  default     = true
}

variable "enable_adaptive_network_hardening" {
  description = "Enable adaptive network hardening recommendations."
  type        = bool
  default     = true
}

variable "enable_automation_account" {
  description = "Enable Azure Automation Account for security operations and incident response."
  type        = bool
  default     = true
}

# -----------------------------------------------------------------------------
# Additional Data Connector Variables
# -----------------------------------------------------------------------------

variable "enable_aws_connector" {
  description = "Enable AWS CloudTrail data connector for Sentinel."
  type        = bool
  default     = false
}

variable "aws_role_arn" {
  description = "AWS IAM role ARN for CloudTrail data connector (required if enable_aws_connector is true)."
  type        = string
  default     = ""
}

variable "enable_firewall_connector" {
  description = "Enable Azure Firewall data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_aks_connector" {
  description = "Enable Azure Kubernetes Service data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_sql_connector" {
  description = "Enable Azure SQL Database data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_appgw_connector" {
  description = "Enable Application Gateway data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_waf_connector" {
  description = "Enable Web Application Firewall data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_lb_connector" {
  description = "Enable Load Balancer data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_logicapps_connector" {
  description = "Enable Logic Apps data connector for Sentinel."
  type        = bool
  default     = false
}

variable "enable_servicefabric_connector" {
  description = "Enable Service Fabric data connector for Sentinel."
  type        = bool
  default     = false
}

# -----------------------------------------------------------------------------
# Network Configuration Variables
# -----------------------------------------------------------------------------

variable "private_endpoint_routes" {
  description = "Custom routes for private endpoint subnet."
  type = map(object({
    name                   = string
    address_prefix         = string
    next_hop_type          = string
    next_hop_in_ip_address = optional(string)
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# Hub Connectivity Variables
# -----------------------------------------------------------------------------

variable "enable_hub_peering" {
  description = "Enable peering to hub virtual network."
  type        = bool
  default     = false
}

variable "hub_virtual_network_id" {
  description = "Resource ID of the hub virtual network for peering."
  type        = string
  default     = ""
}

variable "use_hub_gateway" {
  description = "Use hub virtual network gateway for transit."
  type        = bool
  default     = false
}

# -----------------------------------------------------------------------------
# Firewall Diagnostics Variables
# -----------------------------------------------------------------------------

variable "enable_firewall_diagnostics" {
  description = "Enable diagnostic settings for Azure Firewall."
  type        = bool
  default     = false
}

variable "firewall_resource_id" {
  description = "Resource ID of the Azure Firewall for diagnostics."
  type        = string
  default     = ""
}