# ---------------------------------------------------------------------------------------------------------------------
# ALZ Identity Stack Outputs
# Outputs from the identity infrastructure deployment for use by other stacks and teams
# ---------------------------------------------------------------------------------------------------------------------

# Resource Group Outputs
output "resource_group_name" {
  description = "The name of the identity resource group"
  value       = module.resource_group.name
}

output "resource_group_id" {
  description = "The resource ID of the identity resource group"
  value       = module.resource_group.resource_id
}

output "resource_group_location" {
  description = "The location of the identity resource group"
  value       = module.resource_group.resource.location
}

# Virtual Network Outputs
output "identity_virtual_network_name" {
  description = "The name of the identity virtual network"
  value       = module.identity_virtual_network.name
}

output "identity_virtual_network_id" {
  description = "The resource ID of the identity virtual network"
  value       = module.identity_virtual_network.resource_id
}

output "identity_virtual_network_address_space" {
  description = "The address space of the identity virtual network"
  value       = module.identity_virtual_network.virtual_network_address_space
}

# DNS Configuration Outputs
output "primary_dns_server_ip" {
  description = "IP address of the primary domain controller (DNS server)"
  value       = local.dc_config.primary_dc_ip
}

output "secondary_dns_server_ip" {
  description = "IP address of the secondary domain controller (DNS server)"
  value       = local.dc_config.secondary_dc_ip
}

output "dns_servers" {
  description = "List of DNS server IP addresses for spoke VNets"
  value       = [local.dc_config.primary_dc_ip, local.dc_config.secondary_dc_ip]
}

# Active Directory Configuration Outputs
output "domain_name" {
  description = "The Active Directory domain name"
  value       = local.ad_config.domain_name
}

output "domain_netbios_name" {
  description = "The NetBIOS name of the domain"
  value       = local.ad_config.domain_netbios_name
}

output "forest_mode" {
  description = "The Active Directory forest functional level"
  value       = local.ad_config.forest_mode
}

output "domain_mode" {
  description = "The Active Directory domain functional level"
  value       = local.ad_config.domain_mode
}

# Subnet Outputs
output "subnet_ids" {
  description = "Map of subnet names to their resource IDs"
  value = {
    domain_controllers = module.identity_virtual_network.subnets["domain_controllers"].resource_id
    management         = module.identity_virtual_network.subnets["management"].resource_id
    private_endpoints  = module.identity_virtual_network.subnets["private_endpoints"].resource_id
  }
}

output "subnet_address_prefixes" {
  description = "Map of subnet names to their address prefixes"
  value = {
    domain_controllers = local.subnet_ranges.domain_controllers
    management         = local.subnet_ranges.management
    private_endpoints  = local.subnet_ranges.private_endpoints
  }
}

# Security Outputs
output "key_vault_id" {
  description = "The resource ID of the Key Vault"
  value       = module.key_vault.resource_id
}

output "key_vault_name" {
  description = "The name of the Key Vault"
  value       = module.key_vault.name
}

output "key_vault_uri" {
  description = "The URI of the Key Vault"
  value       = module.key_vault.vault_uri
}

# Backup and Recovery Outputs
output "recovery_services_vault_id" {
  description = "The resource ID of the Recovery Services Vault"
  value       = module.recovery_services_vault.resource_id
}

output "recovery_services_vault_name" {
  description = "The name of the Recovery Services Vault"
  value       = module.recovery_services_vault.name
}

# Storage Outputs
output "storage_account_id" {
  description = "The resource ID of the identity storage account"
  value       = module.storage_account.resource_id
}

output "storage_account_name" {
  description = "The name of the identity storage account"
  value       = module.storage_account.name
}

# Log Analytics Outputs
output "log_analytics_workspace_id" {
  description = "The resource ID of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.resource_id
}

output "log_analytics_workspace_name" {
  description = "The name of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.name
}

output "log_analytics_workspace_workspace_id" {
  description = "The workspace ID of the Log Analytics Workspace"
  value       = module.log_analytics_workspace.workspace_id
}

# Network Security Group Outputs
output "nsg_ids" {
  description = "Map of NSG names to their resource IDs"
  value = {
    domain_controllers = module.domain_controllers_nsg.resource_id
    management         = module.management_nsg.resource_id
    private_endpoints  = module.private_endpoints_nsg.resource_id
  }
}

# Application Security Group Outputs
output "asg_ids" {
  description = "Map of ASG names to their resource IDs"
  value = {
    domain_controllers = azurerm_application_security_group.domain_controllers.id
    management_servers = azurerm_application_security_group.management_servers.id
    monitoring_agents  = azurerm_application_security_group.monitoring_agents.id
  }
}

# Route Table Outputs
output "route_table_ids" {
  description = "Map of route table names to their resource IDs"
  value = {
    domain_controllers = module.route_table_domain_controllers.resource_id
    management         = module.route_table_management.resource_id
    private_endpoints  = module.route_table_private_endpoints.resource_id
  }
}