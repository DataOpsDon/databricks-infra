// ---------------------------------------------------------------------------------------------------------------------
// Azure Landing Zone (ALZ) - Core Pattern Deployment
// This Terraform file deploys the ALZ pattern using the Azure Verified Modules (AVM) "ptn-alz" module.
// It also applies organisation-specific AMBA policy integration (policy parameter values currently empty).
//
// Notes:
// - Naming is centralised via the `naming` module to ensure consistent resource names/tag components across stacks.
// - The ALZ pattern module handles creation of core platform components & policy assignments per subscription placement.
// - `subscription_placement` comes from local configuration (see accompanying locals.tf) to map workloads -> subscriptions.
// ---------------------------------------------------------------------------------------------------------------------

// Module: naming
// Purpose: Provides consistent naming primitives (project, LZ code, suffix, short code) consumed by other modules.
// Notes: Values are currently static for this ALZ stack; adjust if introducing environment-driven variability.
module "naming" {
  source   = "../../../templates/utils"
  location = var.location
  project  = "edp"
  lz       = "h1s01"
  suffix   = "amba"
  lz_short = "connect"
}

// Module: avm-ptn-alz
// Purpose: Deploys the ALZ pattern (management, connectivity, identity constructs & associated policies).
// Notes:
//   - Extend `policy_default_values` if custom parameterisation is required (e.g., allowed locations, tag policies).
//   - Ensure data.azurerm_client_config.main is declared in a separate data block (usually in providers/data.tf).
module "avm-ptn-alz" {
  source                 = "Azure/avm-ptn-alz/azurerm"
  version                = "0.18.0"
  parent_resource_id     = data.azurerm_client_config.main.tenant_id
  location               = var.location
  architecture_name      = "alz"
  subscription_placement = local.subscription_placement
  policy_default_values  = {}
}

