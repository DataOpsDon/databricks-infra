# ---------------------------------------------------------------------------------------------------------------------
# UK West Regional Configuration for ALZ Identity Stack
# ---------------------------------------------------------------------------------------------------------------------

location           = "ukwest"
location_short     = "ukw"
vnet_address_space = "10.0.0.0/24"
dns_servers        = []

# Optional: Hub VNet resource ID for peering (update with your hub VNet)
# hub_vnet_resource_id = "/subscriptions/your-sub-id/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworks/vnet-hub"

# Active Directory Configuration for UK West
domain_name         = "contoso.local"
domain_netbios_name = "CONTOSO"

# Custom routes for identity infrastructure (add specific routes if needed)
domain_controller_routes = {}
management_routes        = {}
private_endpoint_routes  = {}

# Uncomment and modify these examples if you need custom routing for identity:

# Example: Route on-premises traffic through hub firewall for hybrid AD
/*
domain_controller_routes = {
  to_on_premises_dc = {
    name                   = "ToOnPremisesDC"
    address_prefix         = "192.168.0.0/16"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.1.1.4"  # Hub firewall IP
  }
}
*/

# Example: Force management traffic through security appliance
/*
management_routes = {
  internet_via_hub = {
    name                   = "InternetViaHub"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.1.1.4"  # Hub firewall IP
  }
}
*/

# Example: Direct routing for private endpoints (no inspection needed)
/*
private_endpoint_routes = {
  azure_services = {
    name           = "AzureServices"
    address_prefix = "168.63.129.16/32"
    next_hop_type  = "Internet"
  }
}
*/