network_rule_collection_group = [
  {
    name     = "DefaultNetworkRuleCollectionGroup"
    priority = 200
    # network_rule_collections = []
  }
]
