# Azure Function App Module
# Description: Azure Function App for serverless compute

module "{{resource_name}}" {
  source                   = "Azure/avm-res-web-site/azurerm"
  version                  = "0.21.0"
  name                     = "func-${var.location_short}-${var.project}-{{resource_name}}-${var.environment}"
  location                 = module.resource_group.location
  parent_id                = module.resource_group.resource_id
  service_plan_resource_id = module.app_service_plan.resource_id

  # Function App specific configuration
  kind = "FunctionApp"

  # Add application settings, storage connection, and other configuration as needed
}

