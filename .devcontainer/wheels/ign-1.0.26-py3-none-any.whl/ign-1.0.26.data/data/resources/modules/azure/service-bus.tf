# Azure Service Bus Module
# Description: Azure Event Hubs high-throughput data streaming platform

module "{{resource_name}}" {
  source  = "Azure/avm-res-servicebus-namespace/azurerm"
  version = "0.4.0"
  # insert the 3 required variables here
  name                = "sb-${var.location_short}-${var.project}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  ## Additional optional settings
  tags             = module.resource_group.tags
  sku              = "Standard"
  enable_telemetry = var.enable_telemetry


  # Azure Service Bus Queue
  queues = {
    main = {
      name = "sbq-${var.project}-${var.environment}"

      max_delivery_count                      = 10
      dead_lettering_on_message_expiration    = true
      requires_duplicate_detection            = true
      duplicate_detection_history_time_window = "PT10M"
      lock_duration                           = "PT1M"
      default_message_ttl                     = "P14D"
    }
  }
}