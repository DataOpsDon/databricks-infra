# Azure User Assigned Managed Identity Module
# Description: Managed Identity for secure authentication to Azure resources

module "{{resource_name}}" {
  source  = "Azure/avm-res-managedidentity-userassignedidentity/azurerm"
  version = "0.3.4"
  # insert the 3 required variables here
}