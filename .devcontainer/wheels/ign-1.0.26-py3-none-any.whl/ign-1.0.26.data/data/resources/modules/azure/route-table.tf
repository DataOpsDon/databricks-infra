# Azure Route Table Module
# Description: Route Table defining network routes within a virtual network

module "{{resource_name}}" {
  source              = "Azure/avm-res-network-routetable/azurerm"
  version             = "0.4.1"
  name                = "${module.naming.name.route_table}{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
}