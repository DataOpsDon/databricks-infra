# Azure API Management Module
# Description: Azure API Management service for publishing, securing, and managing APIs

module "{{resource_name}}" {
  source  = "Azure/avm-res-apimanagement-service/azurerm"
  version = "0.0.6"

  location            = module.resource_group.location
  resource_group_name = module.resource_group.name
  name                = "apim-${var.location_short}-${var.project}-${var.environment}"
  publisher_email     = var.publisher_email
  enable_telemetry    = var.enable_telemetry
  managed_identities = {
    system_assigned = true
  }
  publisher_name = "Apim Example Publisher"
  sku_name       = "Premium_3"
  tags           = var.tags
  zones          = ["1", "2", "3"] # For compliance with WAF
}