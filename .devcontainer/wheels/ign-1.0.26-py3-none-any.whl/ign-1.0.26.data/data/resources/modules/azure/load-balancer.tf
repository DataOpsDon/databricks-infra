# Azure Load Balancer Module
# Description: Azure Load Balancer for distributing network traffic

module "{{resource_name}}" {
  source  = "Azure/avm-res-network-loadbalancer/azurerm"
  version = "0.4.1"
  # insert the 4 required variables here
}


