# Azure Log Analytics Workspace Module
# Description: Log Analytics workspace for querying and analyzing logs

module "{{resource_name}}" {
  source  = "Azure/avm-res-operationalinsights-workspace/azurerm"
  version = "0.4.2"
  # insert the 3 required variables here
}