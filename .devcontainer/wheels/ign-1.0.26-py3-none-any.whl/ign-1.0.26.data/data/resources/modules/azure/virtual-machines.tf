
# Azure Virtual Machine Module
# Description: Azure Windows Virtual Machine with managed disks, network interface, and optional AVD session host extensions

module "{{resource_name}}" {
  source           = "Azure/avm-res-compute-virtualmachine/azurerm"
  version          = "0.20.0"
  for_each         = var.vm_configurations
  name             = each.value.name
  enable_telemetry = var.enable_telemetry
  managed_identities = {
    system_assigned = true
  }
  resource_group_name             = each.value.resource_group_name
  location                        = module.resource_group.resource.location
  os_type                         = var.virtual_machine_configuration.os_type
  admin_username                  = each.value.username
  encryption_at_host_enabled      = false
  disable_password_authentication = false
  admin_password                  = random_password.vm_password.result
  license_type                    = "Windows_Server"
  zone                            = var.location == "uksouth" ? each.value.zone : null
  sku_size                        = var.virtual_machine_configuration.sku
  source_image_reference          = var.virtual_machine_configuration.source_image_reference
  network_interfaces = {
    main = {
      name = "nic-01-${each.value.name}"
      ip_configurations = {
        ipconfig1 = {
          name                           = "ipconfig"
          private_ip_subnet_resource_id  = var.subnet_id
          private_ip_address_allocation  = lookup(each.value.static_ip_addresses, "main", null) != null ? "Static" : "Dynamic"
          private_ip_address             = lookup(each.value.static_ip_addresses, "main", null)
          ip_forwarding_enabled          = true
          accelerated_networking_enabled = true
        }
      }
      ip_forwarding_enabled          = false
      accelerated_networking_enabled = true
      resource_group_name            = lower(each.value.resource_group_name)
    }
  }
  os_disk = {
    name                 = "os-disk-01-${each.value.name}"
    storage_account_type = var.virtual_machine_configuration.storage_account_type
    caching              = "ReadWrite"

  }
  data_disk_managed_disks = {
    datadisk1 = {
      name                          = "data-disk-01-${each.value.name}"
      disk_attachment_create_option = "Empty"
      disk_size_gb                  = 64
      lun                           = 0
      storage_account_type          = var.virtual_machine_configuration.storage_account_type
      caching                       = "None"
    }
  }
  tags = merge(var.tags, {
    "ServiceName" = "Active Directory"
  })
  boot_diagnostics = true

  ###### Add extension for AVD with Entra connectivity ######
  #extensions = {
  #  # Virtual Machine Extension for AAD Join
  #  aad_join = {
  #    name                 = "aadJoin${each.value.name}-${count.index + 2}"
  #    publisher            = "Microsoft.Azure.ActiveDirectory"
  #    type                 = "AADLoginForWindows"
  #    type_handler_version = "2.0"
  #    #virtual_machine_id          = azurerm_windows_virtual_machine.this[count.index].id
  #    auto_upgrade_minor_version  = true
  #    tags                        = var.tags[terraform.workspace]
  #    automatic_upgrade_enabled   = false
  #    failure_suppression_enabled = false
  #    provision_after_extensions  = []
  #    settings = jsonencode({
  #      mdmId = "0000000a-0000-0000-c000-000000000000"
  #    })
  #  }
  #  # Virtual Machine Extension for AVD Agent
  #  avd_agent = {
  #    name                 = "${each.value.name}-${count.index + 2}-avd_dsc"
  #    publisher            = "Microsoft.Powershell"
  #    type                 = "DSC"
  #    type_handler_version = "2.73"
  #    #virtual_machine_id         = azurerm_windows_virtual_machine.this[count.index].id
  #    auto_upgrade_minor_version = true
  #    protected_settings = jsonencode(
  #      {
  #        properties : {
  #          registrationInfoToken = "${module.avm_res_desktopvirtualization_hostpool.registrationinfo_token}"
  #        }
  #      }
  #    )
  #    settings = jsonencode(
  #      {
  #        modulesUrl            = "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/Configuration_1.0.02714.342.zip"
  #        configurationFunction = "Configuration.ps1\\AddSessionHost"
  #        properties : {
  #          HostPoolName = "${module.avm_res_desktopvirtualization_hostpool.resource.name}"
  #        }
  #      }
  #    )
  #  }
  #}
  ############ End of extension for AVD #################
}


variable "vm_configurations" {
  description = "Configurations for firewall VMs"
  type = map(object({
    name                                 = string
    zone                                 = optional(string, null)
    static_ip_addresses                  = map(string)
    resource_group_name                  = string
    username                             = string
    availability_set_name                = optional(string, null)
    availability_set_resource_group_name = optional(string, null)
  }))
  default = {}
}

variable "virtual_machine_configuration" {
  description = "Configuration for virtual machines in the hub network"
  type = object({
    sku                  = string
    os_type              = string
    admin_username       = string
    storage_account_type = string
    enable_data_disk     = optional(bool, false)
    data_disk_size_gb    = optional(number, 128)
    source_image_reference = object({
      publisher = string
      offer     = string
      sku       = string
      version   = string
    })
  })
  default = {
    sku                  = "Standard_D2s_v3"
    os_type              = "Windows"
    admin_username       = "adminuser"
    storage_account_type = "Premium_LRS"
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-azure-edition-core"
      version   = "latest"
    }
  }
}

resource "random_password" "vm_password" {
  length           = 16
  min_lower        = 2
  min_upper        = 2
  min_numeric      = 2
  special          = true
  override_special = "!@#*[]"
}

variable "subnet_id" {
  type        = string
  description = "The Resource Id of the subnet that the VM will be deployed into"
}