# Azure Storage Account Module
# Description: Azure Storage Account for blob, file, queue, and table storage

module "{{resource_name}}" {
  source                   = "Azure/avm-res-storage-storageaccount/azurerm"
  version                  = "0.6.5"
  name                     = var.storage_account_name
  location                 = module.resource_group.resource.location
  resource_group_name      = module.resource_group.name
  account_replication_type = var.storage_sku

}



variable "storage_account_name" {
  type        = string
  description = "The resource name of the Virtual Network"
}


variable "storage_sku" {
  type        = string
  description = "The resource name of the Virtual Network"
}
