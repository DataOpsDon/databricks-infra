# Azure Monitor Activity Log Alert
# Description: Manages an Activity Log Alert within Azure Monitor
# Note: Temporary raw Terraform until AVM module is available

resource "azurerm_monitor_activity_log_alert" "{{resource_name}}" {
  name                = module.naming.name.activity_log_alert
  resource_group_name = module.resource_group.name
  location            = module.resource_group.location

  # Activity Log scope(s) monitored by this rule.
  scopes = [
    module.resource_group.id
  ]

  description = "Describe the activity/event monitored by this alert."
  enabled     = true

  criteria {
    # Category is required.
    #
    # Common values include:
    # Administrative
    # Autoscale
    # Policy
    # Recommendation
    # ResourceHealth
    # Security
    # ServiceHealth
    category = "Administrative"

    # Optional filters.
    operation_name = "Microsoft.Storage/storageAccounts/write"

    # resource_provider = "Microsoft.Storage"
    # resource_type     = "Microsoft.Storage/storageAccounts"
    # resource_group    = module.resource_group.name
    # resource_id       = azurerm_storage_account.to_monitor.id
    # caller            = "..."
    # level             = "Informational"
    # status            = "Succeeded"
  }

  action {
    action_group_id = module.action_group.id

    # Optional custom properties supplied to webhook receivers.
    # webhook_properties = {
    #   environment = var.environment
    # }
  }

  tags = var.tags
}