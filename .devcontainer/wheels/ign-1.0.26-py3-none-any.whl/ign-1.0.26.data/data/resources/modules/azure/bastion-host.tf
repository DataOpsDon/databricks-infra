# Azure Bastion Host Module
# Description: Azure Bastion Host for secure RDP/SSH connectivity to VMs

module "{{resource_name}}" {
  source              = "Azure/avm-res-network-bastionhost/azurerm"
  version             = "0.8.1"
  name                = "${module.naming.name.bastion_host}{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name

  # Bastion Host configuration
  sku                = "Standard"
  copy_paste_enabled = true
  file_copy_enabled  = true

  # Virtual network and subnet configuration
  virtual_network_id = "{{virtual_network_id}}"

  # Public IP configuration
  public_ip = {
    name              = "${module.naming.name.public_ip}bastion{{resource_name}}"
    allocation_method = "Static"
    sku               = "Standard"
  }

  # Add diagnostic settings as needed
  # diagnostic_settings = {
  #   to_log_analytics = {
  #     name                  = "diagnostic-setting"
  #     log_analytics_destination_type = "Dedicated"
  #   }
  # }
}