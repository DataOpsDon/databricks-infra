# Azure DNS Resolver Module
# Description: Azure DNS Resolver for hybrid name resolution

module "{{resource_name}}" {
  source  = "Azure/avm-res-network-dnsresolver/azurerm"
  version = "0.8.0"
  #insert the 4 required variables here
}