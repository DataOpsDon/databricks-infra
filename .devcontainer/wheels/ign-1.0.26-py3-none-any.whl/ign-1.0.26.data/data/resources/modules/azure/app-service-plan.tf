# Azure App Service Plan Module
# Description: Azure App Service Plan (server farm) for hosting web apps and function apps

module "{{resource_name}}" {
  source  = "Azure/avm-res-web-serverfarm/azurerm"
  version = "2.0.2"

  location               = module.resource_group.location
  name                   = "${module.naming.name.app_service_plan}-{{resource_name}}"
  os_type                = "Linux"
  parent_id              = module.resource_group.resource_id
  enable_telemetry       = var.enable_telemetry
  tags                   = var.tags
  sku_name               = "P1v2"
  zone_balancing_enabled = true # If deploying to the UK west, this needs to be set to false
  worker_count           = 3    # If deploying to the UK west, this needs to be set to 1
}