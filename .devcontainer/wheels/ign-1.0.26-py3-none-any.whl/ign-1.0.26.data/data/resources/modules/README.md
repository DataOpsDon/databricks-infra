# Terraform Modules Library

## 🎯 Purpose

This directory contains **Terraform modules** (`.tf` files) that can be added to infrastructure stacks. 

**For Contributors:** Add new modules by simply writing standard Terraform `.tf` files here - no template syntax needed!

> 📐 **Read [MODULE_STANDARD.md](MODULE_STANDARD.md) first.** It defines the
> required shape of every file in `modules/azure/` and is enforced automatically
> by pre-commit and CI. In VS Code, type `avm-module` + Tab to scaffold a
> compliant module.

## 🚀 Quick Start for Contributors

### Adding a New Module (3 Easy Steps!)

1. **Create a `.tf` file** in `modules/azure/`:
   ```bash
   # Example: Add Azure Container Registry
   touch modules/azure/container-registry.tf
   ```

2. **Write standard Terraform code** using `{{resource_name}}` placeholder:
   ```hcl
   # Azure Container Registry Module
   # Contributor: Your Name
   # Description: Azure Container Registry for Docker images

   module "{{resource_name}}" {
     source              = "Azure/avm-res-containerregistry-registry/azurerm"
     version             = "0.3.0"
     name                = "acr${var.location_short}${var.project}{{resource_name}}"
     location            = module.resource_group.resource.location
     resource_group_name = module.resource_group.name
     sku                 = "Premium"
     tags                = var.tags
   }
   ```

3. **Test it**:
   ```bash
   # List available modules (yours should appear!)
   ign list-modules
   
   # Use it in a stack
   ign add-resource \
     --stack-name my-stack \
     --resource-type container-registry \
     --resource-name myregistry
   ```

That's it! The CLI automatically discovers your HCL file. ✨

## 📝 Module Format

### Required Structure

```hcl
# <Module Title>
# Contributor: <Your Name> (optional but appreciated)
# Description: <Short description for list-modules command>

module "{{resource_name}}" {
  # Your Terraform configuration
  # Use {{resource_name}} anywhere you need the resource name
}
```

### Available Placeholders

| Placeholder | Description | Example Use |
|-------------|-------------|-------------|
| `{{resource_name}}` | The name provided by the user | `name = "acr-{{resource_name}}"` |

### Example Module

```hcl
# Azure Cosmos DB Module
# Contributor: Jane Doe
# Description: Azure Cosmos DB for globally distributed databases

module "{{resource_name}}" {
  source              = "Azure/avm-res-documentdb-databaseaccount/azurerm"
  version             = "0.2.0"
  name                = "cosmos-${var.location_short}-${var.project}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  offer_type          = "Standard"
  kind                = "GlobalDocumentDB"
  
  consistency_policy = {
    consistency_level = "Session"
  }
  
  geo_locations = [
    {
      location          = var.location
      failover_priority = 0
    }
  ]
  
  tags = var.tags
}
```

## 🗂️ Directory Structure

```
modules/
├── azure/              # Azure modules
│   ├── storage.tf
│   ├── keyvault.tf
│   ├── databricks.tf
│   ├── sql-database.tf
│   ├── app-service.tf
│   ├── function-app.tf
│   └── <your-new-module>.tf
├── aws/                # AWS modules (future)
├── gcp/                # GCP modules (future)
└── README.md           # This file
```

## ✅ Module Guidelines

### Do's

✅ **Write clean, standard HCL**
```hcl
module "{{resource_name}}" {
  source   = "..."
  version  = "0.1.0"  # Always pin versions
  name     = "..."
}
```

✅ **Use Azure Verified Modules (AVM)** when available
```hcl
source = "Azure/avm-res-<resource>/azurerm"
```

✅ **Include helpful comments**
```hcl
# Network configuration
public_network_access_enabled = false  # Secure by default

# Add your IP for dev access:
# ip_rules = ["YOUR_IP_HERE"]
```

✅ **Use existing variables** (`var.location`, `var.tags`, `var.environment`, etc.)

✅ **Reference existing modules** (`module.resource_group.name`, `module.naming.name.*`)

✅ **Add a description** so it appears in `list-modules`

### Don'ts

❌ **Don't use template syntax** (`.template` files)
```hcl
# ❌ BAD - template syntax
name = "{resource_name}"

# ✅ GOOD - HCL placeholder
name = "{{resource_name}}"
```

❌ **Don't hardcode values**
```hcl
# ❌ BAD
location = "uksouth"

# ✅ GOOD
location = var.location
```

❌ **Don't skip version pinning**
```hcl
# ❌ BAD
version = "latest"

# ✅ GOOD
version = "0.3.2"
```

## 🧪 Testing Your Module

1. **List modules** to verify discovery:
   ```bash
   ign list-modules
   ```

2. **Create a test stack**:
   ```bash
   ign add-stack --stack-name test-stack
   ```

3. **Add your module**:
   ```bash
   ign add-resource \
     --stack-name test-stack \
     --resource-type your-module-name \
     --resource-name test
   ```

4. **Verify the generated code**:
   ```bash
   cat spokes/test-stack/terraform/main.tf
   ```

5. **Run Terraform validate**:
   ```bash
   cd spokes/test-stack/terraform
   terraform init -backend=false
   terraform validate
   ```

## 📚 Examples

### Example 1: Simple Module (Azure Service Bus)

```hcl
# Azure Service Bus Module
# Contributor: DevOps Team
# Description: Azure Service Bus for messaging

module "{{resource_name}}" {
  source              = "Azure/avm-res-servicebus-namespace/azurerm"
  version             = "0.2.0"
  name                = "sb-${var.location_short}-${var.project}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  sku                 = "Standard"
  tags                = var.tags
}
```

### Example 2: Complex Module (Azure Virtual Network)

```hcl
# Azure Virtual Network Module
# Contributor: Network Team
# Description: Azure Virtual Network with subnets

module "{{resource_name}}" {
  source              = "Azure/avm-res-network-virtualnetwork/azurerm"
  version             = "0.4.0"
  name                = "vnet-${var.location_short}-${var.project}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  
  address_space = ["10.0.0.0/16"]
  
  subnets = {
    default = {
      address_prefixes = ["10.0.1.0/24"]
    }
    private = {
      address_prefixes = ["10.0.2.0/24"]
    }
  }
  
  tags = var.tags
}
```

### Example 3: Module with Dependencies

```hcl
# Azure Private Endpoint Module
# Contributor: Security Team
# Description: Azure Private Endpoint for secure connectivity

module "{{resource_name}}" {
  source              = "Azure/avm-res-network-privateendpoint/azurerm"
  version             = "0.1.1"
  name                = "pe-${var.location_short}-${var.project}-{{resource_name}}"
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  
  subnet_resource_id = data.azurerm_subnet.private.id
  
  # Add your private link service connections here
  
  tags = var.tags
}
```

## 🔧 Advanced Features

### Multiple Placeholders (Future)

In the future, we may support additional placeholders:

```hcl
# Coming soon:
# {{location}}        - Azure region
# {{environment}}     - Environment (dev/tst/uat/prd)
# {{project}}         - Project name
# {{custom:key}}      - Custom user-provided values
```

Currently supported: `{{resource_name}}`

### Conditional Logic

You can include conditional logic in your HCL:

```hcl
module "{{resource_name}}" {
  source = "..."
  
  # Use environment-specific values
  sku = var.environment == "prd" ? "Premium" : "Standard"
  
  # Use ternary operators
  public_network_access_enabled = var.environment == "dev" ? true : false
}
```

## 🤝 Contributing

### Contribution Workflow

1. **Fork the repository** (if external contributor)

2. **Create your HCL module**:
   ```bash
   cd modules/azure
   vim my-awesome-resource.hcl
   ```

3. **Test it locally**:
   ```bash
   ign list-modules
   ign add-resource --stack-name test --resource-type my-awesome-resource
   ```

4. **Commit and push**:
   ```bash
   git add modules/azure/my-awesome-resource.hcl
   git commit -m "Add Azure [Resource] module"
   git push
   ```

5. **Create a Pull Request**

### What to Include in Your PR

- [ ] The `.hcl` module file
- [ ] Description comment in the module
- [ ] Test results (Terraform validate output)
- [ ] Brief description in PR of what the module does

## 📖 Available Variables

Your modules can use these variables (defined in generated stacks):

```hcl
var.subscription_id             # Azure subscription ID
var.management_subscription_id  # Management subscription ID
var.location                    # Azure region (e.g., "uksouth")
var.location_short              # Short location code (e.g., "uks")
var.environment                 # Environment (dev/tst/uat/prd)
var.project                     # Project name (e.g., "edp")
var.enable_telemetry           # Boolean for telemetry
var.tags                       # Map of tags
```

### Available Module References

```hcl
module.naming.name.resource_group       # Standardized RG name
module.naming.name.storage_account      # Standardized storage name
module.naming.name.key_vault           # Standardized Key Vault name
module.naming.name.databricks_workspace # Standardized Databricks name
# ... and more in templates/utils/outputs.tf

module.resource_group.name              # Resource group name
module.resource_group.resource.location # Resource group location
module.resource_group.resource_id       # Resource group ID
```

### Available Data Sources

```hcl
data.azurerm_client_config.current.tenant_id  # Current tenant ID
data.azurerm_client_config.current.object_id  # Current object ID
```

## 🎓 Tips for Great Modules

1. **Start Simple**: Copy an existing module and modify it
2. **Use AVM**: Azure Verified Modules are tested and maintained
3. **Pin Versions**: Always specify module versions
4. **Add Comments**: Help future users understand configuration
5. **Secure by Default**: Disable public access, enable encryption
6. **Test Thoroughly**: Run `terraform validate` before committing

## 📞 Getting Help

- **CLI Help**: `ign list-modules --help`
- **List Modules**: `ign list-modules`
- **Azure Modules**: https://aka.ms/avm
- **Terraform Docs**: https://www.terraform.io/docs

## 🎉 Benefits

### For Contributors

✅ **No template syntax** - just write normal HCL  
✅ **Automatic discovery** - no registration needed  
✅ **Easy testing** - use immediately after creating  
✅ **Standard tools** - use any HCL editor  
✅ **Version control friendly** - diff-able HCL files  

### For Users

✅ **More modules** - easier for community to contribute  
✅ **Better quality** - HCL is easier to review  
✅ **Faster updates** - contributors don't need to learn templates  
✅ **Clearer code** - see actual Terraform configuration  

---

**Ready to contribute? Create your first module now!** 🚀

```bash
# 1. Create the file
echo '# Azure [Your Resource] Module
# Contributor: Your Name
# Description: Your resource description

module "{{resource_name}}" {
  source = "Azure/..."
  # your config
}' > modules/azure/your-resource.hcl

# 2. Test it
ign list-modules

# 3. Use it
ign add-resource \
  --stack-name test \
  --resource-type your-resource \
  --resource-name mytest
```

Happy contributing! 🎊

