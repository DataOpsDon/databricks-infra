# Module Standard

This is the house standard for the snippet files in `modules/azure/`. It is
enforced automatically by `scripts/lint_modules.py`, which runs as a
[pre-commit](#tooling) hook locally and as the `module-standards` GitHub Action
on every PR.

## What these files are (and aren't)

The files in `modules/azure/*.tf` are **not** standalone Terraform modules. They
are **snippets** that the `ign` CLI stitches into a generated stack's
`main.tf`. Because of that they:

- use the `{{resource_name}}` placeholder, which the CLI replaces with the
  user-supplied resource name;
- reference symbols that only exist in the assembled stack — `var.tags`,
  `var.enable_telemetry`, `module.resource_group`, `module.naming`,
  `data.azurerm_client_config.current`, etc.

This is why we **cannot** run `terraform validate`, `tflint`, or
`terraform-docs` on them — they reference undefined symbols and the `{{ }}`
placeholders are not resolvable in isolation. `terraform fmt` *does* work (the
labels are valid HCL strings), so formatting is enforced; everything else is
enforced by our custom linter.

## The standard

Every file in `modules/azure/` must follow this shape:

```hcl
# <Resource> Module
# Description: <short description shown by `ign list-modules`>

module "{{resource_name}}" {
  source              = "Azure/avm-res-<service>-<resource>/azurerm"
  version             = "0.1.0"            # always pin
  name                = module.naming.name.<resource>
  location            = module.resource_group.resource.location
  resource_group_name = module.resource_group.name
  enable_telemetry    = var.enable_telemetry
  tags                = var.tags

  # resource-specific config...
}

variable "example_input" {
  type        = string
  description = "Every variable needs a real description."
}
```

### Rules

| Rule | Severity | Why |
|------|----------|-----|
| File has a `# Description:` header comment | **error** | The CLI reads it for `ign list-modules` |
| Each `module` block sets a `source` | **error** | A snippet with no source is broken |
| Registry sources (`Azure/...`, `.../azurerm`) pin a `version` | **error** | Unpinned versions break reproducibility |
| Each `variable` block has a `description` | **error** | Consumers can't use undocumented inputs |
| Prefer an Azure Verified Module (`Azure/avm-*`) source | **warning** | AVM modules are tested and maintained |
| `module` block wires `tags = var.tags` | **warning** | Keeps tagging consistent across stacks |
| `module` block wires `enable_telemetry = var.enable_telemetry` | **warning** | Consistent telemetry control |

Warnings are printed but do **not** fail the build. Errors fail it.

### Using a non-AVM resource

Some resources have no AVM module, or you deliberately use a raw `azurerm`
resource (e.g. the `random_password` in `virtual-machines.tf`, or the shared
data-source lookups in `data.private.dns.tf`). That's fine — to silence the AVM
warning, add a marker comment anywhere in the file stating why:

```hcl
# avm-exempt: no AVM module exists for azurerm_foo as of 2026-06
```

Files that contain only `data`/`resource` blocks (helpers) are recognised
automatically and skip the module checks.

## Authoring a new module

1. In VS Code, create the `.tf` file under `modules/azure/`, type `avm-module`
   and press **Tab** — the snippet scaffolds a compliant block. (`avm-module-var`
   also adds an input variable; `avm-exempt` inserts the opt-out marker.)
2. Find the right AVM module at <https://aka.ms/avm> and set `source`/`version`.
3. Run the linter locally before committing:

   ```bash
   python scripts/lint_modules.py            # lint everything
   python scripts/lint_modules.py modules/azure/my-resource.tf   # one file
   ```

## Tooling

- **VS Code snippets** — `.vscode/terraform.code-snippets`
- **Linter** — `scripts/lint_modules.py` (pure stdlib Python, no dependencies)
- **Pre-commit** — `.pre-commit-config.yaml`. Set up once:

  ```bash
  pip install pre-commit
  pre-commit install          # installs the git hook
  pre-commit run --all-files  # run against the whole repo on demand
  ```

- **CI** — `.github/workflows/module-standards.yml` runs the linter plus
  `terraform fmt -check` on every PR touching `modules/azure/`.
