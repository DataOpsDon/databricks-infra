# What the GitHub bootstrap deploys (GitHub view)

This page describes what `ign bootstrap` creates **in GitHub** when `cicdPlatform: github`, and how
each object is set up. For the Azure side (state storage and managed identities) see
[BOOTSTRAP-DOCUMENTATION.md](BOOTSTRAP-DOCUMENTATION.md).

Names below use the defaults from `bootstrap/terraform/config.yaml`. Example values:
organisation `my-org`, infrastructure repository `infra-app1`, environment `dev`.

---

## At a glance

| Scope | Object | Example name | When |
|---|---|---|---|
| Organisation | Shared CI/CD repository | `my-org/terraform-azure-cicd` | First run, only if it does not exist yet |
| Organisation | CI/CD maintainers team | `terraform-azure-cicd-maintainers` | With the CI/CD repository |
| Organisation | 6 role teams | `infra-app1-platform-admin`, `infra-app1-engineers`, ... | First run per repository |
| Organisation | Deploy approvers team | `approvers-dev-app1-tf-infra-app1` | Every environment |
| Repository | Infrastructure repository (optional) | `my-org/infra-app1` | First run, if `ghCreateRepository: true` |
| Repository | Guardrails: branch ruleset, Actions policy, token permissions, Dependabot | `terraform-protected-branches` | First run per repository |
| Repository | Plan environment and variables | `dev` | Every environment |
| Repository | Apply environment, variables, approvals and branch policy | `dev/apply` | Every environment |

The run type is set by `isFirstTimeDeployToGH` in `config.yaml`:

- **`true`:** the first environment you bootstrap for a repository. It creates the teams, the guardrails,
  the shared CI/CD repository if needed, and the environments.
- **`false`:** every later environment (`tst`, `prd`, ...). It only adds the environments, the approvers
  team and the Azure trust for that environment. It looks up the existing Platform Admin team by name.

No Azure DevOps objects are created. `ado.tf` is left out of GitHub runs.

---

## 1. Shared CI/CD repository (once per organisation)

Controlled by `createCicdRepo_gh` (default `true`) and `cicdRepoName_gh` (default `terraform-azure-cicd`).

On a first run, `ign bootstrap` asks GitHub whether `<org>/<cicdRepoName_gh>` exists:

- **It exists:** it is left untouched. If `manageCicdRepoAccess_gh: true`, bootstrap still grants organisation
  access to it (see below).
- **It does not exist:** bootstrap creates and populates it.
- **GitHub cannot be reached, or the token is rejected:** the run stops before Terraform runs.

### Repository

| Setting | Value |
|---|---|
| Visibility | `cicdRepoVisibility_gh` (default `private`) |
| Default branch | `main` (no `develop` branch) |
| Merge methods | `allowedMergeMethods_gh` (default merge and squash) |
| Delete head branch after merge | on |
| Issues | on; Projects and Wiki off |
| On `terraform destroy` | archived, never deleted |

### Content

The files are rendered for your organisation (org name, repo name and `cicd_ref` filled in) and
committed to `main` one file per commit:

```text
.github/workflows/_terraform-pipeline.yml   reusable workflow called by every stack
.github/actions/tf-ci/action.yaml           composite action: fmt / validate / checkov
.github/actions/tf-plan/action.yaml         composite action: plan
.github/actions/tf-apply/action.yaml        composite action: apply
.github/workflows/release.yml               semantic version tagging (committed last)
CODEOWNERS                                  * @my-org/terraform-azure-cicd-maintainers
README.md
.gitignore
```

`release.yml` is committed last with `#major` in the commit message, so its first run publishes `v1.0.0`.

### Team and access

| Object | Setting |
|---|---|
| `terraform-azure-cicd-maintainers` team | Closed team, **Admin** on the repo, code owner of everything. Members come from `cicdRepoMaintainers_gh`. |
| Actions access level | `organization`: every repository in the organisation may call the reusable workflow and composite actions, even though the repo is private. |
| Guardrails | The same as the infrastructure repository (section 3). The maintainers team is the only bypass actor. |

---

## 2. Role teams (first run per repository)

The GitHub equivalent of the six ADO project groups. Team names are organisation-wide, so they are
prefixed with `teamPrefix_gh` (default: the repository name). Each one is a **closed** team with a
role on the infrastructure repository.

| Team | Repository role | What the role allows | Config flag |
|---|---|---|---|
| `<prefix>-platform-admin` | **Admin** | Settings, plus ruleset bypass by pull request (break-glass) and apply approval | `createPlatformAdminGroup` |
| `<prefix>-lead-engineers` | **Maintain** | Manage the repo without access to sensitive settings | `createLeadEngineerGroup` |
| `<prefix>-engineers` | **Write** | Push branches and open pull requests | `createEngineerGroup` |
| `<prefix>-project-managers` | **Triage** | Manage issues and pull requests | `createPMGroup` |
| `<prefix>-lead-testers` | **Triage** | Manage issues and pull requests | `createLeadTesterGroup` |
| `<prefix>-testers` | **Read** | Read and clone | `createTesterGroup` |

- **Membership:** set per team in `teamMembers_gh`. If a list is left empty, bootstrap does not manage that
  team's members, so you can maintain them in GitHub or through IdP team sync.
- **Code owners:** the `CODEOWNERS` file written by `ign init` names `<prefix>-lead-engineers` and
  `<prefix>-platform-admin`.

---

## 3. Repository guardrails (first run per repository)

Applied to the infrastructure repository. The same set is applied to the shared CI/CD repository when
bootstrap creates it.

### Repository (only if `ghCreateRepository: true`)

| Setting | Value |
|---|---|
| Visibility | `ghRepositoryVisibility` (`private` or `internal`) |
| Initialised | A README and the standard dev container (`.devcontainer/`, from `templates/devcontainer`) on `main`, plus a `develop` branch created from `main` |
| Merge methods | `allowedMergeMethods_gh`; auto-merge off; "update branch" button on |
| Delete head branch after merge | on |
| Secret scanning and push protection | on, if `enableSecretScanning_gh: true` |
| On `terraform destroy` | archived, never deleted |

If `ghCreateRepository: false`, the existing repository is looked up and only the guardrails below are applied.

### Branch ruleset `terraform-protected-branches`

Enforcement is **active** on `protectedBranches_gh` (default: the default branch and `refs/heads/develop`).

| Rule | Value | Config |
|---|---|---|
| Block branch deletion | on | - |
| Block force pushes | on | - |
| Require a pull request | on | - |
| Required approvals | 1 | `requiredApprovals_gh` |
| Dismiss stale approvals on new push | on | - |
| Require code owner review | on | `requireCodeOwnerReview_gh` |
| Require approval of the most recent push by someone else | on | `requireLastPushApproval_gh` |
| Require conversation resolution | on | - |
| Allowed merge methods | merge, squash | `allowedMergeMethods_gh` |
| Required status checks (strict, so the branch must be up to date) | none until configured | `requiredStatusChecks_gh`, e.g. `["dev / Terraform-CI"]` |
| Require signed commits | off | `requireSignedCommits_gh` |
| Require linear history | off | `requireLinearHistory_gh` |
| Bypass | Platform Admin team, **pull requests only** (no direct pushes) | - |

The ruleset is created after the initial files and the `develop` branch, so bootstrap's own commits are not blocked.
On private repositories, rulesets need GitHub Team or Enterprise. Set `enableRulesets_gh: false` if they are not available.

### GitHub Actions policy (`manageActionsPermissions_gh: true`)

| Setting | Value |
|---|---|
| Actions enabled | yes |
| Allowed actions | **Selected only**: actions owned by GitHub and by your organisation, plus `allowedActionPatterns_gh` (default `azure/login@*`, `bridgecrewio/checkov-action@*`). Verified Marketplace creators are **not** allowed by default. |
| Require actions to be pinned to a full SHA | `shaPinningRequired_gh` (default off) |
| Default `GITHUB_TOKEN` permissions | **Read**. Workflows must request anything more, such as `id-token: write`. |
| Actions can approve pull requests | **No**, so a workflow cannot satisfy the review rule itself |

### Security (`enableVulnerabilityAlerts_gh: true`)

- Dependabot alerts: on.
- Dependabot security updates (automatic fix pull requests): on.

---

## 4. Environments (every environment you bootstrap)

These are the GitHub equivalent of the ADO build and deploy service connections. Each environment
holds the variables the shared workflow reads, and is trusted by one Azure managed identity through
OIDC. No secrets are stored.

| | Plan environment | Apply environment |
|---|---|---|
| Name | `<environmentName_gh>` (e.g. `dev`) | `<environmentName_gh>/apply` (e.g. `dev/apply`) |
| Used by | CI and plan jobs | Apply job |
| Azure identity | Build identity (Reader) | Deploy identity (Owner, with a condition that stops it granting roles) |
| Required reviewers | none | Approvers team + Platform Admin team (`deployApprovalRequired`) |
| Prevent self-review | - | on (`preventSelfReviewDeploy_gh`) |
| Admins can bypass | - | off (`canAdminsBypassDeploy_gh`) |
| Wait timer | - | `deployWaitTimer_gh` minutes (default 0) |
| Deployment branches | any | Only `applyBranchPatterns_gh` (default `main`, `develop`; use `["main"]` for prd) |

### Environment variables (on both environments)

| Variable | Value |
|---|---|
| `AZURE_CLIENT_ID` | Build identity client ID (plan env) / deploy identity client ID (apply env) |
| `AZURE_TENANT_ID` | Tenant of the identities |
| `AZURE_SUBSCRIPTION_ID` | Application subscription |
| `TF_STATE_SUBSCRIPTION_ID` | State subscription |
| `TF_STATE_RESOURCE_GROUP` | State resource group |
| `TF_STATE_STORAGE_ACCOUNT` | State storage account |
| `TF_STATE_CONTAINER` | `defaultStateContainer_gh` (default `infra`). Stacks can override it with the `state_container` input. |

These are plain environment **variables**, not secrets. None of the values are sensitive.

### Deploy approvers team (per environment)

| Setting | Value |
|---|---|
| Name | `teamName_gh` (default `approvers-<env>-<app_short>-tf-<repo>`) |
| Privacy | Closed |
| Repository role | **Read** (reviewers need at least read access) |
| Members | `approvers_gh`. If left empty, nobody can approve an apply until you add people in GitHub. |

### OIDC trust (what links GitHub to Azure)

Each environment gets a federated credential on its managed identity. The credential trusts tokens from
`https://token.actions.githubusercontent.com` with audience `api://AzureADTokenExchange` and this subject:

| Identity | Trusted subject |
|---|---|
| Build | `repo:my-org@123456/infra-app1@456789:environment:dev` |
| Deploy | `repo:my-org@123456/infra-app1@456789:environment:dev/apply` |

`123456` and `456789` are the organisation and repository IDs. The bootstrap looks them up from GitHub.
This is GitHub's immutable subject format: the default for repositories created after 15 July 2026, and for
older repositories that have opted in. A rename therefore doesn't break the trust, and a new repository that
reuses an old name can't take it over. For an older repository that hasn't opted in, set
`oidcSubjectFormat_gh: "legacy"` to trust `repo:<org>/<repo>:environment:<env>` instead.

The result:

- Only jobs that run **in that environment of that repository** can sign in to Azure.
- A pull request or feature-branch job can only get the Reader identity.
- The Owner identity is only issued after an approved review, from an allowed branch.

---

## 5. How it fits together

```text
my-org/terraform-azure-cicd  (shared, org-wide access, tagged v1.0.0)
  └── _terraform-pipeline.yml  ◄── called by every stack workflow
                                       │
my-org/infra-app1                      │
  ├── ruleset: PR + code owner review on main / develop
  ├── Actions: selected only, GITHUB_TOKEN read-only
  ├── env "dev"        ── OIDC ──► umi-tfbuild-…   (Reader)        CI + plan
  └── env "dev/apply"  ── OIDC ──► umi-tfdeploy-…  (Owner, cond.)  apply
         └── required reviewers: approvers-dev-… + infra-app1-platform-admin
             branches: main, develop
```

---

## 6. What it does not do (manual follow-up)

- **Add people to teams** whose member lists you left empty, especially the approvers team.
- **Add required status checks** (`requiredStatusChecks_gh`) once the workflow has run at least once and
  the check names exist.
- **Add a `MODULE_REPO_PAT` repository secret** if stacks pull private Terraform modules. Bootstrap never
  stores secrets.
- **Grant access to an existing CI/CD repository** that was created outside bootstrap. Set
  `manageCicdRepoAccess_gh: true` (needs admin on that repo), or change it in
  **Settings → Actions → General → Access**.
- **Organisation-level settings**, such as SSO, base permissions and org-wide Actions policy, are left
  unchanged. Bootstrap only manages the repositories and teams above.

### Token needed to run it

A classic PAT (or `gh auth token`) with `repo`, `workflow` and `admin:org` scopes. The `admin:org` scope
is needed to create teams. The token comes from `--gh-token`, `GITHUB_TOKEN`, `gh auth token` or a prompt,
in that order, and is never written to disk.
