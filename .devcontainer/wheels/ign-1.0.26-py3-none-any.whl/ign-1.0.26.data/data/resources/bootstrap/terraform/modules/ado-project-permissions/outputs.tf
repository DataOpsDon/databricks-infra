output "ado_project_group_descriptor" {
  description = "Azure DevOps project group descriptor"
  value       = azuredevops_group.project_group.descriptor
}
