output "repository_name" {
  description = "Repository name (without the organisation)"
  value       = local.repository_name
}

output "full_name" {
  description = "Repository full name (org/repo)"
  value       = local.full_name
}

output "repo_id" {
  description = "Numeric repository ID (used in the immutable GitHub OIDC subject claim)"
  value       = local.repo_id
}

output "ruleset_id" {
  description = "ID of the protected-branches ruleset (null when rulesets are disabled)"
  value       = var.enable_rulesets ? github_repository_ruleset.protected_branches[0].ruleset_id : null
}

output "committed_files" {
  description = "Files committed when the repository was created"
  value       = sort(concat(keys(local.first_files), keys(local.last_files)))
}

