terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
    }
    azuredevops = {
      source  = "microsoft/azuredevops"
      version = "1.16.0"
    }
    fabric = {
      source  = "microsoft/fabric"
      version = "1.11.0"
    }
  }
}
