output "environment" {
  description = "Environment name"
  value       = local.environment
}

output "state_subscription_id" {
  description = "Subscription ID where state storage is created"
  value       = local.subscriptionId_State
}

output "state_resource_group_name" {
  description = "Resource Group name for Terraform state storage"
  value       = local.rgName_state
}

output "storage_account_name" {
  description = "Storage Account name for Terraform state files"
  value       = local.saName_state
}

output "container_names" {
  description = "List of Terraform state storage container names"
  value       = [for k, v in local.containers_state : v.name]
}

output "build_umi_name" {
  description = "Build User Managed Identity name"
  value       = local.umiName_build
}

output "build_umi_principal_id" {
  description = "Build User Managed Identity principal ID"
  value       = module.umi_tf_build.principal_id
}

output "build_umi_client_id" {
  description = "Build User Managed Identity client/object ID"
  value       = module.umi_tf_build.client_id
}

output "deploy_umi_name" {
  description = "Deploy User Managed Identity name"
  value       = local.umiName_deploy
}

output "deploy_umi_principal_id" {
  description = "Deploy User Managed Identity principal ID"
  value       = module.umi_tf_deploy.principal_id
}

output "deploy_umi_client_id" {
  description = "Deploy User Managed Identity client/object ID"
  value       = module.umi_tf_deploy.client_id
}

output "build_sc_name" {
  description = "Build Service Connection name"
  value       = local.serviceConnectionName_Build
}

output "deploy_sc_name" {
  description = "Deploy Service Connection name"
  value       = local.serviceConnectionName_Deploy
}

output "tenant_id" {
  description = "Microsoft Entra tenant ID"
  value       = data.azurerm_client_config.current.tenant_id
}

output "application_subscription_id" {
  description = "Subscription ID the deploy identity can deploy into"
  value       = local.subscriptionId_Application
}

output "cicd_platform" {
  description = "CI/CD platform configured for this environment (ado or github)"
  value       = local.cicdPlatform
}

output "github_repository" {
  description = "GitHub repository (org/repo) trusted by the federated credentials (GitHub only)"
  value       = local.github_configured ? "${local.orgName_gh}/${local.repositoryName_gh}" : ""
}

output "github_environment" {
  description = "GitHub environment used by the CI and plan jobs (GitHub only)"
  value       = local.github_configured ? local.environmentName_gh : ""
}

output "github_apply_environment" {
  description = "GitHub environment used by the apply job (GitHub only)"
  value       = local.github_configured ? "${local.environmentName_gh}/apply" : ""
}

output "github_subject_build" {
  description = "Federated credential subject trusted by the build identity (GitHub only)"
  value       = local.github_configured ? local.github_subject_build : ""
}

output "github_subject_deploy" {
  description = "Federated credential subject trusted by the deploy identity (GitHub only)"
  value       = local.github_configured ? local.github_subject_deploy : ""
}

output "github_teams" {
  description = "Role teams created in GitHub as \"slug (repository role)\". Empty after the first run."
  value       = [for k, m in module.gh_teams : "${local.gh_teams[k].slug} (${local.gh_teams[k].permission})"]
}

output "github_platform_admin_team" {
  description = "Slug of the Platform Admin team (use it in CODEOWNERS as @<org>/<slug>)"
  value       = local.github_configured && contains(keys(local.gh_teams), "platformAdmin") ? local.gh_teams["platformAdmin"].slug : ""
}

output "github_approvers_team" {
  description = "Slug of the team that approves applies in the apply environment"
  value       = local.github_configured ? module.deploy_github_environment[0].approvers_team_slug : ""
}

output "github_apply_branches" {
  description = "Branches allowed to run in the apply environment"
  value       = local.github_configured ? local.applyBranchPatterns_gh : []
}

output "github_environment_variables" {
  description = "Variables created on both GitHub environments"
  value       = local.github_configured ? module.build_github_environment[0].variable_names : []
}

output "github_default_state_container" {
  description = "Value of TF_STATE_CONTAINER on the GitHub environments"
  value       = local.github_configured ? local.defaultStateContainer_gh : ""
}

output "github_ruleset_id" {
  description = "ID of the protected-branches ruleset (first run only)"
  value       = local.github_first_time ? module.gh_repository[0].ruleset_id : null
}

output "github_cicd_repository" {
  description = "Shared CI/CD repository (org/repo)"
  value       = local.github_configured ? "${local.orgName_gh}/${local.cicdRepoName_gh}" : ""
}

output "github_cicd_repository_status" {
  description = "What bootstrap did with the shared CI/CD repository"
  value = (
    !local.github_configured ? "" :
    local.create_cicd_repo ? "created and populated (its release workflow publishes v1.0.0)" :
    var.cicd_repo_exists ? "already existed - left unchanged" :
    "not managed (createCicdRepo_gh is false or this is not the first run)"
  )
}

output "github_cicd_committed_files" {
  description = "Files committed to the shared CI/CD repository"
  value       = local.create_cicd_repo ? module.gh_cicd_repository[0].committed_files : []
}

output "github_cicd_maintainers_team" {
  description = "Code owners team of the shared CI/CD repository"
  value       = local.create_cicd_repo ? "${local.cicdRepoName_gh}-maintainers" : ""
}
