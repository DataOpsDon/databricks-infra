output "environment_name" {
  description = "GitHub environment name"
  value       = github_repository_environment.this.environment
}

output "approvers_team_slug" {
  description = "Slug of the approvers team (empty when approval is not required)"
  value       = var.deploy_approval_required ? github_team.approvers[0].slug : ""
}

output "variable_names" {
  description = "Environment variables created"
  value       = sort(keys(var.environment_variables))
}
