terraform {
  required_providers {
    github = {
      source = "integrations/github"
    }
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}
