variable "project_id" {
  type = string
}

variable "project_name" {
  type = string
}

variable "is_group_team_admin" {
  type    = bool
  default = false
}

variable "project_group_name" {
  type = string
}

variable "project_group_description" {
  type = string
}

variable "project_permissions" {
  type = map(string)
}

variable "area_permissions" {
  type = map(string)
}

variable "build_permissions" {
  type = map(string)
}

variable "git_permissions" {
  type = map(string)
}

variable "iteration_permissions" {
  type = map(string)
}

variable "library_permissions" {
  type = map(string)
}

variable "tagging_permissions" {
  type = map(string)
}

variable "shared_query_permissions" {
  type = map(string)
}

variable "environment_permission_role" {
  type = string

  validation {
    condition = (
      anytrue([
        var.environment_permission_role == "Administrator",
        var.environment_permission_role == "Creator",
        var.environment_permission_role == "User",
        var.environment_permission_role == "Reader"
      ])
    )
    error_message = "Environment permission role can only be Administrator, Creator, User, or Reader."
  }
}

variable "service_endpoint_permission_role" {
  type = string

  validation {
    condition = (
      anytrue([
        var.service_endpoint_permission_role == "Administrator",
        var.service_endpoint_permission_role == "User",
        var.service_endpoint_permission_role == "Reader"
      ])
    )
    error_message = "Service endpoint permission role can only be Administrator, User, or Reader."
  }
}
