variable "repository_name" {
  type        = string
  description = "Repository name (without the organisation)."
}

variable "create_repository" {
  type        = bool
  default     = false
  description = "Create the repository. When false an existing repository is looked up and only the guardrails are applied."
}

variable "description" {
  type    = string
  default = ""
}

variable "visibility" {
  type    = string
  default = "private"

  validation {
    condition     = contains(["private", "internal"], var.visibility)
    error_message = "Visibility must be private or internal. Public infrastructure repositories are not supported by this standard."
  }
}

variable "default_branch" {
  type    = string
  default = "main"
}

variable "create_develop_branch" {
  type        = bool
  default     = true
  description = "Create a develop branch from the default branch (only when the repository is created)."
}

# ----- Merge settings -----
variable "allowed_merge_methods" {
  type    = list(string)
  default = ["merge", "squash"]

  validation {
    condition     = length(var.allowed_merge_methods) > 0 && alltrue([for m in var.allowed_merge_methods : contains(["merge", "squash", "rebase"], m)])
    error_message = "allowed_merge_methods must contain at least one of merge, squash, rebase."
  }
}

# ----- Security -----
variable "enable_vulnerability_alerts" {
  type    = bool
  default = true
}

variable "enable_secret_scanning" {
  type        = bool
  default     = false
  description = "Secret scanning + push protection (repository creation only). Private/internal repos need GitHub Secret Protection (Advanced Security) licences."
}

# ----- Actions policy -----
variable "manage_actions_permissions" {
  type    = bool
  default = true
}

variable "allowed_action_patterns" {
  type        = list(string)
  default     = []
  description = "Third-party actions / reusable workflows allowed in addition to GitHub-owned and organisation-owned ones (e.g. azure/login@*)."
}

variable "verified_actions_allowed" {
  type    = bool
  default = false
}

variable "sha_pinning_required" {
  type    = bool
  default = false
}

# ----- Branch rulesets -----
variable "enable_rulesets" {
  type    = bool
  default = true
}

variable "protected_branches" {
  type    = list(string)
  default = ["~DEFAULT_BRANCH", "refs/heads/develop"]
}

variable "required_approvals" {
  type    = number
  default = 1

  validation {
    condition     = var.required_approvals >= 0 && var.required_approvals <= 10
    error_message = "required_approvals must be between 0 and 10."
  }
}

variable "dismiss_stale_reviews" {
  type    = bool
  default = true
}

variable "require_code_owner_review" {
  type    = bool
  default = true
}

variable "require_last_push_approval" {
  type    = bool
  default = true
}

variable "require_conversation_resolution" {
  type    = bool
  default = true
}

variable "required_status_checks" {
  type        = list(string)
  default     = []
  description = "Status check contexts that must pass before merging, e.g. 'dev / Terraform-CI'."
}

variable "require_signed_commits" {
  type    = bool
  default = false
}

variable "require_linear_history" {
  type    = bool
  default = false
}

variable "bypass_team_ids" {
  type        = list(number)
  default     = []
  description = "Team IDs that may bypass the branch ruleset, only through a pull request (break-glass)."
}

# ----- Initial content (repository creation only) -----
variable "initial_files" {
  type        = map(string)
  default     = {}
  description = "Files committed to the default branch when the repository is created (path => content)."
}

variable "initial_binary_files" {
  type        = map(string)
  default     = {}
  description = "Binary files committed to the default branch when the repository is created (repo path => local file path), e.g. the Ignition CLI wheel."
}

variable "python_executable" {
  type        = string
  default     = "python3"
  description = "Python interpreter used to upload initial_binary_files (ign bootstrap passes its own)."
}

variable "last_file_paths" {
  type        = list(string)
  default     = []
  description = "Paths from initial_files committed after all the others (e.g. a release workflow that should only run once)."
}

variable "initial_commit_message" {
  type    = string
  default = "Initial commit (ign bootstrap)"
}

variable "last_commit_message" {
  type    = string
  default = "Initial commit (ign bootstrap)"
}

