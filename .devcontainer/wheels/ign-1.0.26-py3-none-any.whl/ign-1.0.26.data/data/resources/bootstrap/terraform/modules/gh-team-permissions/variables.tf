variable "team_name" {
  type        = string
  description = "Team name. GitHub team names are organisation-wide, so prefix them with the repository name."
}

variable "team_description" {
  type    = string
  default = ""
}

variable "repository" {
  type        = string
  description = "Repository the team is granted access to."
}

variable "repository_permission" {
  type        = string
  description = "Repository role: pull, triage, push, maintain, admin, or the name of an organisation custom repository role."

  validation {
    condition     = length(trimspace(var.repository_permission)) > 0
    error_message = "repository_permission must not be empty."
  }
}

variable "parent_team_id" {
  type        = string
  default     = null
  description = "Optional parent team ID or slug (nested teams)."
}

variable "members" {
  type        = list(string)
  default     = []
  description = "GitHub usernames added as team members."
}

variable "maintainers" {
  type        = list(string)
  default     = []
  description = "GitHub usernames added as team maintainers."
}
