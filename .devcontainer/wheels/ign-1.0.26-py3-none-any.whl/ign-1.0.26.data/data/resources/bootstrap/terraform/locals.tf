locals {
  # Pass 1: Parse raw configuration from YAML file to extract parameters
  raw_config = yamldecode(file("${path.module}/config.yaml"))

  # Parameter map provided to templatefile for evaluating ${...} expressions in config.yaml
  params = {
    environment       = local.raw_config.environment
    location          = local.raw_config.location
    locationShort     = local.raw_config.locationShort
    app_short         = local.raw_config.app_short
    instance          = try(local.raw_config.instance, "01")
    repositoryName_gh = try(local.raw_config.repositoryName_gh, local.raw_config.app_short)
  }

  # Pass 2: Render config.yaml as a template using parameters, then decode full YAML configuration
  config = yamldecode(templatefile("${path.module}/config.yaml", local.params))

  # Values from YAML (all configuration)
  environment                  = local.config.environment
  location                     = local.config.location
  locationShort                = local.config.locationShort
  app_short                    = local.config.app_short
  instance                     = try(local.config.instance, "01")
  tags                         = local.config.tags
  subscriptionId_State         = local.config.subscriptionId_State
  tags_state                   = local.config.tags_state
  containers_state             = local.config.containers_state
  subscriptionId_umi           = local.config.subscriptionId_umi
  tags_umi                     = local.config.tags_umi
  subscriptionId_Application   = local.config.subscriptionId_Application
  subscriptionName_Application = local.config.subscriptionName_Application
  preventSelfReviewDeploy_gh   = local.config.preventSelfReviewDeploy_gh
  deployApprovalRequired       = local.config.deployApprovalRequired
  preventSelfReviewDeploy_ado  = local.config.preventSelfReviewDeploy_ado

  # Resource names evaluated directly from config.yaml templates
  rgName_state                 = local.config.rgName_state
  saName_state                 = local.config.saName_state
  rgName_umi                   = local.config.rgName_umi
  umiName_build                = local.config.umiName_build
  umiName_deploy               = local.config.umiName_deploy
  serviceConnectionName_Build  = local.config.serviceConnectionName_Build
  serviceConnectionName_Deploy = local.config.serviceConnectionName_Deploy
  scDescription                = local.config.scDescription
  repositoryName_gh            = local.config.repositoryName_gh
  teamName_gh                  = try(local.config.teamName_gh, "approvers-${local.environment}-${local.app_short}-tf-${local.repositoryName_gh}")
  environmentName_gh           = try(local.config.environmentName_gh, local.environment)

  # Optional variables from YAML
  isFirstTimeDeployToADO = try(local.config.isFirstTimeDeployToADO, false)
  adoOrgUrl              = try(local.config.adoOrgUrl, null)
  adoCreateProject       = try(local.config.adoCreateProject, false)
  # Never null: the ADO data source / project validate their arguments even when count = 0,
  # and GitHub projects set adoProjectName to null.
  adoProjectName                            = coalesce(try(local.config.adoProjectName, null), "not-configured")
  adoProjectDescription                     = try(local.config.adoProjectDescription, "")
  adoPAT                                    = try(local.config.adoPAT, null)
  ghPAT                                     = try(local.config.ghPAT, null)
  orgName_gh                                = try(local.config.orgName_gh, null)
  stateStorageSku                           = try(local.config.stateStorageSku, null)
  stateStoragePublic_network_access_enabled = try(local.config.stateStoragePublic_network_access_enabled, null)

  # CI/CD platform: "ado" (Azure DevOps service connections) or "github" (GitHub Actions OIDC)
  cicdPlatform = lower(try(local.config.cicdPlatform, "ado"))

  # Derived logic
  ado_configured    = local.cicdPlatform != "github" && local.adoOrgUrl != null && local.adoOrgUrl != ""
  github_configured = local.cicdPlatform == "github" && local.orgName_gh != null && local.orgName_gh != ""

  # GitHub OIDC subject format (github_subject_build / github_subject_deploy are built in main.tf):
  #   immutable (default) - repo:<org>@<orgId>/<repo>@<repoId>:environment:<env>
  #                         Default for github.com repositories created after 15 July 2026, and for
  #                         older repositories that opted in to immutable subject claims.
  #   legacy              - repo:<org>/<repo>:environment:<env>  (older repositories that have not opted in)
  oidcSubjectFormat_gh = lower(try(local.config.oidcSubjectFormat_gh, "immutable"))

  # ---------------------------------------------------------------------------
  # GitHub (cicdPlatform: github)
  # ---------------------------------------------------------------------------
  isFirstTimeDeployToGH   = try(local.config.isFirstTimeDeployToGH, false) == true
  github_first_time       = local.github_configured && local.isFirstTimeDeployToGH
  ghCreateRepository      = try(local.config.ghCreateRepository, false) == true
  ghRepositoryVisibility  = try(local.config.ghRepositoryVisibility, "internal")
  ghRepositoryDescription = try(local.config.ghRepositoryDescription, "")
  canAdminsBypassDeploy   = try(local.config.canAdminsBypassDeploy_gh, false) == true
  deployWaitTimer_gh      = try(local.config.deployWaitTimer_gh, 0)
  applyBranchPatterns_gh  = try(local.config.applyBranchPatterns_gh, ["main", "develop"])
  approvers_gh            = coalesce(try(local.config.approvers_gh, null), [])
  teamPrefix_gh           = try(local.config.teamPrefix_gh, local.repositoryName_gh)
  cicdRepoName_gh         = try(local.config.cicdRepoName_gh, "terraform-azure-cicd")
  manageCicdRepoAccess_gh = try(local.config.manageCicdRepoAccess_gh, false) == true
  createCicdRepo_gh       = try(local.config.createCicdRepo_gh, true) == true
  cicdRepoVisibility_gh   = try(local.config.cicdRepoVisibility_gh, "internal")
  cicdRepoMaintainers_gh  = coalesce(try(local.config.cicdRepoMaintainers_gh, null), [])

  # The shared CI/CD repo is created once per organisation, on a repository's first run,
  # only when ign bootstrap found that it does not exist yet.
  create_cicd_repo = local.github_first_time && local.createCicdRepo_gh && !var.cicd_repo_exists
  cicd_repo_files = local.create_cicd_repo && var.cicd_repo_files_dir != "" ? {
    for f in fileset(var.cicd_repo_files_dir, "**") : f => file("${var.cicd_repo_files_dir}/${f}")
  } : {}
  # Starter files (dev container) committed to the infrastructure repository when bootstrap creates it.
  # Text files go through github_repository_file; binary ones (*.whl - the Ignition CLI wheel) are
  # uploaded separately because file() and github_repository_file only handle UTF-8 text.
  create_app_repo_files = local.github_first_time && local.ghCreateRepository && var.app_repo_files_dir != ""
  app_repo_files = local.create_app_repo_files ? {
    for f in fileset(var.app_repo_files_dir, "**") : f => file("${var.app_repo_files_dir}/${f}") if !endswith(lower(f), ".whl")
  } : {}
  app_repo_binary_files = local.create_app_repo_files ? {
    for f in fileset(var.app_repo_files_dir, "**/*.whl") : f => abspath("${var.app_repo_files_dir}/${f}")
  } : {}
  defaultStateContainer_gh = try(
    local.config.defaultStateContainer_gh,
    length(local.containers_state) > 0 ? values(local.containers_state)[0].name : ""
  )

  # Guardrails
  gh_guardrails = {
    enable_rulesets             = try(local.config.enableRulesets_gh, true) == true
    protected_branches          = try(local.config.protectedBranches_gh, ["~DEFAULT_BRANCH", "refs/heads/develop"])
    required_approvals          = try(local.config.requiredApprovals_gh, 1)
    require_code_owner_review   = try(local.config.requireCodeOwnerReview_gh, true) == true
    require_last_push_approval  = try(local.config.requireLastPushApproval_gh, true) == true
    required_status_checks      = coalesce(try(local.config.requiredStatusChecks_gh, null), [])
    require_signed_commits      = try(local.config.requireSignedCommits_gh, false) == true
    require_linear_history      = try(local.config.requireLinearHistory_gh, false) == true
    allowed_merge_methods       = try(local.config.allowedMergeMethods_gh, ["merge", "squash"])
    manage_actions_permissions  = try(local.config.manageActionsPermissions_gh, true) == true
    allowed_action_patterns     = coalesce(try(local.config.allowedActionPatterns_gh, null), [])
    sha_pinning_required        = try(local.config.shaPinningRequired_gh, false) == true
    enable_vulnerability_alerts = try(local.config.enableVulnerabilityAlerts_gh, true) == true
    enable_secret_scanning      = try(local.config.enableSecretScanning_gh, false) == true
  }

  # Role teams: GitHub equivalent of the ADO project groups. Team names are
  # organisation-wide, so they are prefixed with teamPrefix_gh.
  gh_team_members = try(local.config.teamMembers_gh, {})
  gh_team_definitions = {
    platformAdmin = { suffix = "platform-admin", create = local.createPlatformAdminGroup, description = "Platform Admins: repository administration, break-glass ruleset bypass and apply approval." }
    leadEngineer  = { suffix = "lead-engineers", create = local.createLeadEngineerGroup, description = "Lead Engineers: maintain the repository, manage issues and pull requests." }
    engineer      = { suffix = "engineers", create = local.createEngineerGroup, description = "Engineers: push branches and open pull requests." }
    pm            = { suffix = "project-managers", create = local.createPMGroup, description = "Project Managers: triage issues and pull requests." }
    leadTester    = { suffix = "lead-testers", create = local.createLeadTesterGroup, description = "Lead Testers: triage issues and pull requests." }
    tester        = { suffix = "testers", create = local.createTesterGroup, description = "Testers: read access." }
  }
  gh_teams = {
    for k, t in local.gh_team_definitions : k => {
      name        = "${local.teamPrefix_gh}-${t.suffix}"
      slug        = lower(replace("${local.teamPrefix_gh}-${t.suffix}", "/[^a-zA-Z0-9-]+/", "-"))
      description = t.description
      permission  = var.github_team_repository_roles[k]
      members     = coalesce(try(local.gh_team_members[k], null), [])
    } if t.create == true
  }

  # Variables read by the shared reusable workflow. Build = CI/plan environment, deploy = apply environment.
  gh_common_variables = {
    AZURE_TENANT_ID          = data.azurerm_client_config.current.tenant_id
    AZURE_SUBSCRIPTION_ID    = local.subscriptionId_Application
    TF_STATE_SUBSCRIPTION_ID = local.subscriptionId_State
    TF_STATE_RESOURCE_GROUP  = local.rgName_state
    TF_STATE_STORAGE_ACCOUNT = local.saName_state
    TF_STATE_CONTAINER       = local.defaultStateContainer_gh
  }

  # groups
  createLeadEngineerGroup  = try(local.config.createLeadEngineerGroup, true)
  createPMGroup            = try(local.config.createPMGroup, true)
  createEngineerGroup      = try(local.config.createEngineerGroup, true)
  createLeadTesterGroup    = try(local.config.createLeadTesterGroup, true)
  createTesterGroup        = try(local.config.createTesterGroup, true)
  createPlatformAdminGroup = try(local.config.createPlatformAdminGroup, true)
}
