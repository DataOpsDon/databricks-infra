# -----------------------------------------------------------------------------
# GitHub team + repository role.
# GitHub equivalent of the ado-project-permissions module: one team per persona
# (Platform Admin, Lead Engineers, Engineers, ...) with a repository role.
# -----------------------------------------------------------------------------

resource "github_team" "this" {
  name           = var.team_name
  description    = var.team_description
  privacy        = "closed"
  parent_team_id = var.parent_team_id
}

resource "github_team_repository" "this" {
  team_id    = github_team.this.id
  repository = var.repository
  permission = var.repository_permission
}

# Authoritative membership: only managed when members are supplied in config.yaml.
# Leave the lists empty to manage membership in GitHub (or through IdP team sync).
resource "github_team_members" "this" {
  count     = length(var.members) + length(var.maintainers) > 0 ? 1 : 0
  team_slug = github_team.this.slug

  dynamic "members" {
    for_each = toset(var.maintainers)
    content {
      username = members.value
      role     = "maintainer"
    }
  }

  dynamic "members" {
    for_each = setsubtract(toset(var.members), toset(var.maintainers))
    content {
      username = members.value
      role     = "member"
    }
  }
}
