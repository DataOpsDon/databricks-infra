#TODO: project permissions
# Group permissions- Done
# Area permissions - Done
# Sprint permissions - Done
# Agent pool permissions
# Service connection permissions - Done
# Repo permissions - Done
# Query permissions - Done
# Delivery plan permissions
# Pipeline permissions - Done
# Environment permissions - Done
# Library permissions - Done
# Feed permissions


# Create the ADO group
resource "azuredevops_group" "project_group" {
  scope        = var.project_id
  display_name = var.project_group_name
  description  = var.project_group_description
}

data "azuredevops_team" "ado_team" {
  project_id = var.project_id
  name       = "${var.project_name} Team"
}

resource "azuredevops_team_administrators" "ado_team_admins" {
  count      = var.is_group_team_admin ? 1 : 0
  project_id = var.project_id
  team_id    = data.azuredevops_team.ado_team.id
  mode       = "add"
  administrators = [
    azuredevops_group.project_group.descriptor
  ]
}

resource "azuredevops_team_members" "ado_team_members" {
  project_id = var.project_id
  team_id    = data.azuredevops_team.ado_team.id
  mode       = "add"
  members = [
    azuredevops_group.project_group.descriptor
  ]
}

############### Set Permissions #######################################

# Set top level project permissions
resource "azuredevops_project_permissions" "project_permission" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.project_permissions
}

# Assign area permissions
resource "azuredevops_area_permissions" "area_permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  path        = "/"
  permissions = var.area_permissions
}

resource "azuredevops_build_folder_permissions" "build_folder_permissions" {
  project_id = var.project_id
  path       = "\\"
  principal  = azuredevops_group.project_group.id

  permissions = var.build_permissions
}

resource "azuredevops_git_permissions" "git_permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.git_permissions
}

resource "azuredevops_iteration_permissions" "iteration_permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.iteration_permissions
}

resource "azuredevops_library_permissions" "permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.library_permissions
}

resource "azuredevops_tagging_permissions" "tagging_permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.tagging_permissions
}

resource "azuredevops_workitemquery_permissions" "shared_queries_permissions" {
  project_id  = var.project_id
  principal   = azuredevops_group.project_group.id
  permissions = var.shared_query_permissions
  path        = "/"
}

resource "azuredevops_securityrole_assignment" "all_environments_permission" {
  scope       = "distributedtask.globalenvironmentreferencerole"
  resource_id = var.project_id
  identity_id = azuredevops_group.project_group.origin_id
  role_name   = var.environment_permission_role
}

resource "azuredevops_securityrole_assignment" "service_endpoint_permission" {
  scope       = "distributedtask.project.serviceendpointrole"
  resource_id = var.project_id
  identity_id = azuredevops_group.project_group.origin_id
  role_name   = var.service_endpoint_permission_role
}
