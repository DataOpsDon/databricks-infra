terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.81.0"
    }
    azuredevops = {
      # Configured and used only in ado.tf (left out of GitHub runs)
      source  = "microsoft/azuredevops"
      version = "1.16.0"
    }
    github = {
      source  = "integrations/github"
      version = "~> 6.13"
    }
    fabric = {
      source  = "microsoft/fabric"
      version = "1.11.0"
    }
  }
}

provider "azurerm" {
  features {}
  use_oidc            = true
  subscription_id     = local.subscriptionId_State
  storage_use_azuread = true
}

provider "azurerm" {
  alias = "application"
  features {}
  use_oidc            = true
  subscription_id     = local.subscriptionId_Application
  storage_use_azuread = true
}

# GitHub provider - only used when cicdPlatform is "github" (all GitHub resources are conditional)
# The token is read from the GITHUB_TOKEN environment variable, set securely by the CLI
# (`ign bootstrap` prompts for it or uses `gh auth token`) and never stored in files.
# Required token scopes (classic PAT): repo, admin:org (teams), workflow.
provider "github" {
  owner = local.orgName_gh
  token = local.ghPAT
}

provider "fabric" {
  # Configuration options
  #tenant_id =
  use_oidc                            = true
  use_workspace_private_link_endpoint = true
}

provider "random" {}
