# -----------------------------------------------------------------------------
# GitHub Actions environment + Azure OIDC trust.
# GitHub equivalent of the ado-service-connection module:
#   ADO service connection        -> GitHub environment + environment variables
#   ADO federated credential      -> federated credential trusting the environment
#   ADO approvers group + check   -> approvers team + required reviewers
# -----------------------------------------------------------------------------

resource "github_team" "approvers" {
  count       = var.deploy_approval_required ? 1 : 0
  name        = var.approvers_team_name
  description = "Approvers for GitHub environment ${var.environment_name} in ${var.repository}"
  privacy     = "closed"
}

# Reviewers must have at least read access to the repository.
resource "github_team_repository" "approvers" {
  count      = var.deploy_approval_required ? 1 : 0
  team_id    = github_team.approvers[0].id
  repository = var.repository
  permission = "pull"
}

resource "github_team_members" "approvers" {
  count     = var.deploy_approval_required && length(var.approvers) > 0 ? 1 : 0
  team_slug = github_team.approvers[0].slug

  dynamic "members" {
    for_each = toset(var.approvers)
    content {
      username = members.value
      role     = "member"
    }
  }
}

locals {
  all_reviewer_team_ids = var.deploy_approval_required ? distinct(concat([tonumber(github_team.approvers[0].id)], var.additional_reviewer_team_ids)) : []
  # GitHub accepts at most 6 required reviewers per environment.
  reviewer_team_ids = slice(local.all_reviewer_team_ids, 0, min(6, length(local.all_reviewer_team_ids)))
}

resource "github_repository_environment" "this" {
  repository          = var.repository
  environment         = var.environment_name
  wait_timer          = var.wait_timer
  can_admins_bypass   = var.can_admins_bypass
  prevent_self_review = var.deploy_approval_required && var.environment_name != "dev" ? var.prevent_self_review : false

  dynamic "reviewers" {
    for_each = var.deploy_approval_required ? [1] : []
    content {
      teams = local.reviewer_team_ids
    }
  }

  # Restrict which branches may run jobs in this environment (and so obtain the
  # identity's token). Empty list = any branch.
  dynamic "deployment_branch_policy" {
    for_each = length(var.deployment_branch_patterns) > 0 ? [1] : []
    content {
      protected_branches     = false
      custom_branch_policies = true
    }
  }

  depends_on = [github_team_repository.approvers]
}

resource "github_repository_environment_deployment_policy" "this" {
  for_each       = toset(var.deployment_branch_patterns)
  repository     = var.repository
  environment    = github_repository_environment.this.environment
  branch_pattern = each.value
}

# Variables read by the shared reusable workflow (AZURE_*, TF_STATE_*).
resource "github_actions_environment_variable" "this" {
  for_each      = var.environment_variables
  repository    = var.repository
  environment   = github_repository_environment.this.environment
  variable_name = each.key
  value         = each.value
}

# Trust GitHub OIDC tokens issued to jobs running in this environment.
resource "azurerm_federated_identity_credential" "this" {
  name                      = var.federated_credential_name
  user_assigned_identity_id = var.umi_resource_id
  audience                  = ["api://AzureADTokenExchange"]
  issuer                    = "https://token.actions.githubusercontent.com"
  subject                   = var.federated_subject
}
