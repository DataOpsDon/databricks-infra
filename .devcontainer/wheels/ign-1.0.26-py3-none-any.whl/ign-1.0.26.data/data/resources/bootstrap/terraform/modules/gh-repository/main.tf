# -----------------------------------------------------------------------------
# GitHub repository + repository-level guardrails.
# GitHub equivalent of the Azure DevOps project creation and project settings.
# Run once per repository (isFirstTimeDeployToGH).
# -----------------------------------------------------------------------------

resource "github_repository" "this" {
  count       = var.create_repository ? 1 : 0
  name        = var.repository_name
  description = var.description
  visibility  = var.visibility
  auto_init   = true

  has_issues   = true
  has_projects = false
  has_wiki     = false

  allow_merge_commit     = contains(var.allowed_merge_methods, "merge")
  allow_squash_merge     = contains(var.allowed_merge_methods, "squash")
  allow_rebase_merge     = contains(var.allowed_merge_methods, "rebase")
  allow_auto_merge       = false
  allow_update_branch    = true
  delete_branch_on_merge = true

  # Never delete an infrastructure repository from Terraform.
  archive_on_destroy = true

  dynamic "security_and_analysis" {
    for_each = var.enable_secret_scanning ? [1] : []
    content {
      secret_scanning {
        status = "enabled"
      }
      secret_scanning_push_protection {
        status = "enabled"
      }
    }
  }
}

data "github_repository" "existing" {
  count = var.create_repository ? 0 : 1
  name  = var.repository_name

  # The provider returns an empty result (not an error) when GitHub answers 404,
  # which otherwise surfaces later as a confusing null-value error.
  lifecycle {
    postcondition {
      condition     = self.name != null && self.name != ""
      error_message = "GitHub repository '${var.repository_name}' was not found, or the token cannot see it. Create it first, set ghCreateRepository: true, or use a token with access to it (fine-grained PATs must include the repository; classic PATs must be SSO-authorised for the organisation)."
    }
  }
}

locals {
  repository_name = var.create_repository ? github_repository.this[0].name : data.github_repository.existing[0].name
  full_name       = var.create_repository ? github_repository.this[0].full_name : data.github_repository.existing[0].full_name
  repo_id         = var.create_repository ? github_repository.this[0].repo_id : data.github_repository.existing[0].repo_id
}

# ----- Initial content (new repositories only) -----
# Committed before the ruleset exists, so direct commits to the default branch are still allowed.
# Commits to one branch must not run in parallel: ign bootstrap applies with -parallelism=1
# whenever initial files are supplied.

locals {
  first_files = var.create_repository ? { for k, v in var.initial_files : k => v if !contains(var.last_file_paths, k) } : {}
  last_files  = var.create_repository ? { for k, v in var.initial_files : k => v if contains(var.last_file_paths, k) } : {}
}

resource "github_repository_file" "initial" {
  for_each            = local.first_files
  repository          = local.repository_name
  branch              = var.default_branch
  file                = each.key
  content             = each.value
  commit_message      = "${var.initial_commit_message}: ${each.key}"
  overwrite_on_create = true
}

resource "github_repository_file" "last" {
  for_each            = local.last_files
  repository          = local.repository_name
  branch              = var.default_branch
  file                = each.key
  content             = each.value
  commit_message      = var.last_commit_message
  overwrite_on_create = true

  depends_on = [github_repository_file.initial]
}

# Binary files (e.g. the Ignition CLI wheel) - github_repository_file only takes UTF-8 text,
# so these go through the Contents API with a small stdlib Python script. GITHUB_TOKEN is
# inherited from the terraform process (set by ign bootstrap).
resource "terraform_data" "initial_binary" {
  for_each         = var.create_repository ? var.initial_binary_files : {}
  triggers_replace = [local.full_name, each.key, filesha256(each.value)]

  provisioner "local-exec" {
    # No shell: the interpreter is run directly with the script as its argument (Windows-safe).
    interpreter = [var.python_executable]
    command     = "${path.module}/scripts/github_put_file.py"
    environment = {
      GH_REPO    = local.full_name
      GH_BRANCH  = var.default_branch
      GH_PATH    = each.key
      GH_SOURCE  = each.value
      GH_MESSAGE = "${var.initial_commit_message}: ${each.key}"
    }
  }

  depends_on = [github_repository_file.initial, github_repository_file.last]
}

resource "github_branch" "develop" {
  count         = var.create_repository && var.create_develop_branch ? 1 : 0
  repository    = local.repository_name
  branch        = "develop"
  source_branch = var.default_branch

  depends_on = [github_repository_file.initial, github_repository_file.last, terraform_data.initial_binary]
}

# ----- Security -----

resource "github_repository_vulnerability_alerts" "this" {
  count      = var.enable_vulnerability_alerts ? 1 : 0
  repository = local.repository_name
  enabled    = true
}

resource "github_repository_dependabot_security_updates" "this" {
  count      = var.enable_vulnerability_alerts ? 1 : 0
  repository = local.repository_name
  enabled    = true

  depends_on = [github_repository_vulnerability_alerts.this]
}

# ----- Actions policy -----

# Only GitHub-owned actions, actions owned by this organisation, and the listed
# patterns may run in this repository.
resource "github_actions_repository_permissions" "this" {
  count                = var.manage_actions_permissions ? 1 : 0
  repository           = local.repository_name
  enabled              = true
  allowed_actions      = "selected"
  sha_pinning_required = var.sha_pinning_required

  allowed_actions_config {
    github_owned_allowed = true
    verified_allowed     = var.verified_actions_allowed
    patterns_allowed     = var.allowed_action_patterns
  }
}

# GITHUB_TOKEN is read-only by default, so workflows must request extra scopes
# explicitly. Actions may not approve pull requests (stops a workflow from
# satisfying its own review rule).
resource "github_workflow_repository_permissions" "this" {
  count                            = var.manage_actions_permissions ? 1 : 0
  repository                       = local.repository_name
  default_workflow_permissions     = "read"
  can_approve_pull_request_reviews = false
}

# ----- Branch protection (ruleset) -----

resource "github_repository_ruleset" "protected_branches" {
  count       = var.enable_rulesets ? 1 : 0
  name        = "terraform-protected-branches"
  repository  = local.repository_name
  target      = "branch"
  enforcement = "active"

  conditions {
    ref_name {
      include = var.protected_branches
      exclude = []
    }
  }

  dynamic "bypass_actors" {
    for_each = var.bypass_team_ids
    content {
      actor_id    = bypass_actors.value
      actor_type  = "Team"
      bypass_mode = "pull_request"
    }
  }

  rules {
    deletion                = true
    non_fast_forward        = true
    required_linear_history = var.require_linear_history
    required_signatures     = var.require_signed_commits

    pull_request {
      required_approving_review_count   = var.required_approvals
      dismiss_stale_reviews_on_push     = var.dismiss_stale_reviews
      require_code_owner_review         = var.require_code_owner_review
      require_last_push_approval        = var.require_last_push_approval
      required_review_thread_resolution = var.require_conversation_resolution
      allowed_merge_methods             = var.allowed_merge_methods
    }

    dynamic "required_status_checks" {
      for_each = length(var.required_status_checks) > 0 ? [1] : []
      content {
        strict_required_status_checks_policy = true

        dynamic "required_check" {
          for_each = var.required_status_checks
          content {
            context = required_check.value
          }
        }
      }
    }
  }

  depends_on = [github_branch.develop, github_repository_file.initial, github_repository_file.last, terraform_data.initial_binary]
}
